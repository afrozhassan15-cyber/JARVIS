# JARVIS — Development Plan
**Status:** PLAN stage — approved for AGENT implementation
**Source of truth:** ASK stage analysis (completed)
**Rule:** No implementation code until this plan is approved and AGENT mode is activated.

---

## 1. FINAL PROJECT OBJECTIVE

Build a Python-based, voice-driven desktop AI assistant named JARVIS that:

1. Runs as a real native desktop application on the user's Windows machine
2. Listens for a wake word, then captures and understands natural-language voice input
3. Classifies the user's intent (conversation, question, computer task, multi-step task, or interruption)
4. Plans and executes tasks using a dual-AI verification loop (Primary AI + Verifier AI)
5. Controls the user's computer through an abstracted, permission-aware tool layer
6. Observes the result of every action and verifies it succeeded before proceeding
7. Recovers from failures gracefully, re-plans when necessary, and escalates to the user when stuck
8. Responds naturally in voice and text with a warm, witty, intelligent personality
9. Supports pause, resume, cancel, and priority-based task switching
10. Is structured so new tools and capabilities can be added without changing the core system

**MVP success criterion (Phase 5 complete):**
> The user says "Hey JARVIS, open Notepad and type Hello World", and JARVIS:
> opens Notepad, types the text, observes the result, verifies success,
> and replies naturally — all on a visible desktop window with no crashes.

---

## 2. SYSTEM ARCHITECTURE

The system is divided into seven layers. Each layer has exactly one responsibility and communicates only through defined interfaces. No layer may directly import from a non-adjacent layer.

```
Layer 1 — Voice Layer         Audio capture, wake word, STT, TTS
Layer 2 — Understanding Layer Language parsing, intent, entities, conversation type
Layer 3 — Conversation Layer  Dialogue state, context history, clarification
Layer 4 — Task Layer          Task lifecycle, task queue, planner, interruption
Layer 5 — AI Reasoning Layer  Primary AI, Verifier AI, Verification Policy Engine
Layer 6 — Action Layer        Action Executor, Tool Registry, individual tools
Layer 7 — Observation Layer   Screen capture, OCR, step verification, error handler
```

**Cross-cutting concerns (not a layer — services used by all layers):**
- Context Manager: shared read/write store for conversation, task, and world state
- Event Bus: message queue for cross-thread, cross-layer communication
- Config: API keys, thresholds, permission settings
- Logger: structured audit log of every action

**GUI** (main thread only) reads from Context Manager and subscribes to Event Bus.
It never calls AI, tools, or voice code directly.

**Communication contract:**
- All cross-layer calls go through the Event Bus (publish/subscribe)
- Layers that need shared state read from / write to Context Manager
- The AI Reasoning Layer never imports from the Action Layer directly
- The Action Layer never imports from the AI Reasoning Layer directly
- They communicate through structured Action and ActionResult objects via the Executor

---

## 3. TECHNOLOGY STACK

### Language and Runtime
- **Python 3.11+** — stable typing, good async/threading, wide library support

### Desktop GUI
- **Phase 1-2: CustomTkinter** — fast to build, modern look, pure Python, no Qt setup
- **Phase 3+: PyQt6** — production-quality, proper threading signals, complex layouts
- Rationale: CustomTkinter gets the MVP running quickly; PyQt6 supports the full real-time task panel

### Speech-to-Text
- **IBM Watson Speech to Text** (`ibm-watson` Python SDK)
- Provides streaming recognition, high accuracy, punctuation, and speaker labels
- Used for all voice input after wake word is detected
- Fallback for testing: `speech_recognition` library with local model (no API key needed)

### Text-to-Speech
- **IBM Watson Text to Speech** (`ibm-watson` Python SDK)
- Neural voice synthesis — natural, not robotic
- Fallback for testing: `pyttsx3` (fully offline, no API key)

### Wake Word Detection
- **pvporcupine** (Porcupine by Picovoice) — lightweight, runs on CPU, always-on
- Custom wake word "Hey JARVIS" or built-in "Jarvis" keyword
- Why not STT for wake word: STT is expensive per call; wake word needs to run 24/7

### Audio Capture / Playback
- **PyAudio** — microphone stream capture, compatible with Porcupine and Watson STT
- **pygame.mixer** or **playsound** — play TTS audio output

### AI / LLM — Core Brain
- **IBM watsonx.ai** (`ibm-watsonx-ai` Python SDK)
- Primary AI: `ibm/granite-3-8b-instruct` model via `ModelInference.chat()` API
- Verifier AI: same SDK, same or different model, completely different system prompt
- Rationale: IBM's Granite models support tool calling, structured JSON output, and
  chain-of-thought reasoning. The `chat()` API supports multi-turn conversation natively.
- API: `ModelInference.chat()` with tool-calling for structured action proposals

### Intent Classification
- Built on top of watsonx.ai — no separate NLU service needed for MVP
- Optional future: IBM Watson Assistant for pre-built intent/entity classification

### Machine Learning Components
- **scikit-learn** — confidence calibration, simple classifiers if needed
- **numpy** — numerical operations for confidence score arithmetic

### Internet Search
- **DuckDuckGo Search API** (`duckduckgo-search` Python library) — free, no API key
- Future: Serper API or Bing Search API for higher reliability

### Computer Interaction / Control
- **pyautogui** — cross-platform mouse movement, clicking, keyboard input
- **pywinauto** (Windows-specific) — higher-level Windows UI element access
- **keyboard** library — global hotkeys including emergency stop

### Screen / UI Observation
- **Pillow (PIL)** — screenshot capture via `ImageGrab`
- **pytesseract** — OCR to extract visible text from screenshots
- **OpenCV** (`opencv-python`) — image processing, element detection in screenshots

### Storage / Context
- **SQLite** via Python `sqlite3` (stdlib) — task history, audit log, user preferences
- **JSON files** — configuration, tool schemas
- Future: ChromaDB vector store for long-term semantic memory

### Logging
- Python `logging` (stdlib) — structured logging to file and console
- Every action logged with: timestamp, component, action type, confidence scores, outcome

### Testing
- **pytest** — all unit and integration tests
- **pytest-mock** — mock AI API calls, mock tool execution
- **pytest-asyncio** — test async components
- **unittest.mock** — mock pyautogui and screen capture in CI

### Environment / Secrets
- **python-dotenv** — load `.env` file for API keys
- Never hardcode API keys; never commit `.env` to version control

---

## 4. PROJECT STRUCTURE

```
JARVIS/
│
├── main.py                          Entry point — starts the desktop app
├── .env                             API keys (never committed)
├── .env.example                     Template showing required keys
├── requirements.txt                 All dependencies
├── README.md                        Setup and run instructions
│
├── config/
│   ├── config.py                    Config dataclass — loads from .env
│   ├── permissions.py               Permission definitions and action safety levels
│   └── thresholds.py                Confidence thresholds and policy constants
│
├── core/
│   ├── orchestrator.py              Top-level coordinator — owns the main loop
│   ├── event_bus.py                 Publish/subscribe message bus for all components
│   └── context_manager.py          Shared context store — conversation, task, world state
│
├── voice/
│   ├── wake_word.py                 WakeWordDetector — Porcupine integration
│   ├── speech_to_text.py            SpeechToText — Watson STT wrapper
│   └── text_to_speech.py            TextToSpeech — Watson TTS wrapper
│
├── understanding/
│   ├── language_parser.py           LanguageParser — intent, entities, input type
│   └── input_types.py               InputType enum and ParsedInput dataclass
│
├── conversation/
│   ├── conversation_manager.py      ConversationManager — dialogue state and history
│   └── clarification.py             ClarificationHandler — when JARVIS needs more info
│
├── tasks/
│   ├── task.py                      Task, TaskStep, TaskStatus dataclasses
│   ├── task_manager.py              TaskManager — lifecycle, queue, priority
│   ├── planner.py                   Planner — decomposes goals into step sequences
│   └── interruption_manager.py      InterruptionManager — pause, resume, switch
│
├── ai/
│   ├── primary_ai.py                PrimaryAI — watsonx.ai inference, action proposal
│   ├── verifier_ai.py               VerifierAI — watsonx.ai inference, evaluation
│   ├── policy_engine.py             VerificationPolicyEngine — approval decisions
│   ├── action_schema.py             Action and ActionResult dataclasses
│   └── prompts/
│       ├── primary_system_prompt.txt     System prompt for Primary AI persona
│       ├── verifier_system_prompt.txt    System prompt for Verifier AI persona
│       └── planner_system_prompt.txt     System prompt for planning role
│
├── tools/
│   ├── base_tool.py                 BaseTool abstract class — the tool interface contract
│   ├── tool_registry.py             ToolRegistry — register and discover tools
│   ├── computer_control/
│   │   ├── computer_tool.py         ComputerControlTool — mouse, keyboard, apps
│   │   └── screen_reader.py        ScreenReader — screenshot, OCR, element finding
│   ├── browser/
│   │   └── browser_tool.py          BrowserTool — Playwright-based browser control
│   ├── search/
│   │   └── search_tool.py           WebSearchTool — DuckDuckGo wrapper
│   └── filesystem/
│       └── file_tool.py             FileSystemTool — safe file read/write
│
├── observation/
│   ├── observer.py                  Observer — captures world state after action
│   ├── step_verifier.py             StepVerifier — compares result to expected outcome
│   └── error_handler.py             ErrorHandler — classifies failures, plans recovery
│
├── response/
│   ├── response_generator.py        ResponseGenerator — builds natural language replies
│   └── personality.py               Personality — tone, wit, status update templates
│
├── safety/
│   ├── permission_checker.py        PermissionChecker — blocks unsafe actions
│   └── action_classifier.py         ActionSafetyClassifier — auto/confirm/block
│
├── gui/
│   ├── app_window.py                Main application window
│   ├── conversation_panel.py        Chat transcript display
│   ├── task_panel.py                Active task and step status display
│   ├── voice_indicator.py           Visual microphone/speaking state
│   └── settings_panel.py            API keys, voice, and permission configuration
│
├── memory/
│   ├── session_memory.py            In-memory context for current session
│   └── persistent_memory.py         SQLite-backed task history and preferences
│
├── logs/
│   └── jarvis.log                   Runtime audit log (auto-created)
│
└── tests/
    ├── unit/
    │   ├── test_language_parser.py
    │   ├── test_task_manager.py
    │   ├── test_planner.py
    │   ├── test_primary_ai.py
    │   ├── test_verifier_ai.py
    │   ├── test_policy_engine.py
    │   ├── test_tool_registry.py
    │   ├── test_computer_tool.py
    │   ├── test_observer.py
    │   ├── test_step_verifier.py
    │   └── test_permission_checker.py
    ├── integration/
    │   ├── test_voice_pipeline.py
    │   ├── test_task_execution_loop.py
    │   ├── test_dual_ai_verification.py
    │   └── test_error_recovery.py
    └── e2e/
        └── test_end_to_end_scenarios.py
```

---

## 5. CORE CLASSES AND RESPONSIBILITIES

### core/orchestrator.py — Orchestrator
- **Purpose:** The top-level coordinator. Owns the main application loop.
- **Responsibility:** Receives events from the Event Bus, routes them to the correct layer, maintains overall system state.
- **Key methods:** `start()`, `stop()`, `handle_voice_input(transcript)`, `handle_task_event(event)`, `handle_user_interrupt()`
- **Communicates with:** Event Bus, Context Manager, Task Manager, Response Generator, GUI

### core/event_bus.py — EventBus
- **Purpose:** Thread-safe publish/subscribe message bus.
- **Responsibility:** Decouple components so they never import each other directly.
- **Key methods:** `publish(event_type, payload)`, `subscribe(event_type, callback)`, `unsubscribe(event_type, callback)`
- **Communicates with:** Every component in the system

### core/context_manager.py — ContextManager
- **Purpose:** Shared state store for the entire session.
- **Responsibility:** Hold conversation history, current task state, last world observation. Provide thread-safe reads and writes.
- **Key methods:** `get_conversation_history()`, `add_turn(role, content)`, `set_task_context(task)`, `update_world_state(observation)`, `get_world_state()`
- **Communicates with:** All layers that need shared state

### voice/speech_to_text.py — SpeechToText
- **Purpose:** Convert microphone audio to text using IBM Watson STT.
- **Responsibility:** Stream audio to Watson API, return transcript with confidence score.
- **Key methods:** `start_streaming()`, `stop_streaming()`, `transcribe_audio(audio_bytes) -> TranscriptResult`
- **Communicates with:** WakeWordDetector (trigger), Orchestrator (delivers transcript)

### voice/text_to_speech.py — TextToSpeech
- **Purpose:** Convert text to audio and play it through the speaker.
- **Responsibility:** Call Watson TTS API, save audio to temp file, play it without blocking GUI.
- **Key methods:** `speak(text)`, `stop_speaking()`, `is_speaking() -> bool`
- **Communicates with:** ResponseGenerator (receives text), runs on background thread

### understanding/language_parser.py — LanguageParser
- **Purpose:** Understand what the user said.
- **Responsibility:** Classify input type, extract intent, identify entities, detect urgency.
- **Key methods:** `parse(transcript: str) -> ParsedInput`
- **ParsedInput fields:** `input_type`, `intent`, `entities`, `raw_text`, `confidence`
- **Communicates with:** Orchestrator (receives transcript), Conversation Manager, Task Manager

### tasks/task_manager.py — TaskManager
- **Purpose:** Own the full lifecycle of all tasks.
- **Responsibility:** Create tasks, maintain the task queue, manage state transitions, handle interruptions.
- **Key methods:** `create_task(goal, priority) -> Task`, `activate_task(task_id)`, `pause_task(task_id)`, `resume_task(task_id)`, `cancel_task(task_id)`, `get_active_task() -> Task | None`
- **Communicates with:** Planner, Task Executor (within Task Manager), Interruption Manager, Context Manager

### tasks/planner.py — Planner
- **Purpose:** Decompose a natural-language goal into ordered, atomic steps.
- **Responsibility:** Call Primary AI with planning prompt, receive structured step list, validate steps.
- **Key methods:** `plan(goal: str, context: ContextSnapshot) -> TaskPlan`
- **TaskPlan fields:** `goal`, `steps: list[TaskStep]`, `created_at`
- **TaskStep fields:** `id`, `description`, `action_type`, `expected_outcome`, `precondition`, `fallback`
- **Communicates with:** Primary AI (planning call), Task Manager

### ai/primary_ai.py — PrimaryAI
- **Purpose:** The reasoning brain that proposes actions.
- **Responsibility:** Given current step, context, and last observation, produce a structured action proposal with reasoning and confidence.
- **Key methods:** `propose_action(step, context) -> ActionProposal`, `revise_action(step, context, verifier_feedback) -> ActionProposal`
- **ActionProposal fields:** `action: Action`, `reasoning: str`, `confidence: float`, `alternatives: list`
- **Communicates with:** watsonx.ai SDK, Context Manager, VerificationPolicyEngine

### ai/verifier_ai.py — VerifierAI
- **Purpose:** The independent critic that evaluates every proposed action.
- **Responsibility:** Receive an action proposal, evaluate it without access to Primary AI's reasoning path, return verdict and confidence.
- **Key methods:** `evaluate(proposal: ActionProposal, context: ContextSnapshot) -> VerifierResult`
- **VerifierResult fields:** `verdict: Verdict`, `confidence: float`, `risks: list[str]`, `suggested_correction: str | None`
- **Communicates with:** watsonx.ai SDK (separate call), VerificationPolicyEngine

### ai/policy_engine.py — VerificationPolicyEngine
- **Purpose:** Make the final approval decision based on both AI outputs.
- **Responsibility:** Apply the decision table, enforce retry limits, escalate to user when needed.
- **Key methods:** `decide(proposal: ActionProposal, result: VerifierResult) -> PolicyDecision`
- **PolicyDecision values:** EXECUTE, RECONSIDER, BLOCK, ASK_USER, ESCALATE
- **Communicates with:** PrimaryAI (sends back for revision), ActionExecutor (sends EXECUTE), Orchestrator (sends ASK_USER / ESCALATE)

### tools/base_tool.py — BaseTool (abstract)
- **Purpose:** Define the contract every tool must implement.
- **Responsibility:** Provide `can_handle()`, `execute()`, and `get_schema()` interface.
- **Key methods:** `can_handle(action: Action) -> bool`, `execute(action: Action) -> ActionResult`, `get_schema() -> dict`
- **Communicates with:** ToolRegistry, ActionExecutor

### tools/tool_registry.py — ToolRegistry
- **Purpose:** Maintain the list of registered tools and route actions to the right one.
- **Responsibility:** Register tools, find the correct tool for a given action, return tool schemas to AI.
- **Key methods:** `register(tool: BaseTool)`, `find_tool(action: Action) -> BaseTool`, `get_all_schemas() -> list[dict]`
- **Communicates with:** ActionExecutor, PrimaryAI (for schema injection into prompt)

### observation/observer.py — Observer
- **Purpose:** Capture the state of the world after an action is executed.
- **Responsibility:** Take screenshot, run OCR, capture window title and active app, assemble Evidence Bundle.
- **Key methods:** `capture() -> EvidenceBunle`
- **EvidenceBundle fields:** `screenshot_path`, `visible_text`, `window_title`, `active_app`, `captured_at`
- **Communicates with:** StepVerifier (delivers evidence), ContextManager (updates world state)

### observation/step_verifier.py — StepVerifier
- **Purpose:** Determine whether an action succeeded.
- **Responsibility:** Compare EvidenceBundle against the step's expected_outcome using LLM reasoning.
- **Key methods:** `verify(step: TaskStep, evidence: EvidenceBundle) -> VerificationResult`
- **VerificationResult fields:** `passed: bool`, `confidence: float`, `explanation: str`
- **Communicates with:** Observer (receives evidence), ErrorHandler (on failure), TaskManager (on pass)

### observation/error_handler.py — ErrorHandler
- **Purpose:** Classify failures and produce recovery strategies.
- **Responsibility:** Receive failed verification, classify error type, propose recovery action or re-plan request.
- **Key methods:** `classify(step, evidence, verification_result) -> ErrorClassification`, `plan_recovery(classification) -> RecoveryStrategy`
- **Communicates with:** StepVerifier (receives failure), TaskManager (sends recovery or replanning request)

### response/response_generator.py — ResponseGenerator
- **Purpose:** Produce natural, personality-driven text for every user-facing communication.
- **Responsibility:** Receive a semantic message (task completed, step failed, asking for confirmation) and convert it to JARVIS-voice text.
- **Key methods:** `generate(message_type, context) -> str`, `status_update(step_description) -> str`, `confirmation_request(action_description) -> str`
- **Communicates with:** Personality layer, TextToSpeech, GUI ConversationPanel

### safety/permission_checker.py — PermissionChecker
- **Purpose:** Hard boundary between safe and unsafe actions.
- **Responsibility:** Block any action that exceeds defined permission levels before it reaches the tool layer.
- **Key methods:** `check(action: Action) -> PermissionResult`
- **PermissionResult values:** ALLOW, REQUIRE_CONFIRMATION, BLOCK
- **Communicates with:** ActionExecutor (called before every tool execution)

---

## 6. TASK EXECUTION ENGINE

### Step 1 — Voice Input → ParsedInput
- User speaks after wake word
- Watson STT transcribes audio to text
- LanguageParser classifies: InputType is one of CONVERSATION, QUESTION, COMPUTER_TASK, MULTI_STEP_TASK, INTERRUPTION, CANCEL, CLARIFICATION
- Result is a ParsedInput object with intent and entities

### Step 2 — Routing
- Orchestrator reads InputType
- CONVERSATION / QUESTION → ConversationManager → ResponseGenerator → TTS
- COMPUTER_TASK / MULTI_STEP_TASK → TaskManager
- INTERRUPTION → InterruptionManager
- CANCEL → TaskManager.cancel_task()

### Step 3 — Task Creation and Planning
- TaskManager creates a Task with status PENDING
- Planner receives the goal and calls PrimaryAI with planning system prompt
- PrimaryAI returns a TaskPlan: ordered list of TaskStep objects
- Each step has: description, action_type, expected_outcome, precondition, fallback
- TaskManager activates the task (status → ACTIVE)

### Step 4 — Execution Loop (per step)
```
FOR each step in task.steps:
  1. Check precondition against current world state
  2. PrimaryAI.propose_action(step, context)  → ActionProposal + confidence
  3. VerifierAI.evaluate(proposal, context)   → VerifierResult + confidence
  4. PolicyEngine.decide(proposal, result)    → PolicyDecision
     IF EXECUTE     → continue to step 5
     IF RECONSIDER  → PrimaryAI.revise_action() → repeat from step 3
     IF BLOCK       → mark step FAILED, skip to error handling
     IF ASK_USER    → pause, ask user, wait for response, resume
     IF ESCALATE    → pause task, notify user, wait
  5. PermissionChecker.check(action)
     IF BLOCK       → same as PolicyEngine BLOCK
     IF REQUIRE_CONFIRMATION → ask user, wait for "yes"/"no"
  6. ToolRegistry.find_tool(action) → execute action
  7. Observer.capture() → EvidenceBundle
  8. StepVerifier.verify(step, evidence) → VerificationResult
     IF passed      → mark step COMPLETE, GUI update, continue loop
     IF failed      → ErrorHandler → RecoveryStrategy
       IF retry     → increment retry count, repeat from step 2 (max 3)
       IF replan    → Planner regenerates remaining steps
       IF escalate  → pause task, notify user
END LOOP
```

### Step 5 — Task Completion
- All steps complete → TaskManager marks task COMPLETED
- ResponseGenerator produces natural completion message
- TTS speaks the result
- GUI updates task panel

---

## 7. DUAL-AI VERIFICATION

### Primary AI Persona (system prompt defines this)
- Role: Focused, goal-oriented action planner
- Instruction: "Propose the most effective action to complete the current step. Provide your reasoning and a confidence score between 0.0 and 1.0 representing how certain you are this action is correct and safe."
- Output format: Structured JSON — action type, parameters, reasoning, confidence

### Verifier AI Persona (completely different system prompt)
- Role: Independent safety critic
- Instruction: "You are reviewing an action proposed by another AI. You have NOT seen its reasoning. Evaluate only the action itself: is it the right action, is it safe, could it cause unintended harm? Give a verdict (APPROVE/REJECT) and a confidence score."
- Output format: Structured JSON — verdict, confidence, risk list, optional correction

### Confidence Score Definition
- A score between 0.0 and 1.0 representing certainty that the action is correct AND safe
- 1.0 means absolutely certain; 0.0 means completely uncertain
- Irreversible actions (delete, send, submit) must have a confidence ceiling of 0.75
  (the system always asks for user confirmation above this ceiling for irreversible actions)

### Verification Policy Decision Table

| PAI Score | VAI Score  | VAI Verdict | Decision            |
|-----------|------------|-------------|---------------------|
| >= 0.80   | >= 0.75    | APPROVE     | EXECUTE             |
| >= 0.70   | >= 0.70    | APPROVE     | EXECUTE             |
| >= 0.70   | < 0.50     | REJECT      | RECONSIDER          |
| < 0.50    | any        | any         | ASK_USER            |
| any       | any        | REJECT + risk=UNSAFE | BLOCK        |
| action is irreversible | any | APPROVE   | ASK_USER always     |
| reconsider_count >= 3  | any | any       | ESCALATE            |
| both > 0.70 but disagree | - | -        | RECONSIDER once, then ASK_USER |

### Reconsideration Protocol
- PolicyEngine sends verifier feedback to PrimaryAI along with: "The verifier flagged: [risk]. Reconsider and provide a revised proposal."
- PrimaryAI sees its own original proposal plus the verifier objection
- PrimaryAI may revise the action, change parameters, or propose a different approach
- Verifier evaluates the new proposal from scratch (not the diff)
- Maximum 3 reconsider cycles per step; after that: ESCALATE to user

### When Both AIs Are Uncertain (both < 0.50)
- PolicyEngine triggers ASK_USER regardless of agreement
- JARVIS says: "I'm not confident about the best approach here. Could you clarify?"
- User's clarification is fed back into context and the loop restarts from planning

---

## 8. ERROR RECOVERY

### Error Classification (ErrorHandler classifies these)

| Error Type             | Detection Method                                        |
|------------------------|---------------------------------------------------------|
| Element not found      | OCR finds no matching text; pyautogui raises exception  |
| Wrong screen state     | StepVerifier: expected text not present in screenshot   |
| Application did not open | Window title does not match expected within timeout  |
| Click had no effect    | Screenshot identical before and after action            |
| Network failure        | requests / API raises ConnectionError or timeout        |
| AI returned invalid action | ActionProposal fails schema validation              |
| Step timeout           | Step took longer than configured max_step_duration      |
| Unexpected popup       | OCR detects dialog/modal not in expected outcome        |

### Recovery Strategies

| Error Type             | Recovery Strategy                                       |
|------------------------|---------------------------------------------------------|
| Element not found      | Re-scan screen; try OCR-based element search; retry up to 3x |
| Wrong screen state     | Undo last action if reversible; re-observe; re-plan from last verified state |
| Application not open   | Wait 2s, retry; try alternative launch command          |
| Click no effect        | Move mouse away, click again; scroll to find element    |
| Network failure        | Retry with 1s / 3s / 5s backoff; notify user if 3rd fails |
| Invalid action schema  | Log the malformed output; ask PrimaryAI to reformat     |
| Step timeout           | Capture current screen; classify as wrong state         |
| Unexpected popup       | Detect popup type; close if safe; escalate if unknown   |

### Retry Budget
- Every step has a retry budget of 3 attempts
- After 3 failures on the same step: pause task, inform user with current state screenshot
- Never silently loop; always increment retry counter

### Re-planning Trigger
- If ErrorHandler classifies an error as ENVIRONMENT_CHANGED (something unexpected is visible on screen), it triggers a re-plan rather than a retry
- Planner receives: original goal + completed steps + current screen state + error description
- Planner produces new steps from the current state forward
- Maximum 2 re-plan cycles per task; after that: FAILED

---

## 9. MULTI-TASK AND INTERRUPTION SYSTEM

### Task States
```
PENDING   → created, not yet executing
ACTIVE    → currently executing
VERIFYING → AI is evaluating current step action
EXECUTING → tool action is running
OBSERVING → observer is capturing post-action state
PAUSED    → execution halted; full context serialised to memory
COMPLETED → all steps verified as passed
FAILED    → exceeded retry/replan budget
CANCELLED → user explicitly cancelled
WAITING   → awaiting user input (confirmation or clarification)
```

### Task Priority Levels
- CRITICAL (0): immediately interrupts all other tasks; emergency stop
- HIGH (1): pauses current task after current atomic step completes
- NORMAL (2): queued after current task completes
- BACKGROUND (3): only runs when no active or paused tasks exist

### Interruption Protocol
1. User speaks while a task is active → InterruptionManager receives ParsedInput
2. InterruptionManager classifies: STOP, NEW_TASK, QUESTION, or PRIORITIZE
3. STOP: cancel current task, clear queue
4. QUESTION: answer inline without pausing task (status update: "Working on it — [answer]")
5. NEW_TASK: pause current task (serialise step context), create new task at HIGH priority, execute
6. After new task completes: JARVIS says "I've finished [new task]. Should I continue [previous task]?"

### Context Preservation on Pause
Serialised to Context Manager:
- Task ID and current step index
- Completed step results
- Last EvidenceBundle (world state snapshot)
- Retry counts
- AI conversation history for this task

### World State Validation on Resume
Before resuming a paused task:
- Observer captures current screen
- StepVerifier checks: does the current screen still match the expected precondition for the next step?
- If yes: resume normally
- If no: re-plan from current state forward

---

## 10. VOICE CONVERSATION

### Voice Pipeline Architecture
```
Microphone (PyAudio)
    → WakeWordDetector (Porcupine, always running on background thread)
    → WakeWord detected → activate STT
    → SpeechToText (Watson STT, streaming)
    → Transcript delivered to Orchestrator
    → Orchestrator routes to Understanding layer
    → Response built by ResponseGenerator
    → TextToSpeech (Watson TTS)
    → Audio playback (pygame.mixer)
```

### Always-On Design
- WakeWordDetector runs on a dedicated daemon thread
- It consumes minimal CPU (~1%) when idle
- When wake word is detected it triggers the STT pipeline
- STT listens until 2 seconds of silence, then closes the stream and delivers transcript

### Long-Task Voice Behaviour
The system must not go silent for more than 15 seconds during a task. Rules:
- Every time a step begins: short status update ("Opening Notepad...")
- Every 15 seconds without a natural update: background status ("Still working on this...")
- On step success: brief acknowledgment ("Got it, moving on...")
- On error: honest update ("Hit a snag — trying again...")
- On task completion: full natural summary

### While JARVIS Is Speaking
- Voice input is suppressed to prevent feedback loops
- The voice indicator shows "SPEAKING" state
- Emergency stop keyword still active even while speaking

### Fallback Mode (no API keys)
- STT: `speech_recognition` with Google or local Vosk model
- TTS: `pyttsx3` offline synthesis
- System still works without IBM credentials; just with reduced quality

---

## 11. PERSONALITY LAYER

### Design Principle
The Personality Layer is a pure transformation layer. It receives a semantic message type and parameters and returns a natural language string. Task logic never changes based on personality. Personality never influences decision-making.

### JARVIS Personality Profile
- Intelligent: precise, uses correct vocabulary, never dumbs down unnecessarily
- Warm: uses contractions, natural phrasing, occasional first-person
- Friendly: not overly formal; treats the user as a capable adult
- Witty: light humour at appropriate moments — never during errors or safety warnings
- Concise during execution: short confirmations, not paragraphs
- Clear for confirmation: safety-critical requests are unambiguous and direct

### Message Type Catalogue

| Message Type           | Example Output                                                          |
|------------------------|-------------------------------------------------------------------------|
| TASK_STARTED           | "On it."                                                                |
| STEP_UPDATE            | "Opening Notepad..."                                                    |
| STEP_COMPLETE          | "Done. Moving on."                                                      |
| TASK_COMPLETE          | "All finished. I've opened Notepad and typed your message."             |
| STEP_RETRY             | "That didn't quite work — trying again."                                |
| TASK_FAILED            | "I ran into a problem I couldn't resolve. Here's where things stand..."  |
| CONFIRM_ACTION         | "I'm about to delete that file permanently. Are you sure?"              |
| CONFIRM_IRREVERSIBLE   | "Just to be safe — send that email to everyone on the list?"            |
| CLARIFICATION_NEEDED   | "Could you be a bit more specific about which folder you mean?"         |
| QUESTION_ANSWER        | Natural LLM response                                                    |
| CASUAL_RESPONSE        | Natural LLM response with personality system prompt                     |
| LONG_RUNNING_UPDATE    | "Still on it — this one's taking a moment."                             |
| TASK_PAUSED            | "Pausing that for now. What do you need?"                               |
| TASK_RESUMED           | "Right, back to what we were doing..."                                  |

### Implementation Note
ResponseGenerator calls watsonx.ai with a personality-flavoured system prompt only for QUESTION_ANSWER and CASUAL_RESPONSE types. All other message types use pre-written templates from `personality.py` with light variable substitution. This keeps latency low during task execution.

---

## 12. SAFETY AND PERMISSIONS

### Action Safety Levels

| Level               | Definition                                             | Behaviour                    |
|---------------------|--------------------------------------------------------|------------------------------|
| SAFE                | Reversible, low-risk, no data loss possible            | Execute automatically        |
| CONFIRM_REQUIRED    | Irreversible OR affects external services              | Always ask user first        |
| ELEVATED_CONFIRM    | Destructive, financial, or system-level action         | Ask twice, require explicit "yes" |
| BLOCKED             | Outside defined scope or explicitly prohibited         | Refuse and explain           |

### SAFE Actions (auto-execute)
- Open any standard application
- Type text into a text field
- Click clearly-identified buttons
- Take screenshots
- Read visible text from screen
- Search the web

### CONFIRM_REQUIRED Actions
- Delete any file or folder
- Send any email or message
- Submit any form
- Purchase or payment actions
- Close unsaved work

### ELEVATED_CONFIRM Actions
- System settings changes
- Uninstall applications
- Modify registry or system files
- Any action outside the user's home directory

### BLOCKED Actions (never execute)
- Access to passwords or credential stores
- Actions on files outside C:\Users\[current user]\ without explicit override
- Executing downloaded scripts without review
- Actions that would disable security software

### Emergency Stop
- Keyword "JARVIS STOP" OR global hotkey (configurable, default: Ctrl+Shift+Esc)
- Immediately: halt all tool execution, release any held keyboard/mouse states, mark active task CANCELLED
- JARVIS says: "Stopped."
- No further actions taken until user speaks again

### Audit Log
Every executed action is logged:
```
timestamp | action_type | parameters | PAI_confidence | VAI_confidence | decision | outcome
```
Log is stored in `logs/jarvis.log` and never deleted automatically.

---

## 13. MVP DEVELOPMENT PHASES

### Phase 1 — Project Foundation
**Goal:** A runnable desktop window with a working event system.
**Components:**
- `config/` module with Config and .env loading
- `core/event_bus.py` EventBus
- `core/context_manager.py` ContextManager
- `gui/app_window.py` minimal CustomTkinter window
- `gui/conversation_panel.py` basic text display
- `main.py` entry point
**Dependencies:** None (no IBM services yet)
**Tests:** EventBus pub/sub, ContextManager thread safety, GUI launches without crashing
**Definition of done:** `python main.py` opens a window; EventBus unit tests pass

### Phase 2 — Voice Input and Output
**Goal:** JARVIS listens for wake word, hears a spoken command, and speaks a reply.
**Components:**
- `voice/wake_word.py` Porcupine integration
- `voice/speech_to_text.py` Watson STT (with pyttsx3 fallback)
- `voice/text_to_speech.py` Watson TTS (with pyttsx3 fallback)
- `gui/voice_indicator.py` microphone state display
**Dependencies:** Phase 1, IBM Watson credentials or fallback
**Tests:** STT returns transcript for known audio, TTS produces audio without crashing, wake word fires on trigger
**Definition of done:** Say "Hey JARVIS, hello" and hear a reply

### Phase 3 — Language Understanding
**Goal:** JARVIS classifies spoken input into the correct type and extracts intent.
**Components:**
- `understanding/language_parser.py` LanguageParser
- `understanding/input_types.py` InputType enum and ParsedInput
- `conversation/conversation_manager.py` ConversationManager
- `response/response_generator.py` ResponseGenerator (basic)
- `response/personality.py` personality templates
**Dependencies:** Phase 2, watsonx.ai credentials
**Tests:** LanguageParser correctly classifies at least 10 diverse inputs (unit tests with mocked LLM)
**Definition of done:** "Hey JARVIS, what is the capital of France?" returns a correct spoken answer

### Phase 4 — Tool System Foundation
**Goal:** The Action Executor can run tools through a registry.
**Components:**
- `tools/base_tool.py` BaseTool abstract class
- `tools/tool_registry.py` ToolRegistry
- `ai/action_schema.py` Action and ActionResult dataclasses
- `safety/permission_checker.py` PermissionChecker
- `safety/action_classifier.py` ActionSafetyClassifier
**Dependencies:** Phase 3
**Tests:** ToolRegistry registers and routes to correct tool, PermissionChecker blocks and allows correctly
**Definition of done:** A mock tool can be registered, found, and executed through the registry

### Phase 5 — Computer Control (MVP milestone)
**Goal:** JARVIS can open an application and type text — the end-to-end MVP.
**Components:**
- `tools/computer_control/computer_tool.py` ComputerControlTool
- `tools/computer_control/screen_reader.py` ScreenReader
- `observation/observer.py` Observer
- `observation/step_verifier.py` StepVerifier basic version
- `ai/primary_ai.py` PrimaryAI (single-step, no verifier yet)
**Dependencies:** Phase 4
**Tests:** ComputerTool unit tests with mocked pyautogui; Observer returns valid EvidenceBundle; integration test opens Notepad in a sandboxed environment
**Definition of done:** "Hey JARVIS, open Notepad and type Hello World" works end-to-end

### Phase 6 — Dual-AI Verification
**Goal:** Every action passes through the Primary AI → Verifier AI → Policy Engine loop.
**Components:**
- `ai/verifier_ai.py` VerifierAI
- `ai/policy_engine.py` VerificationPolicyEngine
- `ai/prompts/` system prompt files
- Updated PrimaryAI to use revision protocol
**Dependencies:** Phase 5
**Tests:** Policy engine applies decision table correctly for all confidence combinations; reconsider loop does not exceed 3 cycles; mock AI returns test confidence values
**Definition of done:** JARVIS refuses an unsafe proposed action and asks user for confirmation

### Phase 7 — Task Planning and Multi-Step Execution
**Goal:** JARVIS handles a goal with 3+ steps autonomously.
**Components:**
- `tasks/task.py` Task, TaskStep, TaskStatus dataclasses
- `tasks/task_manager.py` TaskManager with state machine
- `tasks/planner.py` Planner
- Full execution loop with step iteration
**Dependencies:** Phase 6
**Tests:** Planner produces valid TaskPlan for 5 known goals; TaskManager correctly transitions all states; integration test executes a 3-step task
**Definition of done:** "Open browser, navigate to google.com, and search for IBM" executes all 3 steps

### Phase 8 — Error Recovery
**Goal:** JARVIS detects failed steps and recovers or re-plans intelligently.
**Components:**
- `observation/error_handler.py` ErrorHandler
- Error classification for all defined error types
- Retry logic and re-plan trigger in execution loop
**Dependencies:** Phase 7
**Tests:** ErrorHandler correctly classifies each error type; retry budget is respected; re-plan is triggered on environment change
**Definition of done:** Deliberately failing a step (mocked) triggers retry, then re-plan, then user escalation correctly

### Phase 9 — Task Interruption and Priority
**Goal:** JARVIS can pause, accept a new task, and resume correctly.
**Components:**
- `tasks/interruption_manager.py` InterruptionManager
- Context serialisation on pause
- World-state validation on resume
- Task priority queue in TaskManager
**Dependencies:** Phase 8
**Tests:** Interruption correctly pauses active task; world-state mismatch detected on resume; priority ordering is correct
**Definition of done:** Mid-task "JARVIS stop that and open Calculator" correctly pauses, opens Calculator, then offers to resume previous task

### Phase 10 — Internet Search and Full Personality
**Goal:** JARVIS can search the web and responds with full personality.
**Components:**
- `tools/search/search_tool.py` WebSearchTool
- `tools/browser/browser_tool.py` BrowserTool (Playwright)
- Full personality templates for all message types
- Long-running status update system (15-second rule)
- `memory/persistent_memory.py` SQLite task history
**Dependencies:** Phase 9
**Tests:** WebSearchTool returns results for known queries; BrowserTool navigates to a known URL; personality templates cover all defined message types
**Definition of done:** "Hey JARVIS, search for the latest IBM news and tell me the top story" completes end-to-end with personality

---

## 14. IBM INTEGRATION

IBM technology is used where it provides genuine value. It is not forced into components where simpler alternatives work equally well.

### IBM Watson Speech to Text
- **Where:** `voice/speech_to_text.py`
- **Why:** High-accuracy streaming transcription, better than free alternatives for real-time voice
- **SDK:** `ibm-watson` Python SDK, `SpeechToTextV1` class
- **Credential:** `WATSON_STT_API_KEY` and `WATSON_STT_URL` in `.env`

### IBM Watson Text to Speech
- **Where:** `voice/text_to_speech.py`
- **Why:** Neural voice quality — JARVIS must not sound robotic
- **SDK:** `ibm-watson` Python SDK, `TextToSpeechV1` class
- **Credential:** `WATSON_TTS_API_KEY` and `WATSON_TTS_URL` in `.env`

### IBM watsonx.ai
- **Where:** `ai/primary_ai.py`, `ai/verifier_ai.py`, `tasks/planner.py`, `response/response_generator.py`
- **Why:** The core reasoning engine. Foundation models support tool calling, structured JSON output, and multi-turn chat natively via Python SDK.
- **Model:** `ibm/granite-3-8b-instruct` for most reasoning tasks (fast, cost-effective)
- **API:** `ModelInference.chat()` with structured output
- **SDK:** `ibm-watsonx-ai` Python SDK
- **Credentials:** `WATSONX_API_KEY`, `WATSONX_PROJECT_ID`, `WATSONX_URL` in `.env`

### IBM Not Used (intentional exclusions)
- **Watson Assistant:** Not needed — watsonx.ai foundation models handle intent classification more flexibly
- **IBM Cloud databases:** SQLite is sufficient for MVP and beginner-friendly; no cloud DB needed
- **watsonx.governance:** Relevant for Phase 4 (AI evaluation metrics) — not in MVP scope

---

## 15. TESTING STRATEGY

### Unit Tests (`tests/unit/`)
- One test file per core class
- All IBM API calls are mocked with `pytest-mock`
- All pyautogui calls are mocked
- Focus: does the class logic work correctly in isolation?
- Coverage target: 80% of all non-GUI code

### Integration Tests (`tests/integration/`)
- Test the interaction between two or three adjacent components
- Voice pipeline: mock audio → STT → LanguageParser → correct ParsedInput
- Task execution: mock PrimaryAI + VerifierAI → PolicyEngine → mock Tool → Observer → StepVerifier
- Dual-AI verification: all decision table combinations produce correct PolicyDecision
- Error recovery: injected failures trigger correct ErrorHandler responses

### AI Evaluation Tests
- A fixed set of 20 known inputs → expected ParsedInput classifications (regression tests)
- PolicyEngine decision table: all 8 combinations → expected decision (no AI calls needed)
- PrimaryAI and VerifierAI: tested against fixed response stubs, not live API

### Computer Control Tests
- pyautogui calls are mocked; test that correct calls are made for each action type
- Observer: use a fixed test screenshot and verify OCR produces expected text
- StepVerifier: test with known screenshot + expected outcome pairs

### Voice Tests
- STT: test against a saved .wav file of known spoken words
- TTS: test that synthesise() produces a non-empty audio file without exceptions
- WakeWordDetector: test that trigger callback fires on matching audio

### Failure and Recovery Tests
- Inject each error type into the execution loop
- Verify retry counter increments correctly
- Verify escalation fires at retry_count == 3
- Verify re-plan is triggered on ENVIRONMENT_CHANGED classification

### End-to-End Tests (`tests/e2e/`)
- Scripted scenarios using real (or sandboxed) environment
- Scenario 1: "Open Notepad and type Hello JARVIS" — observe Notepad window
- Scenario 2: "Search for IBM watsonx" — observe browser navigation
- Scenario 3: Mid-task interruption and resume
- These run manually or in CI with a virtual display (xvfb on Linux / virtual desktop on Windows)

---

## 16. PROJECT SUCCESS CRITERIA

The MVP (Phase 5) is declared successful when all of the following are true:

1. `python main.py` opens a desktop window without errors
2. Wake word "Hey JARVIS" is detected from microphone input
3. "Hey JARVIS, what time is it?" produces a spoken and displayed answer
4. "Hey JARVIS, open Notepad" opens Notepad correctly
5. "Hey JARVIS, open Notepad and type Hello World" executes both steps in sequence
6. The Verifier AI rejects at least one unsafe action in the test suite (mocked)
7. The emergency stop keyword immediately halts execution
8. All Phase 1–5 unit tests pass
9. The system recovers from a deliberate mock failure (retries once and succeeds)
10. No IBM API keys are present in any source file; all keys loaded from `.env`

---

## 17. FUTURE EXTENSIONS (post-MVP)

### Realistic Phase 4 Extensions
- Persistent long-term memory with vector search (ChromaDB)
- User preference learning from task history
- Custom wake word training
- Browser automation (Playwright) for full web tasks
- File system tool for document tasks
- Email tool (send emails, read inbox)
- Calendar tool (schedule, check appointments)

### Advanced Future Capabilities
- Computer vision model for UI element detection (replace OCR-only approach)
- RAG knowledge base (JARVIS learns from user's own documents)
- Multi-modal input (voice + screen simultaneously)
- Fine-tuned Granite model on JARVIS-specific task vocabulary
- watsonx.governance integration for AI performance monitoring
- Cross-device operation (control another machine via network)
- Agent delegation (JARVIS spawns sub-agents for parallel tasks)
- Proactive assistance ("You usually do X at this time — want me to start?")

### What Will Never Be Claimed
- JARVIS is not AGI — it is an LLM-powered tool-calling agent
- JARVIS does not "understand" in the human sense
- JARVIS cannot operate without IBM API connectivity in default mode
- JARVIS cannot make decisions with moral or ethical judgment beyond its safety rules

---

## FINAL ARCHITECTURE DIAGRAM (text form for plan file)

```
User Voice
    ↓
[Wake Word Detector] ← always-on background thread
    ↓ triggered
[Speech to Text] ← Watson STT background thread
    ↓ transcript
[Language Parser] ← watsonx.ai classification
    ↓ ParsedInput
[Orchestrator + Event Bus]
    ├── Conversation / Question → [Conversation Manager] → [Response Generator] → [TTS]
    └── Task → [Task Manager]
                    ↓
               [Planner] ← watsonx.ai planning call
                    ↓ TaskPlan
               [Execution Loop]
                    ↓ per step
               [Primary AI] ← watsonx.ai inference
                    ↓ ActionProposal
               [Verifier AI] ← watsonx.ai inference
                    ↓ VerifierResult
               [Policy Engine]
                    ↓ EXECUTE / RECONSIDER / BLOCK / ASK_USER
               [Permission Checker]
                    ↓
               [Tool Registry] → [Computer Tool | Browser Tool | Search Tool | File Tool]
                    ↓ ActionResult
               [Observer] ← screenshot + OCR
                    ↓ EvidenceBundle
               [Step Verifier]
                    ├── pass → next step
                    └── fail → [Error Handler] → retry / replan / escalate
                    ↓ all steps done
               [Response Generator] ← personality layer
                    ↓
               [TTS] ← Watson TTS
                    ↓
               Voice Output + GUI Update
```

---

## FINAL TECHNOLOGY STACK SUMMARY

| Component              | Technology                          |
|------------------------|-------------------------------------|
| Language               | Python 3.11+                        |
| Desktop GUI (MVP)      | CustomTkinter                       |
| Desktop GUI (Phase 3+) | PyQt6                               |
| Wake Word              | pvporcupine                         |
| Audio Capture          | PyAudio                             |
| Speech-to-Text         | IBM Watson STT (ibm-watson SDK)     |
| Text-to-Speech         | IBM Watson TTS (ibm-watson SDK)     |
| AI / LLM               | IBM watsonx.ai (ibm-watsonx-ai SDK) |
| Primary model          | ibm/granite-3-8b-instruct           |
| Internet Search        | duckduckgo-search                   |
| Computer Control       | pyautogui + pywinauto               |
| Screen Observation     | Pillow + pytesseract + OpenCV       |
| Browser Automation     | Playwright (Phase 7+)               |
| Storage                | SQLite (stdlib sqlite3)             |
| Configuration          | python-dotenv                       |
| Testing                | pytest + pytest-mock                |
| Logging                | Python logging (stdlib)             |
| ML utilities           | scikit-learn, numpy                 |

---

## DEVELOPMENT PHASES SUMMARY

| Phase | Goal                          | Status     |
|-------|-------------------------------|------------|
| 1     | Project foundation + GUI      | [ ] pending |
| 2     | Voice input and output        | [ ] pending |
| 3     | Language understanding        | [ ] pending |
| 4     | Tool system foundation        | [ ] pending |
| 5     | Computer control — MVP        | [ ] pending |
| 6     | Dual-AI verification          | [ ] pending |
| 7     | Task planning + multi-step    | [ ] pending |
| 8     | Error recovery                | [ ] pending |
| 9     | Task interruption + priority  | [ ] pending |
| 10    | Internet search + personality | [ ] pending |

---

## RECOMMENDED FIRST IMPLEMENTATION TASK

**Phase 1, Sub-task 1:**

Create the project skeleton: all directories, empty `__init__.py` files, `requirements.txt`, `.env.example`, `config/config.py` with Config dataclass, `core/event_bus.py`, `core/context_manager.py`, and `main.py` that opens a minimal CustomTkinter window. No AI, no voice, no tools. Just a working, well-structured foundation that proves the architecture is in place and the app launches.

**Instruction for AGENT:** Read this plan file in full before starting. Implement only Phase 1. When Phase 1 is complete, update the Phase 1 status to [x] done and wait for review before proceeding to Phase 2.
