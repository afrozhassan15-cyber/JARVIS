# JARVIS — Personal AI Assistant

A Python-based, voice-driven desktop AI assistant with dual-AI verification, multi-step task execution, and extensible tool architecture.

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure API keys (optional for full functionality)

```bash
copy .env.example .env
# Edit .env and fill in your IBM credentials
```

### 3. Run the application

```bash
python main.py
```

### 4. Run tests

```bash
python -m pytest tests/unit/ tests/integration/ -v
```

---

## API Keys Required (for full functionality)

| Feature | Service | How to get |
|---|---|---|
| Speech-to-Text | IBM Watson STT | [IBM Cloud](https://cloud.ibm.com/catalog/services/speech-to-text) |
| Text-to-Speech | IBM Watson TTS | [IBM Cloud](https://cloud.ibm.com/catalog/services/text-to-speech) |
| AI Brain | IBM watsonx.ai | [IBM Cloud](https://cloud.ibm.com/catalog/services/watsonxai) |
| Wake Word | Picovoice Porcupine | [Picovoice Console](https://console.picovoice.ai/) |

**Without API keys:** The system runs in mock/fallback mode:
- TTS uses `pyttsx3` (offline)
- STT uses Google (via `SpeechRecognition`)
- AI uses deterministic stub responses (full pipeline still testable)

Use the **Speak** button in the application to ask JARVIS by voice. The
transcript follows the same processing pipeline as typed input. Microphone
input requires a working microphone and the `pyaudio` dependency from
`requirements.txt`.

---

## How It Works

```
Your voice / text
    ↓
Language Understanding (classify intent)
    ↓
Task Manager creates a Task
    ↓
Planner decomposes goal into steps
    ↓
For each step:
  Primary AI proposes an action
      ↓
  Verifier AI evaluates independently
      ↓
  Policy Engine decides: EXECUTE / RECONSIDER / BLOCK / ASK_USER
      ↓
  Permission Checker validates
      ↓
  Tool Registry executes
      ↓
  Observer captures screen state
      ↓
  Step Verifier checks success
      ↓
  Error Handler recovers if needed
    ↓
Natural voice + text response
```

---

## Example Commands

```
"open Notepad"
"open Notepad and type Hello World"
"search for IBM watsonx and tell me the top result"
"what is the capital of France?"
"cancel"
"pause"
"resume"
"stop"
```

---

## Project Structure

```
JARVIS/
├── main.py               Entry point
├── config/               Configuration, permissions, thresholds
├── core/                 Orchestrator, EventBus, ContextManager
├── voice/                STT (Watson), TTS (Watson + pyttsx3)
├── understanding/        LanguageParser, InputTypes
├── ai/                   PrimaryAI, VerifierAI, PolicyEngine, watsonx client
│   └── prompts/          System prompt files
├── tasks/                Task, TaskStep, TaskManager, Planner
├── tools/                BaseTool, ToolRegistry, ComputerTool, SearchTool
├── observation/          Observer, StepVerifier, ErrorHandler
├── response/             ResponseGenerator, Personality
├── safety/               PermissionChecker
├── gui/                  Desktop window (CustomTkinter)
├── memory/               Session and persistent memory
├── logs/                 Runtime log
└── tests/                103 unit + integration tests
```

---

## Known Limitations (MVP)

- Wake word requires Picovoice access key (currently disabled)
- Browser automation not yet implemented (Phase 10)
- OCR requires Tesseract installed separately on Windows
- Voice input requires a working microphone
- With mock AI mode, task planning produces generic steps

---

## Next Development Phase

Phase 10: Browser automation (Playwright), persistent memory (SQLite), full watsonx.ai integration with real IBM credentials.
