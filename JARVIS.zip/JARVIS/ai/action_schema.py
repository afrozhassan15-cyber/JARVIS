"""
ai/action_schema.py

Core data structures shared between the AI reasoning layer and the action/tool layer.
These dataclasses are the ONLY contract between the two layers.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class Verdict(str, Enum):
    APPROVE = "APPROVE"
    REJECT  = "REJECT"


class PolicyDecision(str, Enum):
    EXECUTE             = "EXECUTE"
    RECONSIDER          = "RECONSIDER"
    BLOCK               = "BLOCK"
    ASK_USER            = "ASK_USER"
    ESCALATE            = "ESCALATE"


@dataclass
class Action:
    """
    A semantic, structured action request produced by the Primary AI.
    The Tool layer receives this and translates it into system calls.
    The AI layer NEVER issues raw system calls directly.
    """
    action_type: str                    # e.g. "open_application", "type_text"
    parameters: dict[str, Any] = field(default_factory=dict)
    is_irreversible: bool = False       # hints to policy engine
    description: str = ""              # human-readable description of this action

    def __str__(self) -> str:
        return f"Action({self.action_type}, params={self.parameters})"


@dataclass
class ActionResult:
    """Result returned by a tool after executing an Action."""
    success: bool
    output: Any = None                  # tool-specific output (text, path, etc.)
    error_message: str = ""
    action_type: str = ""

    def __str__(self) -> str:
        status = "OK" if self.success else f"FAIL: {self.error_message}"
        return f"ActionResult({self.action_type} → {status})"


@dataclass
class ActionProposal:
    """
    The Primary AI's complete proposal for the next action.
    Sent to the Verifier AI for evaluation.
    """
    action: Action
    reasoning: str                      # chain-of-thought from Primary AI
    confidence: float                   # 0.0–1.0
    alternatives: list[Action] = field(default_factory=list)
    step_id: str = ""
    reconsider_count: int = 0          # how many times this step has been reconsidered


@dataclass
class VerifierResult:
    """
    The Verifier AI's independent evaluation of an ActionProposal.
    Verifier sees the action but NOT the Primary AI's reasoning.
    """
    verdict: Verdict
    confidence: float                   # 0.0–1.0
    risks: list[str] = field(default_factory=list)
    suggested_correction: Optional[str] = None
    explanation: str = ""


@dataclass
class VerificationResult:
    """
    Result of the StepVerifier checking whether an executed action succeeded.
    """
    passed: bool
    confidence: float
    explanation: str = ""
    error_type: str = ""                # used by ErrorHandler for classification
