"""
ai/policy_engine.py

Verification Policy Engine.

Applies the decision table from the JARVIS plan to produce a PolicyDecision
based on the Primary AI's proposal and the Verifier AI's evaluation.

The AI with the higher confidence does NOT automatically win.
Rejection carries asymmetrically more weight than approval.
"""

from __future__ import annotations

import logging

from ai.action_schema import ActionProposal, PolicyDecision, Verdict, VerifierResult
from config.thresholds import (
    MAX_RECONSIDER_CYCLES,
    PAI_HIGH_CONFIDENCE,
    PAI_LOW_THRESHOLD,
    PAI_MEDIUM_CONFIDENCE,
    VAI_HIGH_CONFIDENCE,
    VAI_MEDIUM_CONFIDENCE,
    VAI_REJECT_THRESHOLD,
)

logger = logging.getLogger(__name__)


class VerificationPolicyEngine:
    """
    Makes the final approval decision for every proposed action.

    Decision table (from JARVIS-PLAN.md §7):

    PAI >= HIGH and VAI >= HIGH and APPROVE  → EXECUTE
    PAI >= MED  and VAI >= MED  and APPROVE  → EXECUTE
    PAI >= MED  and VAI < REJECT and REJECT  → RECONSIDER
    PAI < LOW   (any)                        → ASK_USER
    UNSAFE risk in VAI                       → BLOCK
    action is irreversible                   → ASK_USER always
    reconsider_count >= MAX                  → ESCALATE
    both > MED but disagree                  → RECONSIDER once then ASK_USER
    """

    def decide(
        self,
        proposal: ActionProposal,
        verifier_result: VerifierResult,
    ) -> PolicyDecision:
        """
        Apply the decision table and return a PolicyDecision.
        """
        pai_conf     = proposal.confidence
        vai_conf     = verifier_result.confidence
        verdict      = verifier_result.verdict
        risks        = verifier_result.risks or []
        reconsidered = proposal.reconsider_count

        # ── Hard stops ────────────────────────────────────────────────────────
        # 1. UNSAFE flag in verifier risks — always block
        if "unsafe_action" in risks:
            logger.warning("PolicyEngine: BLOCK — unsafe_action risk flagged by Verifier")
            return PolicyDecision.BLOCK

        # 2. Max reconsider cycles exceeded → escalate
        if reconsidered >= MAX_RECONSIDER_CYCLES:
            logger.warning(
                "PolicyEngine: ESCALATE — reconsider_count=%d >= max=%d",
                reconsidered, MAX_RECONSIDER_CYCLES,
            )
            return PolicyDecision.ESCALATE

        # 3. Irreversible actions always need user confirmation
        if proposal.action.is_irreversible:
            logger.info(
                "PolicyEngine: ASK_USER — action '%s' is irreversible",
                proposal.action.action_type,
            )
            return PolicyDecision.ASK_USER

        # ── Primary AI too uncertain → ask user ───────────────────────────────
        if pai_conf < PAI_LOW_THRESHOLD:
            logger.info(
                "PolicyEngine: ASK_USER — PAI confidence %.2f below threshold %.2f",
                pai_conf, PAI_LOW_THRESHOLD,
            )
            return PolicyDecision.ASK_USER

        # ── Both AIs approve with high confidence → execute ───────────────────
        if (
            pai_conf >= PAI_HIGH_CONFIDENCE
            and vai_conf >= VAI_HIGH_CONFIDENCE
            and verdict == Verdict.APPROVE
        ):
            logger.info("PolicyEngine: EXECUTE (high confidence both AIs)")
            return PolicyDecision.EXECUTE

        # Both AIs approve with medium confidence → execute
        if (
            pai_conf >= PAI_MEDIUM_CONFIDENCE
            and vai_conf >= VAI_MEDIUM_CONFIDENCE
            and verdict == Verdict.APPROVE
        ):
            logger.info("PolicyEngine: EXECUTE (medium confidence both AIs)")
            return PolicyDecision.EXECUTE

        # ── Verifier rejects with high confidence but PAI medium → reconsider ─
        if (
            pai_conf >= PAI_MEDIUM_CONFIDENCE
            and vai_conf < VAI_REJECT_THRESHOLD
            and verdict == Verdict.REJECT
        ):
            logger.info(
                "PolicyEngine: RECONSIDER — PAI=%.2f but VAI rejects (%.2f)",
                pai_conf, vai_conf,
            )
            return PolicyDecision.RECONSIDER

        # ── Both medium-high but disagreeing ─────────────────────────────────
        if (
            pai_conf >= PAI_MEDIUM_CONFIDENCE
            and vai_conf >= VAI_MEDIUM_CONFIDENCE
            and verdict == Verdict.REJECT
        ):
            if reconsidered < 1:
                logger.info("PolicyEngine: RECONSIDER — both medium conf but disagree")
                return PolicyDecision.RECONSIDER
            else:
                logger.info("PolicyEngine: ASK_USER — persisting disagreement after reconsider")
                return PolicyDecision.ASK_USER

        # ── Fallback ─────────────────────────────────────────────────────────
        # When we get here: unclear situation → ask user
        logger.info(
            "PolicyEngine: ASK_USER — unresolved case (PAI=%.2f VAI=%.2f verdict=%s)",
            pai_conf, vai_conf, verdict.value,
        )
        return PolicyDecision.ASK_USER
