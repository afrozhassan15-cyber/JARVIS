"""
ai/primary_ai.py

Primary AI — proposes structured actions for each task step.
Uses IBM watsonx.ai (granite-3-8b-instruct) via WatsonxAIClient.
"""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Optional

from ai.action_schema import Action, ActionProposal
from ai.watsonx_client import WatsonxAIClient
from core.context_manager import ContextManager
from tasks.task import TaskStep

logger = logging.getLogger(__name__)

_PROMPT_DIR = Path(__file__).parent / "prompts"


class PrimaryAI:
    """
    The reasoning brain that proposes actions.

    Given a task step + context, produces an ActionProposal with:
    - A structured Action (action_type + parameters)
    - Chain-of-thought reasoning
    - Confidence score (0.0–1.0)
    """

    def __init__(
        self,
        client: WatsonxAIClient,
        context_manager: Optional[ContextManager] = None,
    ) -> None:
        self._client  = client
        self._ctx     = context_manager
        self._system_prompt = self._load_prompt("primary_system_prompt.txt")

    def propose_action(
        self,
        step: TaskStep,
        world_state_text: str = "",
    ) -> ActionProposal:
        """
        Propose the best action for the given task step.

        Args:
            step:             the current TaskStep
            world_state_text: text extracted from the last screen capture

        Returns:
            ActionProposal with action, reasoning, and confidence
        """
        user_message = self._build_user_message(step, world_state_text)
        messages = [
            {"role": "system", "content": self._system_prompt},
            {"role": "user",   "content": user_message},
        ]

        raw = self._client.chat(messages)
        logger.debug("PrimaryAI raw response: %s", raw[:300])
        return self._parse_proposal(raw, step.id)

    def revise_action(
        self,
        step: TaskStep,
        original_proposal: ActionProposal,
        verifier_feedback: str,
        world_state_text: str = "",
    ) -> ActionProposal:
        """
        Revise a proposal after the Verifier AI rejected it.

        The Primary AI is shown:
        1. The original proposal it made
        2. The verifier's specific objection
        It must produce a different proposal.
        """
        user_message = (
            f"{self._build_user_message(step, world_state_text)}\n\n"
            f"IMPORTANT: Your previous proposal was REJECTED by the Verifier AI.\n"
            f"Original proposal: {original_proposal.action}\n"
            f"Verifier feedback: {verifier_feedback}\n\n"
            f"Please reconsider and propose a DIFFERENT action that avoids the flagged risk."
        )
        messages = [
            {"role": "system", "content": self._system_prompt},
            {"role": "user",   "content": user_message},
        ]

        raw = self._client.chat(messages)
        logger.debug("PrimaryAI revision raw response: %s", raw[:300])
        proposal = self._parse_proposal(raw, step.id)
        proposal.reconsider_count = original_proposal.reconsider_count + 1
        return proposal

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_user_message(self, step: TaskStep, world_state_text: str) -> str:
        parts = [f"Task step: {step.description}"]
        if step.action_type:
            parts.append(f"Expected action type: {step.action_type}")
        if step.expected_outcome:
            parts.append(f"Expected outcome: {step.expected_outcome}")
        if world_state_text:
            truncated = world_state_text[:500]
            parts.append(f"Current screen state:\n{truncated}")
        return "\n".join(parts)

    def _parse_proposal(self, raw: str, step_id: str) -> ActionProposal:
        data = self._extract_json(raw)
        action = Action(
            action_type=data.get("action_type", "converse"),
            parameters=data.get("parameters", {}),
            is_irreversible=bool(data.get("is_irreversible", False)),
            description=data.get("reasoning", "")[:100],
        )
        return ActionProposal(
            action=action,
            reasoning=data.get("reasoning", "No reasoning provided."),
            confidence=float(data.get("confidence", 0.5)),
            step_id=step_id,
        )

    @staticmethod
    def _extract_json(text: str) -> dict:
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass
        logger.warning("PrimaryAI: could not extract JSON from response.")
        return {}

    @staticmethod
    def _load_prompt(filename: str) -> str:
        path = _PROMPT_DIR / filename
        if path.exists():
            return path.read_text(encoding="utf-8")
        logger.warning("Prompt file not found: %s", path)
        return ""
