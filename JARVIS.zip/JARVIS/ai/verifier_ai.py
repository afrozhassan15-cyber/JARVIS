"""
ai/verifier_ai.py

Verifier AI — independently evaluates every proposed action.
Uses the same watsonx.ai client but with a completely different system prompt and persona.

The Verifier NEVER sees the Primary AI's reasoning — only the proposed action itself.
This information asymmetry is what makes the verification meaningful.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path

from ai.action_schema import ActionProposal, Verdict, VerifierResult
from ai.watsonx_client import WatsonxAIClient
from tasks.task import TaskStep

logger = logging.getLogger(__name__)

_PROMPT_DIR = Path(__file__).parent / "prompts"


class VerifierAI:
    """
    The independent critic that evaluates ActionProposals.

    Deliberately given a different persona from PrimaryAI:
    - skeptical, conservative, safety-first
    - sees only the proposed ACTION, not the Primary AI's reasoning
    """

    def __init__(self, client: WatsonxAIClient) -> None:
        self._client = client
        self._system_prompt = self._load_prompt("verifier_system_prompt.txt")

    def evaluate(
        self,
        proposal: ActionProposal,
        step: TaskStep,
        world_state_text: str = "",
    ) -> VerifierResult:
        """
        Evaluate an ActionProposal independently.

        Note: only the action is passed — NOT proposal.reasoning.
        This preserves the independence of the evaluation.
        """
        user_message = self._build_eval_message(proposal, step, world_state_text)
        messages = [
            {"role": "system", "content": self._system_prompt},
            {"role": "user",   "content": user_message},
        ]

        raw = self._client.chat(messages)
        logger.debug("VerifierAI raw response: %s", raw[:300])
        return self._parse_result(raw)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_eval_message(
        self,
        proposal: ActionProposal,
        step: TaskStep,
        world_state_text: str,
    ) -> str:
        parts = [
            f"Task step that must be completed: {step.description}",
            f"Expected outcome: {step.expected_outcome}",
            f"Step action type hint: {step.action_type}",
            f"",
            f"Proposed action to evaluate:",
            f"  action_type: {proposal.action.action_type}",
            f"  parameters: {json.dumps(proposal.action.parameters)}",
            f"  is_irreversible: {proposal.action.is_irreversible}",
        ]
        if world_state_text:
            parts.append(f"\nCurrent screen state:\n{world_state_text[:400]}")
        parts.append("\nEvaluate this action. Should it be APPROVED or REJECTED?")
        return "\n".join(parts)

    def _parse_result(self, raw: str) -> VerifierResult:
        data = self._extract_json(raw)
        verdict_str = data.get("verdict", "REJECT").upper()
        try:
            verdict = Verdict(verdict_str)
        except ValueError:
            verdict = Verdict.REJECT

        return VerifierResult(
            verdict=verdict,
            confidence=float(data.get("confidence", 0.5)),
            risks=data.get("risks", []),
            suggested_correction=data.get("suggested_correction"),
            explanation=data.get("explanation", ""),
        )

    @staticmethod
    def _extract_json(text: str) -> dict:
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass
        logger.warning("VerifierAI: could not extract JSON from response.")
        return {}

    @staticmethod
    def _load_prompt(filename: str) -> str:
        path = _PROMPT_DIR / filename
        if path.exists():
            return path.read_text(encoding="utf-8")
        logger.warning("Prompt file not found: %s", path)
        return ""
