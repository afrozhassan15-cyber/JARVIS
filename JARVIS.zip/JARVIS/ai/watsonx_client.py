"""
ai/watsonx_client.py

Thin wrapper around the ibm-watsonx-ai SDK.
All watsonx.ai API calls go through this class.
Falls back gracefully when credentials are not configured.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)


class WatsonxAIClient:
    """
    Wraps ibm-watsonx-ai ModelInference.chat() for JARVIS.

    If watsonx.ai is not configured (no API key), the client operates in
    MOCK mode and returns deterministic stub responses for offline testing.
    """

    def __init__(
        self,
        api_key: str = "",
        project_id: str = "",
        url: str = "https://us-south.ml.cloud.ibm.com",
        model_id: str = "ibm/granite-3-8b-instruct",
        max_tokens: int = 1024,
        temperature: float = 0.2,
    ) -> None:
        self._api_key    = api_key
        self._project_id = project_id
        self._url        = url
        self._model_id   = model_id
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._model: Optional[object] = None
        self._mock_mode  = not (api_key and project_id)

        if not self._mock_mode:
            self._initialise_model()
        else:
            logger.warning(
                "WatsonxAIClient: no credentials — running in MOCK mode. "
                "Set WATSONX_API_KEY and WATSONX_PROJECT_ID in .env for real inference."
            )

    def _initialise_model(self) -> None:
        try:
            from ibm_watsonx_ai import Credentials
            from ibm_watsonx_ai.foundation_models import ModelInference

            credentials = Credentials(api_key=self._api_key, url=self._url)
            self._model = ModelInference(
                model_id=self._model_id,
                credentials=credentials,
                project_id=self._project_id,
                params={
                    "max_new_tokens": self._max_tokens,
                    "temperature": self._temperature,
                },
            )
            logger.info("WatsonxAIClient initialised with model %s", self._model_id)
        except ImportError:
            logger.warning("ibm-watsonx-ai not installed — falling back to mock mode.")
            self._mock_mode = True
        except Exception as exc:
            logger.error("WatsonxAIClient init failed: %s — using mock mode.", exc)
            self._mock_mode = True

    @property
    def is_mock(self) -> bool:
        return self._mock_mode

    def chat(self, messages: list[dict], system_prompt: str = "") -> str:
        """
        Send a chat request and return the assistant's reply as a string.

        Args:
            messages:     list of {"role": ..., "content": ...} dicts
            system_prompt: optional override for system prompt
        """
        if self._mock_mode:
            return self._mock_response(messages)

        try:
            formatted = list(messages)
            if system_prompt:
                # Insert or replace system message at index 0
                if formatted and formatted[0].get("role") == "system":
                    formatted[0] = {"role": "system", "content": system_prompt}
                else:
                    formatted.insert(0, {"role": "system", "content": system_prompt})

            response = self._model.chat(messages=formatted)  # type: ignore[union-attr]
            # watsonx.ai SDK returns a dict with choices[0].message.content
            if isinstance(response, dict):
                choices = response.get("choices", [])
                if choices:
                    return choices[0].get("message", {}).get("content", "")
            return str(response)
        except Exception as exc:
            logger.error("WatsonxAIClient.chat() error: %s", exc, exc_info=True)
            return self._mock_response(messages)

    # ── Mock responses for offline/testing use ────────────────────────────────

    def _mock_response(self, messages: list[dict]) -> str:
        """
        Return a deterministic stub response based on the last user message.
        Allows the full pipeline to run without IBM credentials.

        Condition ordering is deliberate: more-specific prompts are matched
        before broader ones so that no stub fires for the wrong caller.
        """
        last_content = ""
        for m in reversed(messages):
            if m.get("role") == "user":
                last_content = m.get("content", "").lower()
                break

        system_content = ""
        if messages and messages[0].get("role") == "system":
            system_content = messages[0].get("content", "").lower()

        # ── 1. Planning (Planner) ──────────────────────────────────────────────
        # Matched by unique words "decompose" or "task planner" in the planner
        # system prompt; "plan" alone is too common so we also require "decompose"
        # or "task planner" to avoid false positives.
        if "decompose" in system_content or "task planner" in system_content:
            return json.dumps({
                "steps": [
                    {
                        "id": "s1",
                        "description": "Open the requested application",
                        "action_type": "open_application",
                        "expected_outcome": "Application window is visible",
                        "precondition": "",
                        "fallback": "Try alternative launch method"
                    },
                    {
                        "id": "s2",
                        "description": "Perform the requested action",
                        "action_type": "type_text",
                        "expected_outcome": "Text appears in the application",
                        "precondition": "Application is open",
                        "fallback": "Click text area first then try clicking the text area"
                    }
                ]
            })

        # ── 2. Language classification (LanguageParser) ────────────────────────
        # Must come before Primary AI stub because the LanguageParser prompt
        # contains the word "action" (in "computer action"), which would
        # otherwise trigger the Primary AI branch.
        if "classif" in system_content or "input_type" in system_content:
            _TASK_KW = {"open", "launch", "type", "click", "search", "find",
                        "navigate", "delete", "copy", "move", "create", "close",
                        "run", "execute", "write", "save", "send", "download",
                        "install", "start", "go to", "switch"}
            _MULTI_KW = {"and then", "then", "after that", "also", "finally",
                         "first", "next", "and also"}
            _QUESTION_START = {"what", "who", "where", "when", "why", "how",
                                "is ", "are ", "can ", "could ", "would ",
                                "should ", "tell me", "explain"}
            has_task_kw = any(kw in last_content for kw in _TASK_KW)
            has_multi_kw = any(kw in last_content for kw in _MULTI_KW)
            comma_count = last_content.count(",")
            if has_task_kw:
                input_type = "MULTI_STEP_TASK" if (has_multi_kw or comma_count >= 1) else "COMPUTER_TASK"
            elif "?" in last_content or any(last_content.startswith(q) for q in _QUESTION_START):
                input_type = "QUESTION"
            else:
                input_type = "CONVERSATION"
            return json.dumps({
                "input_type": input_type,
                "intent": last_content[:80],
                "entities": {},
                "confidence": 0.80,
                "is_urgent": False
            })

        # ── 3. Step verification (StepVerifier) ───────────────────────────────
        # Keep this check narrow so the verifier prompt is not mistaken for a
        # step-verification call.
        if "step verification" in system_content or (
                "step verifier" in system_content and
                "expected outcome" in system_content and
                "passed" in system_content):
            return json.dumps({
                "passed": True,
                "confidence": 0.80,
                "explanation": "Expected outcome appears to match observation.",
                "error_type": "none"
            })

        # ── 4. Verifier AI (VerifierAI) ───────────────────────────────────────
        if "verif" in system_content or "critic" in system_content or \
                "independent" in system_content:
            # Smarter stub: reject converse action when step is a computer task
            # Parse action_type from the user message
            proposed_action = ""
            step_action_hint = ""
            for line in last_content.splitlines():
                if line.strip().lower().startswith("action_type:"):
                    proposed_action = line.split(":", 1)[-1].strip().lower()
                if "action_type hint" in line.lower() or "step action type" in line.lower():
                    step_action_hint = line.split(":", 1)[-1].strip().lower()
            # If the proposal is 'converse' but the step hints at a computer action
            _computer_actions = {
                "open_application", "type_text", "press_key", "click",
                "scroll", "close_application", "switch_application",
                "focus_application", "take_screenshot", "read_screen",
            }
            if proposed_action == "converse" and step_action_hint in _computer_actions:
                return json.dumps({
                    "verdict": "REJECT",
                    "confidence": 0.78,
                    "risks": ["wrong_action_type"],
                    "explanation": "Converse action proposed for a computer task step.",
                    "suggested_correction": (
                        f"Use '{step_action_hint}' instead of 'converse'."
                    ),
                })
            return json.dumps({
                "verdict": "APPROVE",
                "confidence": 0.82,
                "risks": [],
                "explanation": "Action appears correct and safe.",
                "suggested_correction": None
            })

        # ── 5. Primary AI action proposal (PrimaryAI) ─────────────────────────
        # Matched by "propose" (in "PROPOSE the best next action") which appears
        # only in the primary system prompt, not in any other prompt.
        if "propose" in system_content:
            # Derive action from the step description in last_content
            if "type" in last_content or "write" in last_content:
                action_type = "type_text"
                # Do not invent a demo string for typing actions. If no actual
                # text is provided by the task, leave it empty rather than
                # injecting a hardcoded value.
                parameters  = {"text": ""}
            elif "search" in last_content:
                action_type = "search_web"
                parameters  = {"query": last_content[:60]}
            elif "navigate" in last_content or "url" in last_content or "http" in last_content:
                action_type = "navigate_url"
                parameters  = {"url": "https://example.com"}
            elif "click" in last_content:
                action_type = "click"
                parameters  = {"target": "button"}
            elif "open" in last_content or "launch" in last_content or "start" in last_content:
                action_type = "open_application"
                # Extract a plausible app name from the step description
                words = [w for w in last_content.split() if w not in
                         {"open", "launch", "start", "the", "application", "app"}]
                parameters  = {"name": words[0] if words else "application"}
            elif "read" in last_content or "screen" in last_content:
                action_type = "read_screen"
                parameters  = {}
            elif "close" in last_content:
                action_type = "close_application"
                words = [w for w in last_content.split() if w not in
                         {"close", "the", "application", "app"}]
                parameters  = {"name": words[0] if words else "application"}
            else:
                # Genuinely unknown step → converse rather than guess Notepad
                action_type = "converse"
                parameters  = {"message": f"I will: {last_content[:80]}"}
            return json.dumps({
                "action_type": action_type,
                "parameters": parameters,
                "reasoning": "This is the most direct way to complete the step.",
                "confidence": 0.85,
                "is_irreversible": False
            })

        # ── 6. Conversational / personality response (ResponseGenerator) ───────
        if "personality" in system_content or "jarvis" in system_content:
            # Synthesis call: user message contains web search results
            if "web search results" in last_content or "the user asked:" in last_content:
                lines = last_content.splitlines()
                query_line = lines[0] if lines else ""
                query = query_line.replace("the user asked:", "").strip()[:80]
                return (
                    f"Based on my search, here's what I found about {query}: "
                    "the results indicate this is a topic with several relevant sources "
                    "providing useful information."
                )
            # Return a contextually appropriate reply instead of a fixed string
            if "?" in last_content:
                return "That's a great question. Here's what I know: " + last_content[:80]
            if any(w in last_content for w in ["hello", "hi", "hey", "good morning",
                                                "good evening", "good afternoon"]):
                return "Hello! How can I help you today?"
            if any(w in last_content for w in ["who are you", "what are you",
                                                "who made you"]):
                return ("I'm JARVIS, your personal AI desktop assistant. "
                        "I can help you control your computer, answer questions, "
                        "and carry out tasks.")
            return f"Understood. I'll help with: {last_content[:80]}"

        # ── 7. Default fallback ───────────────────────────────────────────────
        return f"I understand you want to: {last_content[:100]}"
