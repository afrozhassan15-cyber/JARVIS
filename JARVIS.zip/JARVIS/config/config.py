"""
config/config.py

Central configuration for JARVIS.  All values are loaded from the .env file.
No secrets are ever hard-coded here.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from dotenv import load_dotenv

load_dotenv()  # load .env into os.environ if present


@dataclass
class WatsonSTTConfig:
    api_key: str = field(default_factory=lambda: os.getenv("WATSON_STT_API_KEY", ""))
    url: str = field(
        default_factory=lambda: os.getenv(
            "WATSON_STT_URL",
            "https://api.us-south.speech-to-text.watson.cloud.ibm.com",
        )
    )

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key and self.api_key != "your_watson_stt_api_key_here")


@dataclass
class WatsonTTSConfig:
    api_key: str = field(default_factory=lambda: os.getenv("WATSON_TTS_API_KEY", ""))
    url: str = field(
        default_factory=lambda: os.getenv(
            "WATSON_TTS_URL",
            "https://api.us-south.text-to-speech.watson.cloud.ibm.com",
        )
    )
    voice: str = "en-US_AllisonV3Voice"

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key and self.api_key != "your_watson_tts_api_key_here")


@dataclass
class WatsonxAIConfig:
    api_key: str = field(default_factory=lambda: os.getenv("WATSONX_API_KEY", ""))
    project_id: str = field(
        default_factory=lambda: os.getenv("WATSONX_PROJECT_ID", "")
    )
    url: str = field(
        default_factory=lambda: os.getenv(
            "WATSONX_URL", "https://us-south.ml.cloud.ibm.com"
        )
    )
    model_id: str = "ibm/granite-3-8b-instruct"
    max_tokens: int = 1024
    temperature: float = 0.2

    @property
    def is_configured(self) -> bool:
        return bool(
            self.api_key
            and self.api_key != "your_watsonx_api_key_here"
            and self.project_id
        )


@dataclass
class AppConfig:
    """Top-level application configuration."""

    # IBM services
    stt: WatsonSTTConfig = field(default_factory=WatsonSTTConfig)
    tts: WatsonTTSConfig = field(default_factory=WatsonTTSConfig)
    watsonx: WatsonxAIConfig = field(default_factory=WatsonxAIConfig)

    # Picovoice (wake word)
    picovoice_access_key: str = field(
        default_factory=lambda: os.getenv("PICOVOICE_ACCESS_KEY", "")
    )

    # Task engine limits
    max_retries: int = field(
        default_factory=lambda: int(os.getenv("JARVIS_MAX_RETRIES", "3"))
    )
    max_replans: int = field(
        default_factory=lambda: int(os.getenv("JARVIS_MAX_REPLANS", "2"))
    )
    status_interval_seconds: int = field(
        default_factory=lambda: int(os.getenv("JARVIS_STATUS_INTERVAL_SECONDS", "15"))
    )

    # Logging
    log_level: str = field(
        default_factory=lambda: os.getenv("JARVIS_LOG_LEVEL", "INFO")
    )

    # GUI
    window_title: str = "JARVIS — Personal AI Assistant"
    window_width: int = 900
    window_height: int = 650

    @property
    def has_ibm_voice(self) -> bool:
        return self.stt.is_configured and self.tts.is_configured

    @property
    def has_watsonx(self) -> bool:
        return self.watsonx.is_configured

    @property
    def has_wake_word(self) -> bool:
        return bool(
            self.picovoice_access_key
            and self.picovoice_access_key != "your_picovoice_access_key_here"
        )


# Module-level singleton — import this everywhere
config = AppConfig()
