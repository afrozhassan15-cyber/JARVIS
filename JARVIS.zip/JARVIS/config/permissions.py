"""
config/permissions.py

Permission definitions and action safety levels for the JARVIS safety layer.
"""

from __future__ import annotations
from enum import Enum


class SafetyLevel(str, Enum):
    """Safety classification for every action type."""
    SAFE = "SAFE"                        # Auto-execute, no confirmation needed
    CONFIRM_REQUIRED = "CONFIRM_REQUIRED"  # Ask user once before executing
    ELEVATED_CONFIRM = "ELEVATED_CONFIRM"  # Ask user twice; must say "yes"
    BLOCKED = "BLOCKED"                  # Never execute, explain and refuse


class PermissionResult(str, Enum):
    ALLOW = "ALLOW"
    REQUIRE_CONFIRMATION = "REQUIRE_CONFIRMATION"
    BLOCK = "BLOCK"


# ── Action type → safety level mapping ───────────────────────────────────────
ACTION_SAFETY_MAP: dict[str, SafetyLevel] = {
    # SAFE — reversible, read-only, low-risk
    "open_application":   SafetyLevel.SAFE,
    "close_application":  SafetyLevel.SAFE,     # reversible — user can reopen
    "switch_application": SafetyLevel.SAFE,
    "focus_application":  SafetyLevel.SAFE,
    "take_screenshot":    SafetyLevel.SAFE,
    "read_screen":        SafetyLevel.SAFE,
    "get_window_title":   SafetyLevel.SAFE,
    "type_text":          SafetyLevel.SAFE,
    "press_key":          SafetyLevel.SAFE,
    "click":              SafetyLevel.SAFE,
    "scroll":             SafetyLevel.SAFE,
    "search_web":         SafetyLevel.SAFE,
    "navigate_url":       SafetyLevel.SAFE,
    "read_file":          SafetyLevel.SAFE,
    "converse":           SafetyLevel.SAFE,

    # CONFIRM_REQUIRED — irreversible or external-facing
    "delete_file":   SafetyLevel.CONFIRM_REQUIRED,
    "send_email":    SafetyLevel.CONFIRM_REQUIRED,
    "submit_form":   SafetyLevel.CONFIRM_REQUIRED,
    "write_file":    SafetyLevel.CONFIRM_REQUIRED,

    # ELEVATED_CONFIRM — system-level, destructive
    "modify_system_settings": SafetyLevel.ELEVATED_CONFIRM,
    "uninstall_application": SafetyLevel.ELEVATED_CONFIRM,
    "modify_registry": SafetyLevel.ELEVATED_CONFIRM,

    # BLOCKED — never execute
    "access_credentials": SafetyLevel.BLOCKED,
    "execute_script": SafetyLevel.BLOCKED,
    "disable_security": SafetyLevel.BLOCKED,
}

# Action types that are always considered irreversible
IRREVERSIBLE_ACTION_TYPES: frozenset[str] = frozenset({
    "delete_file",
    "send_email",
    "submit_form",
    "modify_system_settings",
    "modify_registry",
    "uninstall_application",
})

# Path prefix restrictions — JARVIS will not operate outside user home dir by default
import os
ALLOWED_PATH_PREFIXES: list[str] = [
    os.path.expanduser("~"),
    os.path.join(os.environ.get("TEMP", "C:\\Temp")),
]
