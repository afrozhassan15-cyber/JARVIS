"""
config/thresholds.py

Confidence thresholds and policy constants used by the Verification Policy Engine.
All values are centralised here so they can be tuned in one place.
"""

from __future__ import annotations

# ── Primary AI execute thresholds ─────────────────────────────────────────────
# Both PAI and VAI must meet or exceed these for automatic EXECUTE.
PAI_HIGH_CONFIDENCE = 0.80
VAI_HIGH_CONFIDENCE = 0.75

PAI_MEDIUM_CONFIDENCE = 0.70
VAI_MEDIUM_CONFIDENCE = 0.70

# Below this PAI threshold → always ASK_USER regardless of VAI
PAI_LOW_THRESHOLD = 0.50

# ── Verifier reject sensitivity ───────────────────────────────────────────────
# VAI below this when PAI is medium → RECONSIDER
VAI_REJECT_THRESHOLD = 0.50

# ── Reconsideration limits ────────────────────────────────────────────────────
MAX_RECONSIDER_CYCLES = 3      # After this many cycles → ESCALATE

# ── Irreversible action ceiling ───────────────────────────────────────────────
# Irreversible actions always require user confirmation regardless of scores.
IRREVERSIBLE_CONFIDENCE_CEILING = 0.75

# ── Step execution limits ─────────────────────────────────────────────────────
MAX_STEP_RETRIES = 3           # Per step — after this → escalate to user
MAX_TASK_REPLANS = 2           # Per task — after this → FAILED
MAX_STEP_DURATION_SECONDS = 60 # Step timeout

# ── Step verifier pass threshold ─────────────────────────────────────────────
STEP_VERIFICATION_PASS_THRESHOLD = 0.65
