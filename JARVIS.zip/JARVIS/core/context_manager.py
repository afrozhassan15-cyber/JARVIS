"""
core/context_manager.py

Shared, thread-safe context store for the entire JARVIS session.
Holds: conversation history, active task state, last world observation.

All components that need shared state read from / write to this store.
No business logic lives here — it is a pure data store.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional


@dataclass
class ConversationTurn:
    role: str       # "user" | "jarvis" | "system"
    content: str
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class WorldState:
    """Snapshot of the observable computer state after an action."""
    screenshot_path: str = ""
    visible_text: str = ""
    window_title: str = ""
    active_app: str = ""
    captured_at: datetime = field(default_factory=datetime.now)


@dataclass
class TaskContext:
    """Serialisable state of an in-progress task."""
    task_id: str = ""
    goal: str = ""
    current_step_index: int = 0
    completed_step_ids: list[str] = field(default_factory=list)
    retry_counts: dict[str, int] = field(default_factory=dict)
    replan_count: int = 0
    last_world_state: Optional[WorldState] = None
    ai_history: list[dict] = field(default_factory=list)  # watsonx.ai message history


class ContextManager:
    """
    Thread-safe shared context store.

    Components call:
        ctx.add_turn("user", "open notepad")
        ctx.update_world_state(world_state)
        ctx.set_task_context(task_ctx)
    """

    def __init__(self, max_history: int = 20) -> None:
        self._lock = threading.RLock()
        self._max_history = max_history
        self._conversation: list[ConversationTurn] = []
        self._world_state: WorldState = WorldState()
        self._task_context: Optional[TaskContext] = None
        self._metadata: dict[str, Any] = {}

    # ── Conversation ──────────────────────────────────────────────────────────

    def add_turn(self, role: str, content: str) -> None:
        """Append a turn to the conversation history."""
        with self._lock:
            self._conversation.append(ConversationTurn(role=role, content=content))
            # Keep only the last N turns to control context window size
            if len(self._conversation) > self._max_history:
                self._conversation = self._conversation[-self._max_history:]

    def get_conversation_history(self) -> list[ConversationTurn]:
        """Return a copy of the conversation history."""
        with self._lock:
            return list(self._conversation)

    def get_history_as_messages(self) -> list[dict]:
        """Return history formatted for watsonx.ai chat API."""
        with self._lock:
            return [
                {"role": t.role if t.role != "jarvis" else "assistant",
                 "content": t.content}
                for t in self._conversation
            ]

    def clear_conversation(self) -> None:
        with self._lock:
            self._conversation.clear()

    # ── World state ───────────────────────────────────────────────────────────

    def update_world_state(self, state: WorldState) -> None:
        with self._lock:
            self._world_state = state

    def get_world_state(self) -> WorldState:
        with self._lock:
            return self._world_state

    # ── Task context ──────────────────────────────────────────────────────────

    def set_task_context(self, ctx: Optional[TaskContext]) -> None:
        with self._lock:
            self._task_context = ctx

    def get_task_context(self) -> Optional[TaskContext]:
        with self._lock:
            return self._task_context

    # ── Generic metadata ──────────────────────────────────────────────────────

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            self._metadata[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._metadata.get(key, default)


# Module-level singleton
context_manager = ContextManager()
