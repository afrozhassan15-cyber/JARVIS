"""
core/event_bus.py

Thread-safe publish/subscribe event bus.
All cross-layer communication in JARVIS goes through this bus.
Components never import each other directly — they publish and subscribe.
"""

from __future__ import annotations

import logging
import threading
from collections import defaultdict
from typing import Any, Callable

logger = logging.getLogger(__name__)

# ── Event type constants ──────────────────────────────────────────────────────
# Define all event type strings here so there are no magic strings elsewhere.

class EventType:
    # Voice
    WAKE_WORD_DETECTED = "wake_word_detected"
    TRANSCRIPT_READY   = "transcript_ready"
    SPEAKING_STARTED   = "speaking_started"
    SPEAKING_FINISHED  = "speaking_finished"

    # Understanding
    INPUT_PARSED       = "input_parsed"

    # Task lifecycle
    TASK_CREATED       = "task_created"
    TASK_ACTIVATED     = "task_activated"
    TASK_PAUSED        = "task_paused"
    TASK_RESUMED       = "task_resumed"
    TASK_COMPLETED     = "task_completed"
    TASK_FAILED        = "task_failed"
    TASK_CANCELLED     = "task_cancelled"
    STEP_STARTED       = "step_started"
    STEP_COMPLETED     = "step_completed"
    STEP_FAILED        = "step_failed"

    # AI verification
    ACTION_PROPOSED    = "action_proposed"
    ACTION_APPROVED    = "action_approved"
    ACTION_REJECTED    = "action_rejected"
    CONFIRMATION_NEEDED = "confirmation_needed"
    CONFIRMATION_RECEIVED = "confirmation_received"

    # Execution
    ACTION_EXECUTED    = "action_executed"
    OBSERVATION_READY  = "observation_ready"

    # GUI updates
    GUI_LOG_MESSAGE    = "gui_log_message"
    GUI_STATUS_UPDATE  = "gui_status_update"
    GUI_TASK_UPDATE    = "gui_task_update"

    # System
    EMERGENCY_STOP     = "emergency_stop"
    SYSTEM_READY       = "system_ready"
    SYSTEM_ERROR       = "system_error"


class EventBus:
    """
    Thread-safe publish/subscribe message bus.

    Usage:
        bus = EventBus()
        bus.subscribe(EventType.TRANSCRIPT_READY, my_handler)
        bus.publish(EventType.TRANSCRIPT_READY, {"text": "hello"})

    Handlers are called on the thread that calls publish().
    For cross-thread delivery, use publish_threadsafe() which queues
    delivery to the main thread.
    """

    def __init__(self) -> None:
        self._subscribers: dict[str, list[Callable]] = defaultdict(list)
        self._lock = threading.Lock()

    def subscribe(self, event_type: str, handler: Callable[[Any], None]) -> None:
        """Register a handler for an event type."""
        with self._lock:
            self._subscribers[event_type].append(handler)
        logger.debug("Subscribed %s to event '%s'", handler.__qualname__, event_type)

    def unsubscribe(self, event_type: str, handler: Callable[[Any], None]) -> None:
        """Remove a handler for an event type."""
        with self._lock:
            handlers = self._subscribers.get(event_type, [])
            if handler in handlers:
                handlers.remove(handler)

    def publish(self, event_type: str, payload: Any = None) -> None:
        """
        Publish an event to all registered subscribers.
        Handlers are called synchronously on the calling thread.
        Exceptions in handlers are caught and logged so one bad handler
        cannot prevent others from receiving the event.
        """
        with self._lock:
            handlers = list(self._subscribers.get(event_type, []))

        for handler in handlers:
            try:
                handler(payload)
            except Exception as exc:
                logger.error(
                    "Handler %s raised an exception for event '%s': %s",
                    handler.__qualname__,
                    event_type,
                    exc,
                    exc_info=True,
                )

    def publish_async(self, event_type: str, payload: Any = None) -> None:
        """
        Publish an event on a new daemon thread.
        Use this when the caller must not block (e.g. voice thread → GUI).
        """
        t = threading.Thread(
            target=self.publish,
            args=(event_type, payload),
            daemon=True,
        )
        t.start()

    def clear(self) -> None:
        """Remove all subscribers. Useful in tests."""
        with self._lock:
            self._subscribers.clear()


# Module-level singleton — import this everywhere
event_bus = EventBus()
