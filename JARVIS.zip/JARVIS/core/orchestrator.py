"""
core/orchestrator.py

Top-level coordinator for JARVIS.
Owns the main execution loop: Voice → Understanding → Planning → AI Verification → Tool → Observe → Verify → Respond.
"""

from __future__ import annotations

import concurrent.futures
import logging
import threading
import time
from typing import Optional

from ai.action_schema import Action, PolicyDecision, VerificationResult
from ai.policy_engine import VerificationPolicyEngine
from ai.primary_ai import PrimaryAI
from ai.verifier_ai import VerifierAI
from ai.watsonx_client import WatsonxAIClient
from config.config import AppConfig
from config.permissions import PermissionResult
from config.thresholds import MAX_STEP_RETRIES, MAX_TASK_REPLANS, MAX_STEP_DURATION_SECONDS
from core.context_manager import ContextManager, TaskContext
from core.event_bus import EventBus, EventType
from observation.error_handler import ErrorHandler, RecoveryStrategy
from observation.observer import Observer
from observation.step_verifier import StepVerifier
from response.response_generator import ResponseGenerator
from response.personality import MessageType
from safety.permission_checker import PermissionChecker
from tasks.planner import Planner
from tasks.task import Task, TaskPriority, TaskStatus, TaskStep
from tasks.task_manager import TaskManager
from tools.tool_registry import ToolRegistry
from understanding.input_types import InputType, ParsedInput
from understanding.language_parser import LanguageParser
from voice.text_to_speech import TextToSpeech

logger = logging.getLogger(__name__)


class Orchestrator:
    """
    Receives user input (text or voice transcript), routes it, and drives the
    complete PLAN → VERIFY → EXECUTE → OBSERVE → VERIFY loop.

    All heavy work runs on a background thread; the main thread is reserved for the GUI.
    """

    def __init__(
        self,
        config: AppConfig,
        event_bus: EventBus,
        context_manager: ContextManager,
    ) -> None:
        self._cfg     = config
        self._bus     = event_bus
        self._ctx     = context_manager
        self._running = False

        # Initialise watsonx.ai client (shared by all AI components)
        self._watsonx = WatsonxAIClient(
            api_key=config.watsonx.api_key,
            project_id=config.watsonx.project_id,
            url=config.watsonx.url,
            model_id=config.watsonx.model_id,
            max_tokens=config.watsonx.max_tokens,
            temperature=config.watsonx.temperature,
        )

        # AI components
        self._primary_ai  = PrimaryAI(self._watsonx, context_manager)
        self._verifier_ai = VerifierAI(self._watsonx)
        self._policy      = VerificationPolicyEngine()

        # Infrastructure
        self._lang_parser = LanguageParser(self._watsonx)
        self._planner     = Planner(self._watsonx)
        self._task_mgr    = TaskManager()
        self._observer    = Observer(context_manager)
        self._step_ver    = StepVerifier(self._watsonx)
        self._err_handler = ErrorHandler()
        self._perm_check  = PermissionChecker()
        self._response    = ResponseGenerator(self._watsonx)

        # Voice output
        self._tts = TextToSpeech(
            api_key=config.tts.api_key,
            url=config.tts.url,
            voice=config.tts.voice,
        )

        # Tool registry
        self._registry = ToolRegistry()
        self._register_tools()

        # Subscribe to events
        self._bus.subscribe(EventType.EMERGENCY_STOP, self._on_emergency_stop)
        self._bus.subscribe(EventType.CONFIRMATION_RECEIVED, self._on_confirmation)

    def _register_tools(self) -> None:
        from tools.computer_control.computer_tool import ComputerControlTool
        from tools.search.search_tool import WebSearchTool
        self._registry.register(ComputerControlTool())
        self._registry.register(WebSearchTool())
        logger.info("Tools registered: %s", self._registry.list_tools())

    # ── Public API ────────────────────────────────────────────────────────────

    def handle_input(self, text: str) -> None:
        """
        Entry point for user input (text typed OR voice transcript).
        Runs on a background thread — never on the GUI thread.
        """
        if not text.strip():
            return

        # Log user turn to context + GUI once here; _say() only logs JARVIS turns.
        self._ctx.add_turn("user", text)
        self._log_gui("user", text)
        self._set_voice_state("THINKING")

        try:
            parsed = self._lang_parser.parse(text)
            logger.info("Parsed: %s", parsed)
            self._route(parsed)
        except Exception as exc:
            logger.error("Orchestrator.handle_input error: %s", exc, exc_info=True)
            self._say("Sorry, I ran into an unexpected error. Please try again.")
        finally:
            self._set_voice_state("IDLE")

    def start(self) -> None:
        self._running = True
        logger.info("Orchestrator started.")
        self._bus.publish(EventType.SYSTEM_READY, {})
        self._say("JARVIS online. How can I help?")

    def stop(self) -> None:
        self._running = False
        self._task_mgr.cancel_all()
        logger.info("Orchestrator stopped.")

    # ── Routing ───────────────────────────────────────────────────────────────

    def _route(self, parsed: ParsedInput) -> None:
        active = self._task_mgr.get_active_task()

        if parsed.input_type == InputType.CANCEL:
            self._handle_cancel()
        elif parsed.input_type == InputType.RESUME:
            self._handle_resume()
        elif parsed.input_type == InputType.INTERRUPTION and active:
            self._handle_interruption(parsed)
        elif parsed.input_type == InputType.CONFIRMATION:
            self._task_mgr.provide_user_response(parsed.raw_text)
        elif parsed.input_type in (InputType.COMPUTER_TASK, InputType.MULTI_STEP_TASK):
            self._handle_task(parsed)
        elif parsed.input_type in (InputType.QUESTION, InputType.CONVERSATION):
            self._handle_conversation(parsed.raw_text)
        else:
            self._handle_conversation(parsed.raw_text)

    # ── Task handling ─────────────────────────────────────────────────────────

    def _handle_task(self, parsed: ParsedInput) -> None:
        task = self._task_mgr.create_task(parsed.intent or parsed.raw_text)
        self._task_mgr.activate_task(task.id)
        self._say(self._response.task_started())
        self._publish_task_update(task, "Planner building plan...")
        self._run_task(task)

    def _run_task(self, task: Task) -> None:
        """
        Main execution loop for a single task.
        PLAN → for each step: VERIFY → EXECUTE → OBSERVE → VERIFY → repeat
        """
        # Build the plan
        world = self._ctx.get_world_state()
        plan = self._planner.plan(task.goal, world.visible_text[:200])
        task.plan = plan

        logger.info("Task plan: %d steps for '%s'", len(plan.steps), task.goal)
        self._publish_task_update(task, f"Plan ready: {len(plan.steps)} steps")

        replan_count = 0

        while task.current_step_index < len(task.plan.steps):
            if task.status in (TaskStatus.CANCELLED, TaskStatus.PAUSED):
                self._observer.cleanup()
                return

            step = task.plan.steps[task.current_step_index]
            step_success = self._execute_step(task, step)

            if step_success:
                step.status = TaskStatus.COMPLETED
                task.current_step_index += 1
                self._say(self._response.generate(MessageType.STEP_COMPLETE))
                self._publish_task_update(task, task.progress_summary)
            else:
                # Decide retry vs replan vs fail
                if step.retry_count < MAX_STEP_RETRIES:
                    step.retry_count += 1
                    self._say(self._response.generate(MessageType.STEP_RETRY))
                    time.sleep(0.5)
                    continue
                elif replan_count < MAX_TASK_REPLANS:
                    replan_count += 1
                    completed = task.plan.steps[:task.current_step_index]
                    world = self._ctx.get_world_state()
                    new_plan = self._planner.replan(
                        task.goal, completed,
                        step.result_summary, world.visible_text[:200]
                    )
                    # Replace remaining steps with new plan
                    task.plan.steps = (
                        task.plan.steps[:task.current_step_index] + new_plan.steps
                    )
                    logger.info("Replanned: %d new steps", len(new_plan.steps))
                    self._say("Let me try a different approach.")
                else:
                    self._observer.cleanup()
                    self._task_mgr.fail_task(task.id, step.result_summary)
                    self._say(self._response.task_failed(step.result_summary))
                    self._publish_task_update(task)
                    return

        # All steps done — clean up any on-disk screenshots written during the task
        self._observer.cleanup()
        self._task_mgr.complete_task(task.id)
        summary = f"Completed: {task.goal}"
        self._say(self._response.task_complete(summary))
        self._publish_task_update(task)

    def _execute_step(self, task: Task, step: TaskStep) -> bool:
        """
        Run the full VERIFY → EXECUTE → OBSERVE → VERIFY loop for one step.
        Returns True if the step succeeded, False if it should be retried or replanned.
        """
        self._say(self._response.status_update(step.description))
        self._publish_task_update(task, step.description)
        task.status = TaskStatus.VERIFYING

        world = self._ctx.get_world_state()
        world_text = world.visible_text

        # ── Primary AI proposes action ────────────────────────────────────────
        proposal = self._primary_ai.propose_action(step, world_text)
        logger.info("PrimaryAI proposed: %s (conf=%.2f)", proposal.action, proposal.confidence)

        # ── Verification loop ─────────────────────────────────────────────────
        for _ in range(3):  # max 3 reconsider cycles
            verifier_result = self._verifier_ai.evaluate(proposal, step, world_text)
            logger.info(
                "VerifierAI: %s conf=%.2f risks=%s",
                verifier_result.verdict.value, verifier_result.confidence, verifier_result.risks
            )

            decision = self._policy.decide(proposal, verifier_result)
            logger.info("PolicyEngine decision: %s", decision.value)

            if decision == PolicyDecision.EXECUTE:
                break
            elif decision == PolicyDecision.RECONSIDER:
                feedback = verifier_result.suggested_correction or (
                    ", ".join(verifier_result.risks) or verifier_result.explanation
                )
                proposal = self._primary_ai.revise_action(step, proposal, feedback, world_text)
                logger.info("PrimaryAI revised proposal (conf=%.2f)", proposal.confidence)
                continue
            elif decision == PolicyDecision.BLOCK:
                self._say(self._response.generate(MessageType.ERROR_BLOCKED))
                step.result_summary = "Action blocked by safety policy."
                return False
            elif decision in (PolicyDecision.ASK_USER, PolicyDecision.ESCALATE):
                response = self._ask_user_confirmation(
                    self._response.confirm_action(str(proposal.action)), task.id
                )
                if response and "yes" in response.lower():
                    break  # user approved
                else:
                    self._say("Understood, I won't do that.")
                    step.result_summary = "User rejected the proposed action."
                    return False
        else:
            # Exhausted reconsider cycles
            self._say(self._response.escalate("Too many reconsiderations."))
            step.result_summary = "Verification loop exhausted."
            return False

        # ── Permission check ──────────────────────────────────────────────────
        perm = self._perm_check.check(proposal.action)
        if perm == PermissionResult.BLOCK:
            self._say(self._response.generate(MessageType.ERROR_BLOCKED))
            step.result_summary = "Permission denied."
            return False
        if perm == PermissionResult.REQUIRE_CONFIRMATION:
            response = self._ask_user_confirmation(
                self._response.confirm_irreversible(str(proposal.action)), task.id
            )
            if not (response and "yes" in response.lower()):
                step.result_summary = "User declined irreversible action."
                return False

        # ── Execute via Tool Registry (with timeout) ──────────────────────────
        task.status = TaskStatus.EXECUTING

        # Check cancellation before launching the tool
        if task.status in (TaskStatus.CANCELLED, TaskStatus.PAUSED):
            step.result_summary = "Task cancelled before tool execution."
            return False

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(self._registry.execute, proposal.action)
            try:
                action_result = future.result(timeout=MAX_STEP_DURATION_SECONDS)
            except concurrent.futures.TimeoutError:
                logger.warning(
                    "Step '%s' timed out after %ss", step.description, MAX_STEP_DURATION_SECONDS
                )
                step.result_summary = f"Timed out after {MAX_STEP_DURATION_SECONDS}s"
                return False

        logger.info("Tool result: %s", action_result)

        if not action_result.success:
            step.result_summary = action_result.error_message
            return False

        # ── Post-execution: handle special action types ───────────────────────

        # converse: the output IS the response — say it and mark step done
        if proposal.action.action_type == "converse":
            message = action_result.output or step.description
            self._say(message)
            step.result_summary = "Completed successfully."
            return True

        # search_web: synthesize the raw results into a natural-language answer
        if proposal.action.action_type == "search_web":
            query = proposal.action.parameters.get("query", task.goal)
            raw = action_result.output or ""
            answer = self._response.synthesize_search_result(query, raw)
            self._say(answer)
            step.result_summary = "Completed successfully."
            return True

        # ── Observe result ────────────────────────────────────────────────────
        task.status = TaskStatus.OBSERVING
        time.sleep(0.5)  # brief pause for UI to settle
        world_state = self._observer.capture(label=step.description[:20])

        # ── Verify step ───────────────────────────────────────────────────────
        task.status = TaskStatus.ACTIVE
        verification = self._step_ver.verify(step, world_state)
        logger.info(
            "StepVerifier: passed=%s conf=%.2f",
            verification.passed, verification.confidence
        )

        if verification.passed:
            step.result_summary = "Completed successfully."
            return True

        # Classify failure
        err = self._err_handler.classify(step, world_state, verification)
        step.result_summary = err.explanation
        if err.wait_seconds > 0:
            time.sleep(err.wait_seconds)
        return False

    # ── Conversation ──────────────────────────────────────────────────────────

    def _handle_conversation(self, text: str) -> None:
        if self._should_use_web_search(text):
            query = text.strip()
            action = Action(
                action_type="search_web",
                parameters={"query": query, "max_results": 5},
            )
            result = self._registry.execute(action)
            if result.success and result.output:
                answer = self._response.synthesize_search_result(query, str(result.output))
                self._say(answer)
                return

        history = self._ctx.get_history_as_messages()
        response = self._response.converse(text, history)
        # _say() handles context + GUI logging — don't double-log here
        self._say(response)

    @staticmethod
    def _should_use_web_search(text: str) -> bool:
        cleaned = text.strip()
        if not cleaned:
            return False

        lowered = cleaned.lower()
        if any(phrase in lowered for phrase in [
            "who are you",
            "what are you",
            "what is your name",
            "who made you",
            "how are you",
            "hello",
            "hi there",
            "good morning",
            "good evening",
            "good afternoon",
        ]):
            return False

        if "?" in cleaned or any(lowered.startswith(prefix) for prefix in [
            "what ", "who ", "where ", "when ", "why ", "how ",
            "is ", "are ", "can ", "could ", "would ", "should ",
            "tell me ", "explain ", "compare ", "latest ", "current ",
            "news ", "weather ", "price ", "cost ", "capital ",
            "currency ", "best ", "top ", "where can ", "when did ",
        ]):
            return True

        return False

    # ── Interruption / Cancel / Resume ────────────────────────────────────────

    def _handle_interruption(self, parsed: ParsedInput) -> None:
        active = self._task_mgr.get_active_task()
        if active:
            self._task_mgr.pause_task(active.id)
            self._say(self._response.generate(MessageType.TASK_PAUSED))
            self._publish_task_update(active)
            # Handle the new request
            self._route(ParsedInput(
                input_type=InputType.COMPUTER_TASK if any(
                    kw in parsed.raw_text.lower()
                    for kw in ["open", "launch", "search", "type", "click"]
                ) else InputType.CONVERSATION,
                intent=parsed.raw_text,
                raw_text=parsed.raw_text,
            ))

    def _handle_cancel(self) -> None:
        active = self._task_mgr.get_active_task()
        if active:
            self._task_mgr.cancel_task(active.id)
            self._say(self._response.generate(MessageType.TASK_CANCELLED))
            self._publish_task_update(active)
        else:
            self._say("Nothing to cancel.")

    def _handle_resume(self) -> None:
        paused = self._task_mgr.get_paused_task()
        if paused:
            self._task_mgr.resume_task(paused.id)
            self._say(self._response.generate(MessageType.TASK_RESUMED))
            # Re-observe world state before resuming
            world = self._observer.capture("resume_check")
            threading.Thread(
                target=self._run_task, args=(paused,), daemon=True
            ).start()
        else:
            self._say("No paused task to resume.")

    # ── User confirmation ─────────────────────────────────────────────────────

    def _ask_user_confirmation(self, prompt: str, task_id: str) -> Optional[str]:
        self._log_gui("jarvis", prompt)
        self._say(prompt)
        self._task_mgr.set_waiting(task_id)
        self._bus.publish(EventType.CONFIRMATION_NEEDED, {"prompt": prompt})
        response = self._task_mgr.wait_for_user_response(timeout=60.0)
        # Resume active status after waiting
        task = self._task_mgr.get_task(task_id)
        if task and task.status == TaskStatus.WAITING:
            task.status = TaskStatus.ACTIVE
        return response

    def _on_confirmation(self, payload: dict) -> None:
        """Called when the user types/says yes/no to a confirmation prompt."""
        response = payload.get("text", "") if isinstance(payload, dict) else str(payload)
        self._task_mgr.provide_user_response(response)

    # ── Emergency stop ────────────────────────────────────────────────────────

    def _on_emergency_stop(self, payload) -> None:
        logger.warning("EMERGENCY STOP received")
        self._task_mgr.cancel_all()
        self._tts.stop()
        self._say("Stopped.")
        self._set_voice_state("IDLE")
        self._bus.publish(EventType.GUI_TASK_UPDATE, {"goal": "", "status": "IDLE", "current_step": ""})

    # ── GUI helpers ───────────────────────────────────────────────────────────

    def _say(self, text: str) -> None:
        """
        Speak text and log it to the GUI conversation panel.
        This is the single point that records all JARVIS output.
        It must NOT be called for user input (that is logged in handle_input).
        """
        if text:
            self._ctx.add_turn("jarvis", text)
            self._log_gui("jarvis", text)
            self._bus.publish_async(EventType.SPEAKING_STARTED, {})
            self._tts.speak(text)

    def _log_gui(self, role: str, text: str) -> None:
        self._bus.publish(EventType.GUI_LOG_MESSAGE, {"role": role, "text": text})

    def _set_voice_state(self, state: str) -> None:
        self._bus.publish(EventType.GUI_STATUS_UPDATE, {"state": state})

    def _publish_task_update(self, task: Task, current_step: str = "") -> None:
        self._bus.publish(
            EventType.GUI_TASK_UPDATE,
            {
                "goal": task.goal,
                "status": task.status.value,
                "current_step": current_step or task.progress_summary,
            },
        )
