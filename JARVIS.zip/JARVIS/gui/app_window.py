"""
gui/app_window.py

Main application window for JARVIS.
Built with CustomTkinter — the main thread owns this window exclusively.

Layout:
┌─────────────────────────────────────────────────────────┐
│  JARVIS — Personal AI Assistant            [voice badge] │
├────────────────────────────┬────────────────────────────┤
│  Conversation Panel        │  Task Panel                │
│  (scrollable transcript)   │  (goal / step / status)    │
├────────────────────────────┴────────────────────────────┤
│  [Text input box]                  [Send]  [Stop]        │
└─────────────────────────────────────────────────────────┘
"""

from __future__ import annotations

import logging
import threading
from typing import Callable, Optional

import customtkinter as ctk

from gui.conversation_panel import ConversationPanel
from gui.task_panel import TaskPanel
from gui.voice_indicator import VoiceIndicator
from core.event_bus import event_bus, EventType

logger = logging.getLogger(__name__)

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


class AppWindow(ctk.CTk):
    """
    Main JARVIS desktop window.

    The GUI thread only renders — it never calls AI, tools, or voice code.
    All communication with background components goes through the EventBus.
    """

    def __init__(
        self,
        title: str = "JARVIS — Personal AI Assistant",
        width: int = 900,
        height: int = 650,
        on_user_input: Optional[Callable[[str], None]] = None,
        on_voice_input: Optional[Callable[[], None]] = None,
        on_stop: Optional[Callable[[], None]] = None,
    ) -> None:
        super().__init__()

        self._on_user_input = on_user_input
        self._on_voice_input = on_voice_input
        self._on_stop = on_stop

        self.title(title)
        self.geometry(f"{width}x{height}")
        self.minsize(700, 500)

        self._build_ui()
        self._subscribe_to_events()

        logger.info("JARVIS window initialised (%dx%d)", width, height)

    # ── UI construction ───────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        # Header bar
        header = ctk.CTkFrame(self, height=44, corner_radius=0)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)

        ctk.CTkLabel(
            header,
            text="J.A.R.V.I.S",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color="#2196F3",
        ).pack(side="left", padx=16, pady=8)

        self._voice_indicator = VoiceIndicator(header)
        self._voice_indicator.pack(side="right", padx=12, pady=4)

        # Main content area (two columns)
        content = ctk.CTkFrame(self, corner_radius=0)
        content.pack(fill="both", expand=True, padx=0, pady=0)
        content.columnconfigure(0, weight=3)
        content.columnconfigure(1, weight=1)
        content.rowconfigure(0, weight=1)

        # Left — conversation transcript
        self._conversation_panel = ConversationPanel(
            content,
            label_text="Conversation",
            label_font=ctk.CTkFont(size=12, weight="bold"),
        )
        self._conversation_panel.grid(row=0, column=0, sticky="nsew", padx=(8, 4), pady=8)

        # Right — task status
        self._task_panel = TaskPanel(
            content,
            border_width=1,
            corner_radius=8,
        )
        self._task_panel.grid(row=0, column=1, sticky="nsew", padx=(4, 8), pady=8)

        # Footer — text input
        footer = ctk.CTkFrame(self, height=52, corner_radius=0)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)

        self._input_var = ctk.StringVar()
        self._input_box = ctk.CTkEntry(
            footer,
            placeholder_text="Type a message or use voice...",
            textvariable=self._input_var,
            font=ctk.CTkFont(size=13),
        )
        self._input_box.pack(side="left", fill="x", expand=True, padx=(12, 6), pady=10)
        self._input_box.bind("<Return>", self._on_send)

        send_btn = ctk.CTkButton(
            footer, text="Send", width=70, command=self._on_send
        )
        send_btn.pack(side="left", padx=(0, 6), pady=10)

        speak_btn = ctk.CTkButton(
            footer, text="Speak", width=80, command=self._on_speak_clicked
        )
        speak_btn.pack(side="left", padx=(0, 6), pady=10)

        stop_btn = ctk.CTkButton(
            footer,
            text="Stop",
            width=70,
            fg_color="#D32F2F",
            hover_color="#B71C1C",
            command=self._on_stop_clicked,
        )
        stop_btn.pack(side="left", padx=(0, 12), pady=10)

    # ── Event bus subscriptions ───────────────────────────────────────────────

    def _subscribe_to_events(self) -> None:
        event_bus.subscribe(EventType.GUI_LOG_MESSAGE, self._handle_log_message)
        event_bus.subscribe(EventType.GUI_STATUS_UPDATE, self._handle_status_update)
        event_bus.subscribe(EventType.GUI_TASK_UPDATE, self._handle_task_update)
        event_bus.subscribe(EventType.SPEAKING_STARTED, lambda _: self._set_voice("SPEAKING"))
        event_bus.subscribe(EventType.SPEAKING_FINISHED, lambda _: self._set_voice("IDLE"))

    def _handle_log_message(self, payload: dict) -> None:
        """Receive a log message from any background component."""
        role = payload.get("role", "system")
        text = payload.get("text", "")
        self.after(0, lambda: self._conversation_panel.add_message(role, text))

    def _handle_status_update(self, payload: dict) -> None:
        """Update voice indicator state."""
        state = payload.get("state", "IDLE")
        self.after(0, lambda: self._voice_indicator.set_state(state))

    def _handle_task_update(self, payload: dict) -> None:
        """Update task panel."""
        goal   = payload.get("goal", "")
        status = payload.get("status", "IDLE")
        step   = payload.get("current_step", "")
        self.after(0, lambda: self._task_panel.update_task(goal, status, step))

    # ── Input handlers ────────────────────────────────────────────────────────

    def _on_send(self, _event=None) -> None:
        text = self._input_var.get().strip()
        if not text:
            return
        self._input_var.set("")
        # Never append the user text directly here; the event bus logs it once.
        if self._on_user_input:
            # Run on background thread so GUI never blocks
            threading.Thread(
                target=self._on_user_input, args=(text,), daemon=True
            ).start()

    def _on_stop_clicked(self) -> None:
        event_bus.publish(EventType.EMERGENCY_STOP, {"source": "gui_button"})
        if self._on_stop:
            self._on_stop()

    def _on_speak_clicked(self) -> None:
        if self._on_voice_input:
            self._on_voice_input()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _set_voice(self, state: str) -> None:
        self._voice_indicator.set_state(state)

    def log(self, role: str, text: str) -> None:
        """Thread-safe helper to add a message from outside the GUI thread."""
        self.after(0, lambda: self._conversation_panel.add_message(role, text))

    def set_voice_state(self, state: str) -> None:
        """Thread-safe helper to update voice indicator."""
        self.after(0, lambda: self._voice_indicator.set_state(state))
