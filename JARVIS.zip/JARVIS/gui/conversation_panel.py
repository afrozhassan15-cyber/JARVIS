"""
gui/conversation_panel.py

Scrollable transcript panel showing the JARVIS ↔ user dialogue.
"""

from __future__ import annotations

import tkinter as tk
from datetime import datetime
import customtkinter as ctk


class ConversationPanel(ctk.CTkScrollableFrame):
    """
    Displays the conversation as a scrolling log of messages.
    Each message is colour-coded by role (user / jarvis / system).
    """

    ROLE_COLORS = {
        "user":   "#4CAF50",   # green
        "jarvis": "#2196F3",   # blue
        "system": "#9E9E9E",   # grey
        "error":  "#F44336",   # red
    }

    def __init__(self, parent: ctk.CTkFrame, **kwargs) -> None:
        super().__init__(parent, **kwargs)
        self._messages: list[ctk.CTkLabel] = []

    def add_message(self, role: str, text: str) -> None:
        """
        Append a message bubble.  Call from the main thread.
        """
        timestamp = datetime.now().strftime("%H:%M:%S")
        color = self.ROLE_COLORS.get(role, "#FFFFFF")
        prefix = {"user": "You", "jarvis": "JARVIS", "system": "System"}.get(role, role.upper())

        label = ctk.CTkLabel(
            self,
            text=f"[{timestamp}] {prefix}: {text}",
            wraplength=580,
            justify="left",
            anchor="w",
            text_color=color,
            font=ctk.CTkFont(size=13),
        )
        label.pack(anchor="w", padx=8, pady=2, fill="x")
        self._messages.append(label)

        # Auto-scroll to bottom
        self.after(50, self._scroll_to_bottom)

    def _scroll_to_bottom(self) -> None:
        """Scroll to the latest message."""
        self._parent_canvas.yview_moveto(1.0)

    def clear(self) -> None:
        for lbl in self._messages:
            lbl.destroy()
        self._messages.clear()
