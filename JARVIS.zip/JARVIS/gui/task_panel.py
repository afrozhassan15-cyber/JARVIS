"""
gui/task_panel.py

Panel showing active task name, current step, and step status.
"""

from __future__ import annotations

import customtkinter as ctk


class TaskPanel(ctk.CTkFrame):
    """
    Displays the current task state: goal, active step, and status badges.
    Updated by the Orchestrator via the EventBus on the main thread.
    """

    STATUS_COLORS = {
        "PENDING":   "#9E9E9E",
        "ACTIVE":    "#2196F3",
        "PAUSED":    "#FF9800",
        "COMPLETED": "#4CAF50",
        "FAILED":    "#F44336",
        "CANCELLED": "#9E9E9E",
        "WAITING":   "#9C27B0",
    }

    def __init__(self, parent: ctk.CTkFrame, **kwargs) -> None:
        super().__init__(parent, **kwargs)
        self._build_ui()

    def _build_ui(self) -> None:
        # Title row
        self._title = ctk.CTkLabel(
            self, text="No active task",
            font=ctk.CTkFont(size=14, weight="bold"),
            anchor="w",
        )
        self._title.pack(anchor="w", padx=10, pady=(8, 2), fill="x")

        # Status badge
        self._status_label = ctk.CTkLabel(
            self, text="IDLE",
            font=ctk.CTkFont(size=11),
            text_color="#9E9E9E",
            anchor="w",
        )
        self._status_label.pack(anchor="w", padx=10, pady=(0, 2), fill="x")

        # Current step description
        self._step_label = ctk.CTkLabel(
            self, text="",
            font=ctk.CTkFont(size=12),
            text_color="#CCCCCC",
            anchor="w",
            wraplength=350,
        )
        self._step_label.pack(anchor="w", padx=10, pady=(0, 8), fill="x")

    def update_task(self, goal: str, status: str, current_step: str = "") -> None:
        """Update the panel from the main thread."""
        color = self.STATUS_COLORS.get(status, "#9E9E9E")
        self._title.configure(text=goal or "No active task")
        self._status_label.configure(text=status, text_color=color)
        self._step_label.configure(text=current_step)

    def clear(self) -> None:
        self.update_task("", "IDLE", "")
