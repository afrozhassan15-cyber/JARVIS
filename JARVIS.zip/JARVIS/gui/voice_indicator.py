"""
gui/voice_indicator.py

Visual indicator showing JARVIS voice state: IDLE / LISTENING / THINKING / SPEAKING.
"""

from __future__ import annotations

import customtkinter as ctk


class VoiceIndicator(ctk.CTkFrame):
    """
    A simple coloured status pill that reflects the current voice state.
    """

    STATES = {
        "IDLE":      ("#3A3A3A", "● Idle"),
        "LISTENING": ("#4CAF50", "🎙 Listening..."),
        "THINKING":  ("#FF9800", "⚙ Thinking..."),
        "SPEAKING":  ("#2196F3", "🔊 Speaking..."),
        "ERROR":     ("#F44336", "⚠ Error"),
    }

    def __init__(self, parent: ctk.CTkFrame, **kwargs) -> None:
        super().__init__(parent, **kwargs)
        self._label = ctk.CTkLabel(
            self,
            text="● Idle",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#9E9E9E",
        )
        self._label.pack(padx=10, pady=4)

    def set_state(self, state: str) -> None:
        """Update the indicator. Must be called from the main thread."""
        color, text = self.STATES.get(state.upper(), ("#9E9E9E", state))
        self._label.configure(text=text, text_color=color)
