"""
main.py — JARVIS entry point.

Starts the desktop application:
1. Initialises logging
2. Loads configuration
3. Creates the Orchestrator
4. Launches the GUI (main thread)
5. Starts background services (voice listener, task executor)

Usage:
    python main.py
"""

from __future__ import annotations

import logging
import sys
import threading
from pathlib import Path


def setup_logging(log_level: str = "INFO") -> None:
    """Configure structured logging to both console and file."""
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)

    level = getattr(logging, log_level.upper(), logging.INFO)
    fmt = "%(asctime)s | %(levelname)-8s | %(name)-30s | %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    handlers = [
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(log_dir / "jarvis.log", encoding="utf-8"),
    ]
    logging.basicConfig(level=level, format=fmt, datefmt=datefmt, handlers=handlers)
    # Quiet noisy third-party loggers
    for noisy in ("urllib3", "ibm_watson", "ibm_watsonx_ai", "PIL", "pyautogui"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def main() -> None:
    from config.config import config
    setup_logging(config.log_level)
    logger = logging.getLogger(__name__)
    logger.info("=" * 60)
    logger.info("JARVIS starting up")
    logger.info("Watson STT configured: %s", config.stt.is_configured)
    logger.info("Watson TTS configured: %s", config.tts.is_configured)
    logger.info("watsonx.ai configured: %s", config.watsonx.is_configured)
    logger.info("=" * 60)

    from core.event_bus import event_bus
    from core.event_bus import EventType
    from core.context_manager import context_manager
    from core.orchestrator import Orchestrator
    from gui.app_window import AppWindow
    from voice.speech_to_text import SpeechToText

    # Create orchestrator
    orchestrator = Orchestrator(
        config=config,
        event_bus=event_bus,
        context_manager=context_manager,
    )

    speech = SpeechToText(
        on_transcript=lambda result: orchestrator.handle_input(result.text),
        on_state=lambda state: event_bus.publish(
            EventType.GUI_STATUS_UPDATE, {"state": state}
        ),
    )

    def on_user_input(text: str) -> None:
        """Called from GUI input box or spoken transcript — runs on background thread."""
        orchestrator.handle_input(text)

    def on_stop() -> None:
        speech.stop()
        orchestrator.stop()

    # Build the GUI (must happen on main thread)
    app = AppWindow(
        title=config.window_title,
        width=config.window_width,
        height=config.window_height,
        on_user_input=on_user_input,
        on_voice_input=speech.listen_once_async,
        on_stop=on_stop,
    )

    # Start orchestrator on a background thread after GUI is ready
    def start_orchestrator():
        orchestrator.start()

    app.after(500, lambda: threading.Thread(target=start_orchestrator, daemon=True).start())
    logger.info("Starting GUI main loop")
    try:
        app.mainloop()
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received")
    finally:
        orchestrator.stop()
        logger.info("JARVIS shutdown complete")


if __name__ == "__main__":
    main()
