"""
observation/error_handler.py

Classifies step failures and produces recovery strategies.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from ai.action_schema import VerificationResult
from core.context_manager import WorldState
from tasks.task import TaskStep

logger = logging.getLogger(__name__)


class ErrorType(str, Enum):
    ELEMENT_NOT_FOUND     = "element_not_found"
    WRONG_SCREEN_STATE    = "wrong_screen_state"
    APP_NOT_OPEN          = "app_not_open"
    CLICK_NO_EFFECT       = "click_no_effect"
    NETWORK_FAILURE       = "network_failure"
    INVALID_ACTION        = "invalid_action"
    STEP_TIMEOUT          = "timeout"
    ENVIRONMENT_CHANGED   = "environment_changed"
    UNKNOWN               = "unknown"


class RecoveryStrategy(str, Enum):
    RETRY           = "RETRY"           # Retry the same step
    REPLAN          = "REPLAN"          # Re-plan remaining steps from current state
    ESCALATE        = "ESCALATE"        # Inform the user; pause the task
    WAIT_AND_RETRY  = "WAIT_AND_RETRY"  # Wait briefly then retry


@dataclass
class ErrorClassification:
    error_type: ErrorType
    strategy: RecoveryStrategy
    explanation: str
    wait_seconds: float = 0.0


class ErrorHandler:
    """
    Classifies step failures and recommends recovery strategies.

    The decision logic here is purely deterministic — no AI calls.
    Keeps error recovery predictable and testable.
    """

    def classify(
        self,
        step: TaskStep,
        world_state: WorldState,
        verification_result: VerificationResult,
    ) -> ErrorClassification:
        """
        Classify a failed verification into an ErrorType and RecoveryStrategy.
        """
        error_type_str = verification_result.error_type or "unknown"
        try:
            error_type = ErrorType(error_type_str)
        except ValueError:
            error_type = ErrorType.UNKNOWN

        strategy, wait = self._determine_strategy(error_type, step)

        logger.info(
            "ErrorHandler: type=%s strategy=%s step='%s'",
            error_type.value, strategy.value, step.description[:50],
        )
        return ErrorClassification(
            error_type=error_type,
            strategy=strategy,
            explanation=verification_result.explanation,
            wait_seconds=wait,
        )

    # ── Strategy table ────────────────────────────────────────────────────────

    def _determine_strategy(
        self, error_type: ErrorType, step: TaskStep
    ) -> tuple[RecoveryStrategy, float]:
        """
        Returns (RecoveryStrategy, wait_seconds_before_retry).
        """
        mapping = {
            ErrorType.ELEMENT_NOT_FOUND:   (RecoveryStrategy.RETRY,          0.5),
            ErrorType.WRONG_SCREEN_STATE:  (RecoveryStrategy.RETRY,          0.0),
            ErrorType.APP_NOT_OPEN:        (RecoveryStrategy.WAIT_AND_RETRY, 2.0),
            ErrorType.CLICK_NO_EFFECT:     (RecoveryStrategy.RETRY,          0.5),
            ErrorType.NETWORK_FAILURE:     (RecoveryStrategy.WAIT_AND_RETRY, 3.0),
            ErrorType.INVALID_ACTION:      (RecoveryStrategy.ESCALATE,       0.0),
            ErrorType.STEP_TIMEOUT:        (RecoveryStrategy.REPLAN,         0.0),
            ErrorType.ENVIRONMENT_CHANGED: (RecoveryStrategy.REPLAN,         0.0),
            ErrorType.UNKNOWN:             (RecoveryStrategy.RETRY,          0.5),
        }
        return mapping.get(error_type, (RecoveryStrategy.RETRY, 0.5))
