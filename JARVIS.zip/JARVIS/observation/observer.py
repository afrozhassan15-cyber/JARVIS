"""
observation/observer.py

Captures the observable world state after an action executes.

Primary path: PIL.ImageGrab.grab() → in-memory PIL Image (no file I/O).
File writes only happen when save_to_disk=True is explicitly requested.
Files written during a task are tracked and deleted by cleanup().
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from core.context_manager import WorldState
from observation.screen_analyzer import ScreenAnalyzer

logger = logging.getLogger(__name__)

_SCREENSHOT_DIR = Path("logs/screenshots")


class Observer:
    """
    Takes a snapshot of the computer screen after an action executes.
    Extracts visible text via OCR.
    Updates the ContextManager's world state.

    Primary capture path uses PIL.ImageGrab in memory — no files written
    unless save_to_disk=True.  All files written during a session are
    tracked and removed by cleanup().
    """

    def __init__(self, context_manager=None) -> None:
        self._ctx = context_manager
        self._written_files: list[Path] = []
        self._screen_analyzer = ScreenAnalyzer()

    def capture(self, label: str = "", save_to_disk: bool = False) -> WorldState:
        """
        Capture the current screen state and return a WorldState.

        Args:
            label:        Short label used as filename suffix when saving.
            save_to_disk: If True, save the screenshot PNG and record the path.
                          If False (default), keep the image in memory only.

        Falls back gracefully if pyautogui / PIL / pytesseract are unavailable.
        """
        state = WorldState(captured_at=datetime.now())

        # ── Grab screenshot into memory ────────────────────────────────────────
        image = self._grab_screenshot()

        if image is not None and save_to_disk:
            path = self._save_image(image, label)
            if path:
                state.screenshot_path = str(path)

        # ── Extract text (OCR) and structured UI cues from the image ────────
        analyzed = self._screen_analyzer.analyze(
            image=image,
            window_title=self._get_window_info()[0],
            active_app=self._get_window_info()[1],
        )
        state.visible_text = analyzed.raw_text or self._extract_text(image)
        state.window_title = analyzed.window_title or self._get_window_info()[0]
        state.active_app = analyzed.active_app or self._get_window_info()[1]

        # ── Update context manager ────────────────────────────────────────────
        if self._ctx:
            self._ctx.update_world_state(state)

        logger.debug(
            "Observer captured: window='%s' text_len=%d saved=%s",
            state.window_title, len(state.visible_text), bool(state.screenshot_path),
        )
        return state

    def cleanup(self) -> None:
        """Delete all screenshot files written during this session."""
        for path in self._written_files:
            try:
                if path.exists():
                    path.unlink()
                    logger.debug("Deleted screenshot: %s", path)
            except Exception as exc:
                logger.warning("Could not delete screenshot %s: %s", path, exc)
        self._written_files.clear()

    # ── Private helpers ───────────────────────────────────────────────────────

    def _grab_screenshot(self):
        """
        Grab the screen into a PIL Image in memory.
        Returns None if capture fails.
        """
        # Prefer PIL.ImageGrab (no file I/O, cross-platform on Windows)
        try:
            from PIL import ImageGrab
            return ImageGrab.grab()
        except Exception:
            pass
        # Fallback: pyautogui.screenshot() also returns a PIL Image
        try:
            import pyautogui
            return pyautogui.screenshot()
        except Exception as exc:
            logger.warning("Screenshot capture failed: %s", exc)
            return None

    def _save_image(self, image, label: str) -> Optional[Path]:
        """Save a PIL Image to disk and track the file for cleanup."""
        try:
            _SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_label = "".join(c if c.isalnum() else "_" for c in label)[:30]
            filename = f"{ts}_{safe_label}.png" if safe_label else f"{ts}.png"
            path = _SCREENSHOT_DIR / filename
            image.save(str(path))
            self._written_files.append(path)
            logger.debug("Screenshot saved: %s", path)
            return path
        except Exception as exc:
            logger.warning("Screenshot save failed: %s", exc)
            return None

    def _extract_text(self, image) -> str:
        """Run OCR on a PIL Image (in memory). Returns empty string on failure."""
        if image is None:
            return ""
        try:
            import pytesseract
            text = pytesseract.image_to_string(image)
            return text.strip()
        except Exception as exc:
            logger.debug("OCR unavailable or failed: %s", exc)
            return ""

    def _get_window_info(self) -> tuple[str, str]:
        try:
            import pygetwindow as gw
            active = gw.getActiveWindow()
            if active:
                title = active.title or ""
                app = title.split(" - ")[-1] if " - " in title else title
                return title, app
        except Exception:
            pass
        return "", ""
