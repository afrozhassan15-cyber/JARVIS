"""
observation/screen_analyzer.py

Structured OCR analysis of a screen capture.
Returns a ScreenState with typed fields instead of a raw OCR string.

Intentionally limited to OCR + heuristics — no computer vision / ML.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# Patterns that suggest a UI button or link in OCR output
_INTERACTIVE_PATTERNS = re.compile(
    r"\b(OK|Cancel|Close|Submit|Save|Open|Browse|Yes|No|Apply|"
    r"Next|Back|Finish|Continue|Retry|Abort|Help|Search|Send|"
    r"New|Delete|Edit|Copy|Paste|Cut|Print|Undo|Redo|Refresh|"
    r"Sign in|Log in|Log out|Sign up)\b",
    re.IGNORECASE,
)

# Heuristic strings that suggest an editable text area is visible
_TEXT_INPUT_HINTS = re.compile(
    r"\b(type here|enter text|search|address bar|input|username|password|"
    r"email|message|compose|subject|find|filter|query|placeholder)\b",
    re.IGNORECASE,
)


@dataclass
class ScreenState:
    """Structured description of a captured screen state."""
    raw_text: str = ""
    lines: list[str] = field(default_factory=list)
    window_title: str = ""
    active_app: str = ""
    has_text_input: bool = False
    interactive_elements: list[str] = field(default_factory=list)


class ScreenAnalyzer:
    """
    Analyzes a PIL Image and returns a structured ScreenState.

    Uses pytesseract for OCR if available; falls back to an empty text
    result without raising an exception.
    """

    def analyze(self, image, window_title: str = "", active_app: str = "") -> ScreenState:
        """
        Analyze a PIL Image and return a ScreenState.

        Args:
            image:        A PIL.Image.Image (may be None — returns empty state).
            window_title: Pre-populated window title (from pygetwindow or Observer).
            active_app:   Pre-populated active application name.
        """
        raw_text = self._ocr(image)
        lines = [ln for ln in raw_text.splitlines() if ln.strip()]

        # If window_title not supplied, try to derive from pygetwindow
        if not window_title:
            window_title, active_app = self._get_window_info()

        interactive_elements = self._find_interactive_elements(raw_text)
        has_text_input = self._detect_text_input(raw_text, window_title)

        return ScreenState(
            raw_text=raw_text,
            lines=lines,
            window_title=window_title,
            active_app=active_app,
            has_text_input=has_text_input,
            interactive_elements=interactive_elements,
        )

    # ── Private helpers ───────────────────────────────────────────────────────

    def _ocr(self, image) -> str:
        """Run pytesseract on image; return empty string if unavailable."""
        if image is None:
            return ""
        try:
            import pytesseract
            return pytesseract.image_to_string(image).strip()
        except Exception as exc:
            logger.debug("ScreenAnalyzer OCR unavailable: %s", exc)
            return ""

    def _find_interactive_elements(self, text: str) -> list[str]:
        """Extract button/link labels from OCR text using pattern matching."""
        matches = _INTERACTIVE_PATTERNS.findall(text)
        # Deduplicate while preserving order
        seen: set[str] = set()
        result: list[str] = []
        for m in matches:
            key = m.lower()
            if key not in seen:
                seen.add(key)
                result.append(m)
        return result

    def _detect_text_input(self, text: str, window_title: str) -> bool:
        """
        Heuristic: returns True if the screen likely has an editable text area.
        Checks OCR text for input-related words and window title for editor cues.
        """
        if _TEXT_INPUT_HINTS.search(text):
            return True
        editor_titles = ("notepad", "editor", "word", "calc", "terminal",
                         "cmd", "powershell", "code", "sublime", "vim")
        title_lower = window_title.lower()
        return any(t in title_lower for t in editor_titles)

    def _get_window_info(self) -> tuple[str, str]:
        try:
            import pygetwindow as gw
            active = gw.getActiveWindow()
            if active:
                title = active.title or ""
                app = title.split(" - ")[-1] if " - " in title else title
                return title, app
        except Exception:
            pass
        return "", ""
