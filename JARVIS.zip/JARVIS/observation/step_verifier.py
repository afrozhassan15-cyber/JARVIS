"""
observation/step_verifier.py

Determines whether an executed action achieved its expected outcome.
Uses LLM reasoning to compare the Evidence Bundle against the expected outcome.
"""

from __future__ import annotations

import json
import logging
import re

from ai.action_schema import VerificationResult
from ai.watsonx_client import WatsonxAIClient
from core.context_manager import WorldState
from tasks.task import TaskStep

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """You are a step verification system for JARVIS, a desktop AI assistant.
Your job: determine whether an executed action achieved its expected outcome.

Given:
- The step description (what was supposed to happen)
- The expected outcome (what success looks like)
- The observed screen state (what actually happened)

Decide: did the action succeed?

Respond with ONLY valid JSON:
{
  "passed": true or false,
  "confidence": <float 0.0-1.0>,
  "explanation": "<brief explanation>",
  "error_type": "<one of: element_not_found, wrong_screen_state, app_not_open, click_no_effect, timeout, environment_changed, none>"
}

error_type should be "none" when passed=true.
Use "environment_changed" when the screen shows something completely unexpected.
"""


class StepVerifier:
    """
    Compares an EvidenceBundle (world state) against a step's expected outcome.
    Uses LLM for flexible matching — works even when the exact screen text varies.
    Falls back to keyword matching when LLM is unavailable.
    """

    def __init__(self, client: WatsonxAIClient) -> None:
        self._client = client

    def verify(self, step: TaskStep, world_state: WorldState) -> VerificationResult:
        """
        Verify whether the step's expected outcome was achieved.

        Args:
            step:        the completed TaskStep (contains expected_outcome)
            world_state: captured after the action executed

        Returns:
            VerificationResult with passed, confidence, explanation
        """
        if self._client.is_mock:
            return self._rule_based_verify(step, world_state)

        try:
            return self._llm_verify(step, world_state)
        except Exception as exc:
            logger.warning("LLM verification failed (%s), using rule-based.", exc)
            return self._rule_based_verify(step, world_state)

    # ── LLM-based verification ────────────────────────────────────────────────

    def _llm_verify(self, step: TaskStep, world_state: WorldState) -> VerificationResult:
        user_message = (
            f"Step description: {step.description}\n"
            f"Expected outcome: {step.expected_outcome}\n"
            f"Observed window title: {world_state.window_title}\n"
            f"Observed screen text (first 600 chars):\n{world_state.visible_text[:600]}"
        )
        messages = [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user",   "content": user_message},
        ]
        raw = self._client.chat(messages)
        return self._parse_result(raw)

    # ── Rule-based fallback ───────────────────────────────────────────────────

    def _rule_based_verify(self, step: TaskStep, world_state: WorldState) -> VerificationResult:
        """
        Simple keyword matching when LLM is unavailable.
        Checks whether key words from expected_outcome appear in the screen text or title.
        """
        expected = step.expected_outcome.lower()
        observed = (world_state.visible_text + " " + world_state.window_title).lower()

        if not expected:
            # No expected outcome defined — assume pass (best effort)
            return VerificationResult(
                passed=True,
                confidence=0.5,
                explanation="No expected outcome defined; assuming pass.",
            )

        # Extract keywords from expected outcome (ignore common stop words)
        stop_words = {"the", "a", "an", "is", "are", "should", "be", "and", "or", "in"}
        keywords = [
            w for w in re.split(r"\W+", expected)
            if w and w not in stop_words and len(w) > 2
        ]

        if not keywords:
            return VerificationResult(
                passed=True, confidence=0.5,
                explanation="No meaningful keywords extracted from expected outcome.",
            )

        matched = [kw for kw in keywords if kw in observed]
        ratio = len(matched) / len(keywords)
        # Pass if at least 1 keyword matched OR ratio >= 33%
        passed = len(matched) >= 1 or ratio >= 0.33

        return VerificationResult(
            passed=passed,
            confidence=min(0.4 + ratio * 0.5, 0.9),
            explanation=(
                f"Keyword match: {len(matched)}/{len(keywords)} "
                f"({', '.join(matched) or 'none'})"
            ),
            error_type="wrong_screen_state" if not passed else "none",
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _parse_result(raw: str) -> VerificationResult:
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group())
                return VerificationResult(
                    passed=bool(data.get("passed", False)),
                    confidence=float(data.get("confidence", 0.5)),
                    explanation=data.get("explanation", ""),
                    error_type=data.get("error_type", "none"),
                )
            except json.JSONDecodeError:
                pass
        # Fallback — could not parse
        return VerificationResult(
            passed=False,
            confidence=0.3,
            explanation="Could not parse verification response.",
            error_type="wrong_screen_state",
        )
