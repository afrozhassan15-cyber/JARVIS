"""
response/personality.py

Personality templates for JARVIS.
Pure transformation layer — receives a MessageType and returns natural language.
No AI calls for template-based messages (keeps latency low during tasks).
"""

from __future__ import annotations

import random
from enum import Enum


class MessageType(str, Enum):
    TASK_STARTED          = "TASK_STARTED"
    STEP_UPDATE           = "STEP_UPDATE"
    STEP_COMPLETE         = "STEP_COMPLETE"
    TASK_COMPLETE         = "TASK_COMPLETE"
    STEP_RETRY            = "STEP_RETRY"
    TASK_FAILED           = "TASK_FAILED"
    CONFIRM_ACTION        = "CONFIRM_ACTION"
    CONFIRM_IRREVERSIBLE  = "CONFIRM_IRREVERSIBLE"
    CLARIFICATION_NEEDED  = "CLARIFICATION_NEEDED"
    LONG_RUNNING_UPDATE   = "LONG_RUNNING_UPDATE"
    TASK_PAUSED           = "TASK_PAUSED"
    TASK_RESUMED          = "TASK_RESUMED"
    TASK_CANCELLED        = "TASK_CANCELLED"
    ESCALATE              = "ESCALATE"
    GREETING              = "GREETING"
    ERROR_BLOCKED         = "ERROR_BLOCKED"
    NO_TOOL               = "NO_TOOL"


_TEMPLATES: dict[MessageType, list[str]] = {
    MessageType.TASK_STARTED: [
        "On it.",
        "Right away.",
        "Leave it to me.",
        "Sure, let me take care of that.",
    ],
    MessageType.STEP_UPDATE: [
        "{step}",
        "Working on it: {step}",
        "Next up: {step}",
    ],
    MessageType.STEP_COMPLETE: [
        "Done. Moving on.",
        "Got it, next step.",
        "Step complete.",
    ],
    MessageType.TASK_COMPLETE: [
        "All finished. {summary}",
        "Done and done. {summary}",
        "That's sorted. {summary}",
    ],
    MessageType.STEP_RETRY: [
        "That didn't quite work — trying again.",
        "Hit a snag, retrying...",
        "Let me try that again.",
    ],
    MessageType.TASK_FAILED: [
        "I ran into a problem I couldn't get past. {summary}",
        "Sorry, I wasn't able to complete that. {summary}",
        "I've hit a wall on this one. {summary}",
    ],
    MessageType.CONFIRM_ACTION: [
        "I'm about to {action}. Shall I go ahead?",
        "Just to confirm — {action}. Is that right?",
        "I'll {action}. Say yes to confirm.",
    ],
    MessageType.CONFIRM_IRREVERSIBLE: [
        "Just to be safe — {action}. This can't be undone. Are you sure?",
        "I need your explicit confirmation for this: {action}. Yes or no?",
    ],
    MessageType.CLARIFICATION_NEEDED: [
        "Could you be a bit more specific? {question}",
        "I want to make sure I get this right — {question}",
        "Just to clarify: {question}",
    ],
    MessageType.LONG_RUNNING_UPDATE: [
        "Still on it — this one's taking a moment.",
        "Still working...",
        "Bear with me, almost there.",
        "Taking a bit longer than expected.",
    ],
    MessageType.TASK_PAUSED: [
        "Pausing that. What do you need?",
        "Okay, holding on. Go ahead.",
        "I've paused that task. What's up?",
    ],
    MessageType.TASK_RESUMED: [
        "Right, back to what we were doing.",
        "Picking up where we left off.",
        "Resuming the previous task.",
    ],
    MessageType.TASK_CANCELLED: [
        "Cancelled.",
        "Done, I've stopped that.",
        "Task cancelled.",
    ],
    MessageType.ESCALATE: [
        "I've tried a few times and I'm not sure how to proceed. Could you help? {summary}",
        "I need your input here — I've got stuck. {summary}",
    ],
    MessageType.GREETING: [
        "Hello. How can I help?",
        "Hi there. What can I do for you?",
        "Good to hear from you. What do you need?",
    ],
    MessageType.ERROR_BLOCKED: [
        "I can't do that — it falls outside what I'm allowed to do.",
        "That action is blocked for safety reasons.",
        "Sorry, that one's off-limits.",
    ],
    MessageType.NO_TOOL: [
        "I don't have a tool for that yet.",
        "That capability isn't available right now.",
    ],
}


class Personality:
    """
    Returns personality-flavoured text for a given MessageType.
    Variables in braces (e.g. {step}, {summary}) are substituted from kwargs.
    """

    @staticmethod
    def get(message_type: MessageType, **kwargs) -> str:
        templates = _TEMPLATES.get(message_type, ["{message_type}"])
        template = random.choice(templates)
        try:
            return template.format(**kwargs)
        except KeyError:
            # Return template as-is if variables are missing
            return template
