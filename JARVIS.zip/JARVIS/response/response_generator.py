"""
response/response_generator.py

Produces natural-language text for all user-facing messages.
Template messages use Personality templates (fast, no LLM call).
Conversational and question responses use watsonx.ai.
"""

from __future__ import annotations

import logging
from typing import Optional

from ai.watsonx_client import WatsonxAIClient
from response.personality import MessageType, Personality

logger = logging.getLogger(__name__)

_PERSONALITY_SYSTEM_PROMPT = """You are JARVIS, a personal AI desktop assistant.
Your personality:
- Intelligent, precise, and capable
- Warm and friendly — uses contractions, natural phrasing
- Occasionally witty, never sarcastic or dismissive
- Concise: short answers unless detail is needed
- Clear and direct when asking for confirmation
- Never uses robotic or overly formal language
- Personality never overrides accuracy, safety, or user instructions

Respond naturally in 1-3 sentences unless the user needs detail.
"""


class ResponseGenerator:
    """
    Builds JARVIS responses.

    For template-based messages (task status, confirmations, errors):
      → Uses Personality templates — fast, no API call.

    For conversational/question responses:
      → Uses watsonx.ai with personality system prompt.
    """

    def __init__(self, client: Optional[WatsonxAIClient] = None) -> None:
        self._client = client

    def generate(self, message_type: MessageType, **kwargs) -> str:
        """Generate a templated personality response."""
        return Personality.get(message_type, **kwargs)

    def converse(self, user_input: str, history: list[dict] = None) -> str:
        """
        Generate a conversational response using the LLM.
        Falls back to a templated reply if LLM is unavailable.
        """
        if not self._client:
            return "I'm here, though my AI brain isn't fully connected yet."

        messages = [{"role": "system", "content": _PERSONALITY_SYSTEM_PROMPT}]
        if history:
            messages.extend(history[-10:])  # last 10 turns for context
        messages.append({"role": "user", "content": user_input})

        try:
            response = self._client.chat(messages)
            return response.strip() if response else "I'm not sure how to respond to that."
        except Exception as exc:
            logger.error("ResponseGenerator.converse error: %s", exc)
            return "I had a hiccup there. Could you try again?"

    def synthesize_search_result(self, original_query: str, raw_results: str) -> str:
        """
        Turn raw DuckDuckGo bullet results into a natural-language answer.

        With a real LLM: sends a synthesis prompt.
        In mock mode: returns a sensible summary of the raw results directly.
        """
        if not self._client:
            return f"Here's what I found for '{original_query}':\n{raw_results[:600]}"

        prompt = (
            f"The user asked: {original_query}\n\n"
            f"Web search results:\n{raw_results[:1200]}\n\n"
            "Based on these results, give a concise, natural-language answer to the "
            "user's question. Summarise the key information in 2–4 sentences. "
            "Do not say 'according to the search results' — just answer directly."
        )
        messages = [
            {"role": "system", "content": _PERSONALITY_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]
        try:
            response = self._client.chat(messages)
            return response.strip() if response else raw_results[:400]
        except Exception as exc:
            logger.error("ResponseGenerator.synthesize_search_result error: %s", exc)
            return f"Here's what I found:\n{raw_results[:400]}"

    def status_update(self, step_description: str) -> str:
        return Personality.get(MessageType.STEP_UPDATE, step=step_description)

    def task_started(self) -> str:
        return Personality.get(MessageType.TASK_STARTED)

    def task_complete(self, summary: str = "") -> str:
        return Personality.get(MessageType.TASK_COMPLETE, summary=summary)

    def task_failed(self, summary: str = "") -> str:
        return Personality.get(MessageType.TASK_FAILED, summary=summary)

    def confirm_action(self, action: str) -> str:
        return Personality.get(MessageType.CONFIRM_ACTION, action=action)

    def confirm_irreversible(self, action: str) -> str:
        return Personality.get(MessageType.CONFIRM_IRREVERSIBLE, action=action)

    def escalate(self, summary: str = "") -> str:
        return Personality.get(MessageType.ESCALATE, summary=summary)
