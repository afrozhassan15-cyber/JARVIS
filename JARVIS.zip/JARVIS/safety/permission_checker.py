"""
safety/permission_checker.py

Hard boundary between safe and unsafe actions.
Called before every tool execution — no action bypasses this.
"""

from __future__ import annotations

import logging
import os

from ai.action_schema import Action
from config.permissions import (
    ACTION_SAFETY_MAP,
    ALLOWED_PATH_PREFIXES,
    IRREVERSIBLE_ACTION_TYPES,
    PermissionResult,
    SafetyLevel,
)

logger = logging.getLogger(__name__)


class PermissionChecker:
    """
    Classifies every action as ALLOW, REQUIRE_CONFIRMATION, or BLOCK.

    The Action Executor calls check() before invoking any tool.
    This is a hard safety boundary that cannot be bypassed by the AI layer.
    """

    def check(self, action: Action) -> PermissionResult:
        """
        Classify an action and return the required permission level.
        """
        level = self._get_safety_level(action)

        if level == SafetyLevel.BLOCKED:
            logger.warning(
                "PermissionChecker: BLOCKED action_type='%s'", action.action_type
            )
            return PermissionResult.BLOCK

        if level in (SafetyLevel.CONFIRM_REQUIRED, SafetyLevel.ELEVATED_CONFIRM):
            logger.info(
                "PermissionChecker: REQUIRE_CONFIRMATION action_type='%s'",
                action.action_type,
            )
            return PermissionResult.REQUIRE_CONFIRMATION

        # Path boundary check for file operations
        if action.action_type in ("read_file", "write_file", "delete_file"):
            path = action.parameters.get("path", "")
            if path and not self._path_is_allowed(path):
                logger.warning(
                    "PermissionChecker: BLOCK — path outside allowed area: %s", path
                )
                return PermissionResult.BLOCK

        return PermissionResult.ALLOW

    def is_irreversible(self, action: Action) -> bool:
        return action.action_type in IRREVERSIBLE_ACTION_TYPES

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _get_safety_level(self, action: Action) -> SafetyLevel:
        return ACTION_SAFETY_MAP.get(action.action_type, SafetyLevel.SAFE)

    @staticmethod
    def _path_is_allowed(path: str) -> bool:
        abs_path = os.path.abspath(os.path.expanduser(path))
        return any(
            abs_path.startswith(prefix)
            for prefix in ALLOWED_PATH_PREFIXES
        )
