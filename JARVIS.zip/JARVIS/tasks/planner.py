"""
tasks/planner.py

Decomposes a natural-language goal into an ordered list of atomic TaskSteps.
Uses IBM watsonx.ai with the planner system prompt.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Optional

from ai.watsonx_client import WatsonxAIClient
from tasks.task import TaskPlan, TaskStep

logger = logging.getLogger(__name__)

_PROMPT_DIR = Path(__file__).parent.parent / "ai" / "prompts"


class Planner:
    """
    Converts a user goal string into a TaskPlan with ordered TaskSteps.

    Each TaskStep contains:
    - description:        what to do
    - action_type:        expected tool action (hint for Primary AI)
    - expected_outcome:   what success looks like (used by StepVerifier)
    - precondition:       what must be true before this step
    - fallback:           what to try if the step fails
    """

    def __init__(self, client: WatsonxAIClient) -> None:
        self._client = client
        self._system_prompt = self._load_prompt()

    def plan(self, goal: str, context_summary: str = "") -> TaskPlan:
        """
        Decompose a goal into a TaskPlan.

        Args:
            goal:            the user's goal
            context_summary: optional world state or conversation context

        Returns:
            TaskPlan with a list of TaskStep objects
        """
        user_message = f"Goal: {goal}"
        if context_summary:
            user_message += f"\nContext: {context_summary}"

        messages = [
            {"role": "system", "content": self._system_prompt},
            {"role": "user",   "content": user_message},
        ]

        raw = self._client.chat(messages)
        logger.debug("Planner raw response: %s", raw[:400])
        plan = self._parse_plan(raw, goal)
        logger.info("Planner: %d steps for goal='%s'", len(plan.steps), goal[:50])
        return plan

    def replan(self, original_goal: str, completed_steps: list[TaskStep],
               error_description: str, current_screen_text: str = "") -> TaskPlan:
        """
        Re-plan remaining steps after an error.

        Args:
            original_goal:     the original user goal
            completed_steps:   steps already completed successfully
            error_description: what went wrong on the failed step
            current_screen_text: current screen OCR text
        """
        completed_summary = "\n".join(
            f"  ✓ {s.description}" for s in completed_steps
        ) or "  (none)"

        user_message = (
            f"Goal: {original_goal}\n\n"
            f"Steps already completed:\n{completed_summary}\n\n"
            f"What went wrong: {error_description}\n"
            f"Current screen:\n{current_screen_text[:300]}\n\n"
            f"Please create a NEW plan for the REMAINING steps only, "
            f"starting from the current state."
        )
        messages = [
            {"role": "system", "content": self._system_prompt},
            {"role": "user",   "content": user_message},
        ]

        raw = self._client.chat(messages)
        plan = self._parse_plan(raw, original_goal)
        logger.info("Replanner: %d new steps", len(plan.steps))
        return plan

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _parse_plan(self, raw: str, goal: str) -> TaskPlan:
        data = self._extract_json(raw)
        steps_data = data.get("steps", [])
        steps = []
        for i, s in enumerate(steps_data):
            step = TaskStep(
                id=s.get("id", f"s{i+1}"),
                description=s.get("description", f"Step {i+1}"),
                action_type=s.get("action_type", ""),
                expected_outcome=s.get("expected_outcome", ""),
                precondition=s.get("precondition", ""),
                fallback=s.get("fallback", ""),
            )
            steps.append(step)

        if not steps:
            # Fallback: single generic step
            logger.warning("Planner returned no steps — creating fallback single step")
            steps = [TaskStep(
                id="s1",
                description=goal,
                action_type="converse",
                expected_outcome="Task completed",
            )]

        return TaskPlan(goal=goal, steps=steps)

    @staticmethod
    def _extract_json(text: str) -> dict:
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass
        logger.warning("Planner: could not extract JSON from response.")
        return {}

    def _load_prompt(self) -> str:
        path = _PROMPT_DIR / "planner_system_prompt.txt"
        if path.exists():
            return path.read_text(encoding="utf-8")
        logger.warning("Planner prompt not found: %s", path)
        return ""
