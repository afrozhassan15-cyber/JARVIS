"""
tasks/task.py

Task, TaskStep, and TaskStatus dataclasses.
These are the core data structures for the task management system.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional
import uuid


class TaskStatus(str, Enum):
    PENDING    = "PENDING"
    ACTIVE     = "ACTIVE"
    VERIFYING  = "VERIFYING"   # AI is evaluating the next action
    EXECUTING  = "EXECUTING"   # Tool is running
    OBSERVING  = "OBSERVING"   # Observer is capturing state
    PAUSED     = "PAUSED"
    COMPLETED  = "COMPLETED"
    FAILED     = "FAILED"
    CANCELLED  = "CANCELLED"
    WAITING    = "WAITING"     # Awaiting user confirmation or clarification


class TaskPriority(int, Enum):
    CRITICAL   = 0    # Interrupts everything immediately
    HIGH       = 1    # Pauses current task after current step
    NORMAL     = 2    # Queued after current task
    BACKGROUND = 3    # Only runs when nothing else is active


@dataclass
class TaskStep:
    """A single atomic step within a task plan."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    description: str = ""               # natural language description
    action_type: str = ""               # expected action type (hint for AI)
    expected_outcome: str = ""          # what success looks like (for StepVerifier)
    precondition: str = ""              # what must be true before this step runs
    fallback: str = ""                  # what to try if this step fails
    status: TaskStatus = TaskStatus.PENDING
    retry_count: int = 0
    result_summary: str = ""            # populated after step completes/fails


@dataclass
class TaskPlan:
    """An ordered list of steps for achieving a goal."""
    goal: str
    steps: list[TaskStep] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)

    @property
    def total_steps(self) -> int:
        return len(self.steps)

    @property
    def completed_steps(self) -> int:
        return sum(1 for s in self.steps if s.status == TaskStatus.COMPLETED)


@dataclass
class Task:
    """Represents a complete user-requested task with its lifecycle state."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    goal: str = ""
    priority: TaskPriority = TaskPriority.NORMAL
    status: TaskStatus = TaskStatus.PENDING
    plan: Optional[TaskPlan] = None
    current_step_index: int = 0
    replan_count: int = 0
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error_summary: str = ""

    @property
    def current_step(self) -> Optional[TaskStep]:
        if self.plan and 0 <= self.current_step_index < len(self.plan.steps):
            return self.plan.steps[self.current_step_index]
        return None

    @property
    def is_terminal(self) -> bool:
        return self.status in (
            TaskStatus.COMPLETED,
            TaskStatus.FAILED,
            TaskStatus.CANCELLED,
        )

    @property
    def progress_summary(self) -> str:
        if not self.plan:
            return "No plan yet"
        return f"Step {self.current_step_index + 1}/{self.plan.total_steps}"

    def __str__(self) -> str:
        return f"Task({self.id[:8]} | {self.status.value} | {self.goal[:40]})"
