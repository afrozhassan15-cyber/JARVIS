"""
tasks/task_manager.py

Owns the full lifecycle of all JARVIS tasks.
Manages state transitions, task queue, and priority ordering.
"""

from __future__ import annotations

import logging
from collections import deque
from datetime import datetime
from threading import Event, RLock
from typing import Optional

from tasks.task import Task, TaskPriority, TaskStatus

logger = logging.getLogger(__name__)


class TaskManager:
    """
    Creates, queues, activates, pauses, resumes, and cancels tasks.

    State machine per task:
      PENDING → ACTIVE → {VERIFYING, EXECUTING, OBSERVING} → COMPLETED
      ACTIVE  → PAUSED  → ACTIVE (resume)
      ACTIVE  → WAITING → ACTIVE (user confirms)
      ACTIVE  → FAILED  (retries/replans exhausted)
      any     → CANCELLED (user cancels)
    """

    def __init__(self) -> None:
        self._lock       = RLock()
        self._tasks: dict[str, Task] = {}
        self._active_id: Optional[str] = None
        self._paused_id: Optional[str] = None
        self._queue: deque[str] = deque()  # task IDs in priority order
        # Event used by execution loop to signal user-answered a WAITING prompt
        self._user_response_event: Event = Event()
        self._user_response_value: Optional[str] = None

    # ── Task creation ─────────────────────────────────────────────────────────

    def create_task(
        self, goal: str, priority: TaskPriority = TaskPriority.NORMAL
    ) -> Task:
        task = Task(goal=goal, priority=priority)
        with self._lock:
            self._tasks[task.id] = task
            self._enqueue(task.id, priority)
        logger.info("Task created: %s", task)
        return task

    def _enqueue(self, task_id: str, priority: TaskPriority) -> None:
        """Insert task_id into queue respecting priority order."""
        # Convert deque to list, insert in right spot, convert back
        items = list(self._queue)
        insert_pos = len(items)
        for i, tid in enumerate(items):
            t = self._tasks.get(tid)
            if t and t.priority > priority:
                insert_pos = i
                break
        items.insert(insert_pos, task_id)
        self._queue = deque(items)

    # ── Lifecycle operations ──────────────────────────────────────────────────

    def activate_next(self) -> Optional[Task]:
        """
        Activate the next queued task (highest priority first).
        Returns the activated Task, or None if queue is empty.
        """
        with self._lock:
            while self._queue:
                task_id = self._queue.popleft()
                task = self._tasks.get(task_id)
                if task and task.status == TaskStatus.PENDING:
                    task.status = TaskStatus.ACTIVE
                    task.started_at = datetime.now()
                    self._active_id = task_id
                    logger.info("Task activated: %s", task)
                    return task
        return None

    def activate_task(self, task_id: str) -> bool:
        """Force-activate a specific task by ID."""
        with self._lock:
            task = self._tasks.get(task_id)
            if task and task.status == TaskStatus.PENDING:
                task.status = TaskStatus.ACTIVE
                task.started_at = datetime.now()
                self._active_id = task_id
                # Remove from queue if it's there
                if task_id in self._queue:
                    q_list = list(self._queue)
                    q_list.remove(task_id)
                    self._queue = deque(q_list)
                logger.info("Task force-activated: %s", task)
                return True
        return False

    def pause_task(self, task_id: str) -> bool:
        with self._lock:
            task = self._tasks.get(task_id)
            if task and task.status in (
                TaskStatus.ACTIVE, TaskStatus.VERIFYING,
                TaskStatus.EXECUTING, TaskStatus.OBSERVING
            ):
                task.status = TaskStatus.PAUSED
                self._paused_id = task_id
                if self._active_id == task_id:
                    self._active_id = None
                logger.info("Task paused: %s", task)
                return True
        return False

    def resume_task(self, task_id: str) -> bool:
        with self._lock:
            task = self._tasks.get(task_id)
            if task and task.status == TaskStatus.PAUSED:
                task.status = TaskStatus.ACTIVE
                self._active_id = task_id
                self._paused_id = None
                logger.info("Task resumed: %s", task)
                return True
        return False

    def complete_task(self, task_id: str, summary: str = "") -> None:
        with self._lock:
            task = self._tasks.get(task_id)
            if task:
                task.status = TaskStatus.COMPLETED
                task.completed_at = datetime.now()
                if self._active_id == task_id:
                    self._active_id = None
                logger.info("Task completed: %s", task)

    def fail_task(self, task_id: str, reason: str = "") -> None:
        with self._lock:
            task = self._tasks.get(task_id)
            if task:
                task.status = TaskStatus.FAILED
                task.error_summary = reason
                task.completed_at = datetime.now()
                if self._active_id == task_id:
                    self._active_id = None
                logger.warning("Task failed: %s | %s", task, reason)

    def cancel_task(self, task_id: str) -> None:
        with self._lock:
            task = self._tasks.get(task_id)
            if task:
                task.status = TaskStatus.CANCELLED
                task.completed_at = datetime.now()
                if self._active_id == task_id:
                    self._active_id = None
                # Also remove from queue
                if task_id in self._queue:
                    q_list = list(self._queue)
                    if task_id in q_list:
                        q_list.remove(task_id)
                    self._queue = deque(q_list)
                logger.info("Task cancelled: %s", task)

    def set_waiting(self, task_id: str) -> None:
        with self._lock:
            task = self._tasks.get(task_id)
            if task:
                task.status = TaskStatus.WAITING
                self._user_response_event.clear()

    def provide_user_response(self, response: str) -> None:
        """Called when the user answers a WAITING prompt."""
        self._user_response_value = response
        self._user_response_event.set()

    def wait_for_user_response(self, timeout: float = 120.0) -> Optional[str]:
        """Block until user responds or timeout."""
        if self._user_response_event.wait(timeout=timeout):
            return self._user_response_value
        return None

    # ── Queries ───────────────────────────────────────────────────────────────

    def get_active_task(self) -> Optional[Task]:
        with self._lock:
            return self._tasks.get(self._active_id) if self._active_id else None

    def get_paused_task(self) -> Optional[Task]:
        with self._lock:
            return self._tasks.get(self._paused_id) if self._paused_id else None

    def get_task(self, task_id: str) -> Optional[Task]:
        with self._lock:
            return self._tasks.get(task_id)

    def cancel_all(self) -> None:
        """Cancel every pending and active task (emergency stop)."""
        with self._lock:
            for task in self._tasks.values():
                if not task.is_terminal:
                    task.status = TaskStatus.CANCELLED
            self._active_id = None
            self._paused_id = None
            self._queue.clear()
        logger.warning("All tasks cancelled (emergency stop)")
