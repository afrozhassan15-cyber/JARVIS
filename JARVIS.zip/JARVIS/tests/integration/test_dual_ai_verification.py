"""
tests/integration/test_dual_ai_verification.py

Integration tests for the Primary AI → Verifier AI → Policy Engine pipeline.
Uses mock WatsonxAIClient — no real API calls.
"""
import pytest
from ai.action_schema import Action, ActionProposal, PolicyDecision, Verdict, VerifierResult
from ai.policy_engine import VerificationPolicyEngine
from ai.primary_ai import PrimaryAI
from ai.verifier_ai import VerifierAI
from ai.watsonx_client import WatsonxAIClient
from tasks.task import TaskStep


@pytest.fixture
def client():
    return WatsonxAIClient()  # mock mode


@pytest.fixture
def pipeline(client):
    return PrimaryAI(client), VerifierAI(client), VerificationPolicyEngine()


def _step(desc="Open Notepad"):
    return TaskStep(description=desc, action_type="open_application",
                    expected_outcome="Notepad is open")


# ── Propose → Evaluate → Decide ───────────────────────────────────────────────

def test_full_pipeline_produces_decision(pipeline):
    pai, vai, engine = pipeline
    step = _step()
    proposal = pai.propose_action(step)
    result    = vai.evaluate(proposal, step)
    decision  = engine.decide(proposal, result)
    assert decision in list(PolicyDecision)


def test_unsafe_risk_always_blocked(pipeline):
    _, _, engine = pipeline
    # Manually craft a scenario where verifier flags unsafe_action
    proposal = ActionProposal(
        action=Action(action_type="delete_file"),
        reasoning="needed",
        confidence=0.95,
    )
    verifier_result = VerifierResult(
        verdict=Verdict.REJECT,
        confidence=0.92,
        risks=["unsafe_action"],
    )
    assert engine.decide(proposal, verifier_result) == PolicyDecision.BLOCK


def test_irreversible_always_asks_user(pipeline):
    _, _, engine = pipeline
    proposal = ActionProposal(
        action=Action(action_type="send_email", is_irreversible=True),
        reasoning="user asked",
        confidence=0.95,
    )
    verifier_result = VerifierResult(verdict=Verdict.APPROVE, confidence=0.90)
    assert engine.decide(proposal, verifier_result) == PolicyDecision.ASK_USER


def test_reconsider_loop_respected(pipeline):
    """After 3 reconsiderations, policy engine escalates regardless of scores."""
    _, _, engine = pipeline
    proposal = ActionProposal(
        action=Action(action_type="open_application"),
        reasoning="test",
        confidence=0.85,
        reconsider_count=3,
    )
    verifier_result = VerifierResult(verdict=Verdict.REJECT, confidence=0.55)
    assert engine.decide(proposal, verifier_result) == PolicyDecision.ESCALATE


def test_revision_increments_reconsider_count(pipeline):
    pai, _, _ = pipeline
    step = _step()
    original = ActionProposal(
        action=Action(action_type="open_application"),
        reasoning="first",
        confidence=0.7,
        reconsider_count=0,
    )
    revised = pai.revise_action(step, original, "wrong_target")
    assert revised.reconsider_count == 1


def test_higher_confidence_does_not_automatically_win():
    """
    Demonstrates that the AI with higher confidence does NOT automatically win.
    A low-confidence verifier REJECT with PAI medium → RECONSIDER, not EXECUTE.
    """
    engine = VerificationPolicyEngine()
    # PAI has high confidence (0.85) but Verifier rejects with low conf (0.35)
    proposal = ActionProposal(
        action=Action(action_type="click"),
        reasoning="click submit",
        confidence=0.85,
    )
    verifier_result = VerifierResult(
        verdict=Verdict.REJECT,
        confidence=0.35,
        risks=["wrong_target"],
    )
    decision = engine.decide(proposal, verifier_result)
    # Should RECONSIDER — not EXECUTE just because PAI had higher confidence
    assert decision == PolicyDecision.RECONSIDER
