"""
tests/integration/test_error_recovery.py

Integration tests for the error recovery pipeline.
"""
import pytest
from observation.error_handler import ErrorHandler, RecoveryStrategy
from observation.step_verifier import StepVerifier
from ai.action_schema import VerificationResult
from ai.watsonx_client import WatsonxAIClient
from core.context_manager import WorldState
from tasks.task import TaskStep, TaskStatus


@pytest.fixture
def handler():
    return ErrorHandler()


@pytest.fixture
def verifier():
    return StepVerifier(WatsonxAIClient())


def test_retry_budget_respected():
    """Simulates a step being retried up to MAX_STEP_RETRIES times."""
    from config.thresholds import MAX_STEP_RETRIES
    step = TaskStep(description="click submit", expected_outcome="form submitted")
    
    retry_count = 0
    while retry_count < MAX_STEP_RETRIES:
        step.retry_count += 1
        retry_count += 1
    
    assert step.retry_count == MAX_STEP_RETRIES


def test_environment_changed_triggers_replan(handler):
    step = TaskStep(description="click save", expected_outcome="file saved")
    world = WorldState(visible_text="unexpected login screen", window_title="Login")
    result = VerificationResult(
        passed=False, confidence=0.2,
        explanation="Unexpected login screen", error_type="environment_changed"
    )
    classification = handler.classify(step, world, result)
    assert classification.strategy == RecoveryStrategy.REPLAN


def test_app_not_open_waits_then_retries(handler):
    step = TaskStep(description="type text", expected_outcome="text typed in notepad")
    world = WorldState(visible_text="Desktop", window_title="")
    result = VerificationResult(
        passed=False, confidence=0.3,
        explanation="Notepad not found", error_type="app_not_open"
    )
    classification = handler.classify(step, world, result)
    assert classification.strategy == RecoveryStrategy.WAIT_AND_RETRY
    assert classification.wait_seconds >= 2.0


def test_step_verifier_rule_based_pass(verifier):
    step = TaskStep(
        description="Open Notepad",
        expected_outcome="Notepad application visible and open"
    )
    world = WorldState(visible_text="Untitled - Notepad", window_title="Notepad")
    result = verifier.verify(step, world)
    assert result.passed is True


def test_step_verifier_rule_based_fail(verifier):
    step = TaskStep(
        description="Open Notepad",
        expected_outcome="Notepad application visible and open"
    )
    world = WorldState(visible_text="File Explorer", window_title="This PC")
    result = verifier.verify(step, world)
    assert result.passed is False
