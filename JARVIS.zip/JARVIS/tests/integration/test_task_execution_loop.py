"""
tests/integration/test_task_execution_loop.py

Integration tests for the task creation → planning → execution state machine.
Uses mock AI components — no real API calls, no computer control.
"""
import pytest
from unittest.mock import MagicMock, patch
from tasks.task import Task, TaskPlan, TaskStep, TaskStatus, TaskPriority
from tasks.task_manager import TaskManager
from tasks.planner import Planner
from ai.watsonx_client import WatsonxAIClient


@pytest.fixture
def client():
    return WatsonxAIClient()  # mock mode


@pytest.fixture
def planner(client):
    return Planner(client)


@pytest.fixture
def task_mgr():
    return TaskManager()


def test_task_lifecycle_pending_to_active(task_mgr):
    task = task_mgr.create_task("open notepad")
    assert task.status == TaskStatus.PENDING
    task_mgr.activate_task(task.id)
    assert task.status == TaskStatus.ACTIVE


def test_task_pause_serialises_step_index(task_mgr):
    task = task_mgr.create_task("open notepad and type hello")
    task_mgr.activate_task(task.id)
    task.current_step_index = 1  # simulate partial progress
    task_mgr.pause_task(task.id)
    assert task.status == TaskStatus.PAUSED
    assert task.current_step_index == 1  # context preserved


def test_task_resume_restores_active(task_mgr):
    task = task_mgr.create_task("test")
    task_mgr.activate_task(task.id)
    task_mgr.pause_task(task.id)
    task_mgr.resume_task(task.id)
    assert task.status == TaskStatus.ACTIVE


def test_planner_creates_steps_for_multi_step_goal(planner):
    plan = planner.plan("open Notepad and type Hello World")
    assert len(plan.steps) >= 2
    for step in plan.steps:
        assert step.description
        assert step.expected_outcome


def test_task_with_plan_has_current_step(task_mgr, planner):
    task = task_mgr.create_task("open notepad")
    task_mgr.activate_task(task.id)
    task.plan = planner.plan(task.goal)
    assert task.current_step is not None
    assert isinstance(task.current_step, TaskStep)


def test_task_progress_summary(task_mgr, planner):
    task = task_mgr.create_task("open notepad")
    task_mgr.activate_task(task.id)
    task.plan = planner.plan(task.goal)
    summary = task.progress_summary
    assert "/" in summary


def test_multiple_tasks_priority_order(task_mgr):
    t1 = task_mgr.create_task("background", TaskPriority.BACKGROUND)
    t2 = task_mgr.create_task("normal",     TaskPriority.NORMAL)
    t3 = task_mgr.create_task("high",       TaskPriority.HIGH)

    first = task_mgr.activate_next()
    assert first.priority == TaskPriority.HIGH


def test_cancel_removes_from_queue(task_mgr):
    task = task_mgr.create_task("test")
    task_mgr.cancel_task(task.id)
    assert task.status == TaskStatus.CANCELLED
    # Attempting to activate should skip this task
    next_task = task_mgr.activate_next()
    assert next_task is None  # nothing left


def test_interruption_pauses_active(task_mgr):
    t1 = task_mgr.create_task("long task")
    task_mgr.activate_task(t1.id)
    assert task_mgr.get_active_task().id == t1.id

    # Interruption: pause t1 and create t2
    task_mgr.pause_task(t1.id)
    t2 = task_mgr.create_task("urgent task", TaskPriority.HIGH)
    task_mgr.activate_task(t2.id)

    assert task_mgr.get_active_task().id == t2.id
    assert task_mgr.get_paused_task().id == t1.id
