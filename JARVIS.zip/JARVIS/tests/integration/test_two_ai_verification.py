"""
tests/integration/test_two_ai_verification.py

Integration tests for the two-AI verification pipeline.
Includes new tests for smarter mock verifier behaviour.

Preserves all original tests from test_dual_ai_verification.py.
"""

import pytest
from ai.action_schema import Action, ActionProposal, PolicyDecision, Verdict, VerifierResult
from ai.policy_engine import VerificationPolicyEngine
from ai.primary_ai import PrimaryAI
from ai.verifier_ai import VerifierAI
from ai.watsonx_client import WatsonxAIClient
from tasks.task import TaskStep


@pytest.fixture
def client():
    return WatsonxAIClient()  # mock mode


@pytest.fixture
def pipeline(client):
    return PrimaryAI(client), VerifierAI(client), VerificationPolicyEngine()


def _step(desc="Open Notepad", action_type="open_application"):
    return TaskStep(
        description=desc,
        action_type=action_type,
        expected_outcome="Application is open",
    )


# ══ Original tests (preserved) ════════════════════════════════════════════════

def test_full_pipeline_produces_decision(pipeline):
    pai, vai, engine = pipeline
    step = _step()
    proposal = pai.propose_action(step)
    result    = vai.evaluate(proposal, step)
    decision  = engine.decide(proposal, result)
    assert decision in list(PolicyDecision)


def test_unsafe_risk_always_blocked(pipeline):
    _, _, engine = pipeline
    proposal = ActionProposal(
        action=Action(action_type="delete_file"),
        reasoning="needed",
        confidence=0.95,
    )
    verifier_result = VerifierResult(
        verdict=Verdict.REJECT,
        confidence=0.92,
        risks=["unsafe_action"],
    )
    assert engine.decide(proposal, verifier_result) == PolicyDecision.BLOCK


def test_irreversible_always_asks_user(pipeline):
    _, _, engine = pipeline
    proposal = ActionProposal(
        action=Action(action_type="send_email", is_irreversible=True),
        reasoning="user asked",
        confidence=0.95,
    )
    verifier_result = VerifierResult(verdict=Verdict.APPROVE, confidence=0.90)
    assert engine.decide(proposal, verifier_result) == PolicyDecision.ASK_USER


def test_reconsider_loop_respected(pipeline):
    """After 3 reconsiderations, policy engine escalates regardless of scores."""
    _, _, engine = pipeline
    proposal = ActionProposal(
        action=Action(action_type="open_application"),
        reasoning="test",
        confidence=0.85,
        reconsider_count=3,
    )
    verifier_result = VerifierResult(verdict=Verdict.REJECT, confidence=0.55)
    assert engine.decide(proposal, verifier_result) == PolicyDecision.ESCALATE


def test_revision_increments_reconsider_count(pipeline):
    pai, _, _ = pipeline
    step = _step()
    original = ActionProposal(
        action=Action(action_type="open_application"),
        reasoning="first",
        confidence=0.7,
        reconsider_count=0,
    )
    revised = pai.revise_action(step, original, "wrong_target")
    assert revised.reconsider_count == 1


def test_higher_confidence_does_not_automatically_win():
    engine = VerificationPolicyEngine()
    proposal = ActionProposal(
        action=Action(action_type="click"),
        reasoning="click submit",
        confidence=0.85,
    )
    verifier_result = VerifierResult(
        verdict=Verdict.REJECT,
        confidence=0.35,
        risks=["wrong_target"],
    )
    decision = engine.decide(proposal, verifier_result)
    assert decision == PolicyDecision.RECONSIDER


# ══ New tests for smarter mock verifier ═══════════════════════════════════════

def test_full_pipeline_approves_correct_action(pipeline):
    """
    open_application step + open_application proposed action → EXECUTE or ASK_USER
    (not BLOCK, not ESCALATE from a wrong-type rejection).
    """
    pai, vai, engine = pipeline
    step = _step(desc="Open Notepad", action_type="open_application")
    proposal = pai.propose_action(step)
    result = vai.evaluate(proposal, step)
    decision = engine.decide(proposal, result)
    # Should not be BLOCK or ESCALATE for a valid open_application action
    assert decision not in (PolicyDecision.BLOCK,)


def test_verifier_rejects_converse_for_computer_task():
    """
    When proposed action_type is 'converse' but the step's action_type hint is
    'open_application' (a computer task), the mock verifier should REJECT.
    """
    client = WatsonxAIClient()  # mock mode
    vai = VerifierAI(client)

    step = TaskStep(
        description="Open Calculator",
        action_type="open_application",
        expected_outcome="Calculator window is open",
    )
    # Manually craft a converse proposal
    proposal = ActionProposal(
        action=Action(action_type="converse", parameters={"message": "Opening calculator"}),
        reasoning="fallback",
        confidence=0.5,
    )

    result = vai.evaluate(proposal, step)

    assert result.verdict == Verdict.REJECT
    assert "wrong_action_type" in result.risks


def test_revision_loop_produces_different_action(pipeline):
    """
    After a REJECT with wrong_action_type, the revised action should differ
    from 'converse'.
    """
    pai, vai, engine = pipeline

    step = TaskStep(
        description="Open Notepad",
        action_type="open_application",
        expected_outcome="Notepad is visible",
    )

    # Start with a converse proposal (the AI's "bad" first guess)
    bad_proposal = ActionProposal(
        action=Action(action_type="converse", parameters={"message": "opening"}),
        reasoning="initial",
        confidence=0.5,
        reconsider_count=0,
    )

    verifier_result = vai.evaluate(bad_proposal, step)
    # Should be REJECT since proposed=converse, hint=open_application
    assert verifier_result.verdict == Verdict.REJECT

    feedback = verifier_result.suggested_correction or "wrong_action_type"
    revised = pai.revise_action(step, bad_proposal, feedback)

    # The revised action should not be converse
    assert revised.action.action_type != "converse"


def test_verifier_approves_matching_action():
    """
    When the proposed action matches the step hint, the mock verifier approves.
    """
    client = WatsonxAIClient()
    vai = VerifierAI(client)

    step = TaskStep(
        description="Type hello into notepad",
        action_type="type_text",
        expected_outcome="Text 'hello' appears",
    )
    proposal = ActionProposal(
        action=Action(action_type="type_text", parameters={"text": "hello"}),
        reasoning="direct",
        confidence=0.85,
    )

    result = vai.evaluate(proposal, step)
    assert result.verdict == Verdict.APPROVE
    assert result.confidence > 0.5
