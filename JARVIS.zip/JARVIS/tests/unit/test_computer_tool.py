"""
tests/unit/test_computer_tool.py

Unit tests for ComputerControlTool.
All pyautogui / keyboard / pygetwindow calls are patched — no real system actions.
"""
from __future__ import annotations

import pytest
from unittest.mock import MagicMock, patch, call

from ai.action_schema import Action
from tools.computer_control.computer_tool import ComputerControlTool


@pytest.fixture
def tool():
    return ComputerControlTool()


# ── converse action ────────────────────────────────────────────────────────────

def test_converse_action_returns_message(tool):
    action = Action(action_type="converse", parameters={"message": "Hello, how can I help?"})
    result = tool.execute(action)
    assert result.success is True
    assert result.output == "Hello, how can I help?"


def test_converse_action_empty_message_still_succeeds(tool):
    action = Action(action_type="converse", parameters={})
    result = tool.execute(action)
    assert result.success is True


# ── type_text action ───────────────────────────────────────────────────────────

def test_type_text_uses_keyboard_write(tool):
    """keyboard.write() should be tried first for full Unicode support."""
    with patch("keyboard.write") as mock_kb:
        action = Action(action_type="type_text", parameters={"text": "Hello World"})
        result = tool.execute(action)
    mock_kb.assert_called_once_with("Hello World", delay=0.04)
    assert result.success is True
    assert "Hello World" in result.output


def test_type_text_falls_back_to_pyautogui_when_keyboard_missing(tool):
    """If keyboard is unavailable, pyautogui.write() should be used."""
    import sys

    # Simulate keyboard not being importable
    with patch.dict(sys.modules, {"keyboard": None}):
        with patch("pyautogui.write") as mock_pag:
            action = Action(action_type="type_text", parameters={"text": "Hello"})
            result = tool.execute(action)
    mock_pag.assert_called_once_with("Hello", interval=0.04)
    assert result.success is True


def test_type_text_empty_text_fails(tool):
    action = Action(action_type="type_text", parameters={"text": ""})
    result = tool.execute(action)
    assert result.success is False
    assert "No text provided" in result.error_message


def test_type_text_missing_param_fails(tool):
    action = Action(action_type="type_text", parameters={})
    result = tool.execute(action)
    assert result.success is False


# ── open_application action ────────────────────────────────────────────────────

def test_open_application_calls_subprocess(tool):
    with patch("subprocess.Popen") as mock_popen, \
         patch.object(tool, "_try_focus_window", return_value=MagicMock(success=True)):
        action = Action(action_type="open_application", parameters={"name": "notepad"})
        result = tool.execute(action)
    mock_popen.assert_called_once()
    assert result.success is True


def test_open_application_empty_name_fails(tool):
    action = Action(action_type="open_application", parameters={"name": ""})
    result = tool.execute(action)
    assert result.success is False
    assert "No application name" in result.error_message


def test_open_application_resolves_alias(tool):
    """'notepad' should resolve to 'notepad.exe'."""
    with patch("subprocess.Popen") as mock_popen, \
         patch.object(tool, "_try_focus_window", return_value=MagicMock(success=True)):
        action = Action(action_type="open_application", parameters={"name": "notepad"})
        tool.execute(action)
    cmd = mock_popen.call_args[0][0]
    assert "notepad.exe" in cmd.lower()


# ── click action (keyboard-only, no mouse) ────────────────────────────────────

def test_click_uses_tab_key_not_mouse(tool):
    """Click must NOT call pyautogui.click() — only Tab for focus."""
    with patch("pyautogui.press") as mock_press, \
         patch("pyautogui.click") as mock_click:
        action = Action(action_type="click", parameters={"target": "submit button"})
        result = tool.execute(action)
    mock_press.assert_called_with("tab")
    mock_click.assert_not_called()
    assert result.success is True


# ── press_key action ───────────────────────────────────────────────────────────

def test_press_key_no_modifiers(tool):
    with patch("pyautogui.press") as mock_press:
        action = Action(action_type="press_key", parameters={"key": "enter"})
        result = tool.execute(action)
    mock_press.assert_called_once_with("enter")
    assert result.success is True


def test_press_key_with_modifiers(tool):
    with patch("pyautogui.hotkey") as mock_hotkey:
        action = Action(action_type="press_key",
                        parameters={"key": "a", "modifiers": ["ctrl"]})
        result = tool.execute(action)
    mock_hotkey.assert_called_once_with("ctrl", "a")
    assert result.success is True


def test_press_key_empty_key_fails(tool):
    action = Action(action_type="press_key", parameters={})
    result = tool.execute(action)
    assert result.success is False


# ── focus_application action ───────────────────────────────────────────────────

def test_focus_application_delegates_to_try_focus_window(tool):
    with patch.object(tool, "_try_focus_window", return_value=MagicMock(success=True)) as mock_focus:
        action = Action(action_type="focus_application", parameters={"name": "notepad"})
        tool.execute(action)
    mock_focus.assert_called_once_with("notepad")


# ── unknown action type ────────────────────────────────────────────────────────

def test_unknown_action_type_returns_failure(tool):
    action = Action(action_type="launch_rocket", parameters={})
    result = tool.execute(action)
    assert result.success is False
    assert "Unknown action" in result.error_message


# ── can_handle ────────────────────────────────────────────────────────────────

def test_can_handle_known_actions(tool):
    for action_type in ["open_application", "type_text", "press_key", "scroll",
                        "take_screenshot", "read_screen", "converse", "focus_application"]:
        assert tool.can_handle(Action(action_type=action_type)), \
            f"Expected can_handle to be True for '{action_type}'"


def test_cannot_handle_unknown_action(tool):
    assert tool.can_handle(Action(action_type="unknown_xyz")) is False
