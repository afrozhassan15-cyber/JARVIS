"""
tests/unit/test_duplicate_prevention.py

Verifies that the GUI's _on_send() no longer adds the user message directly,
and that handle_input() logs each turn exactly once via the event bus.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch, call

import pytest


# ── GUI: _on_send must not call add_message directly ─────────────────────────

class TestGuiSendNoDuplicate:

    def _make_window(self):
        """
        Build a minimal AppWindow-like object whose _on_send we can inspect
        without actually launching a Tk/CustomTk window.
        """
        import gui.app_window as mod
        import inspect
        # Pull the _on_send source — check it does NOT contain add_message
        src = inspect.getsource(mod.AppWindow._on_send)
        return src

    def test_gui_send_does_not_call_add_message_directly(self):
        """
        AppWindow._on_send must NOT contain a call to self._conversation_panel.add_message.
        The message arrives via the GUI_LOG_MESSAGE event fired by handle_input().
        """
        src = self._make_window()
        assert "add_message" not in src, (
            "_on_send still calls add_message directly — "
            "this will cause duplicate messages in the UI."
        )


# ── Orchestrator: handle_input logs exactly one user turn ─────────────────────

class TestHandleInputLogsOnce:
    """
    handle_input() must:
      1. Call ctx.add_turn("user", ...) exactly once.
      2. Publish GUI_LOG_MESSAGE with role="user" exactly once.
    """

    def _make_orchestrator(self):
        """
        Return an Orchestrator instance with all heavy components mocked out.
        We only care about the ctx.add_turn and _log_gui paths.
        """
        from config.config import AppConfig
        from core.event_bus import EventBus
        from core.context_manager import ContextManager
        from core.orchestrator import Orchestrator
        from understanding.input_types import InputType, ParsedInput

        cfg = AppConfig()
        bus = EventBus()
        ctx = ContextManager()

        # Patch enough so __init__ doesn't fail
        with patch("core.orchestrator.WatsonxAIClient"), \
             patch("core.orchestrator.PrimaryAI"), \
             patch("core.orchestrator.VerifierAI"), \
             patch("core.orchestrator.VerificationPolicyEngine"), \
             patch("core.orchestrator.LanguageParser"), \
             patch("core.orchestrator.Planner"), \
             patch("core.orchestrator.TaskManager"), \
             patch("core.orchestrator.Observer"), \
             patch("core.orchestrator.StepVerifier"), \
             patch("core.orchestrator.ErrorHandler"), \
             patch("core.orchestrator.PermissionChecker"), \
             patch("core.orchestrator.ResponseGenerator"), \
             patch("core.orchestrator.TextToSpeech"), \
             patch("core.orchestrator.ToolRegistry"):
            orch = Orchestrator(cfg, bus, ctx)

        return orch, ctx, bus

    def test_handle_input_adds_turn_exactly_once(self):
        orch, ctx, bus = self._make_orchestrator()

        # Stub _route so we don't execute the full pipeline
        orch._route = MagicMock()
        orch._set_voice_state = MagicMock()

        # Spy on ctx.add_turn
        original_add_turn = ctx.add_turn
        add_turn_calls = []
        ctx.add_turn = lambda role, content: (
            add_turn_calls.append((role, content)),
            original_add_turn(role, content)
        )

        orch.handle_input("hello jarvis")

        user_turns = [(r, c) for r, c in add_turn_calls if r == "user"]
        assert len(user_turns) == 1, f"Expected 1 user turn, got {len(user_turns)}"
        assert user_turns[0][1] == "hello jarvis"

    def test_jarvis_response_logged_exactly_once(self):
        """_say() must publish GUI_LOG_MESSAGE with role='jarvis' exactly once."""
        orch, ctx, bus = self._make_orchestrator()

        logged_jarvis = []

        def capture_event(payload):
            if isinstance(payload, dict) and payload.get("role") == "jarvis":
                logged_jarvis.append(payload)

        from core.event_bus import EventType
        bus.subscribe(EventType.GUI_LOG_MESSAGE, capture_event)

        # Mock TTS so _say() doesn't actually speak
        orch._tts = MagicMock()

        orch._say("Hello, I'm JARVIS.")

        assert len(logged_jarvis) == 1
        assert logged_jarvis[0]["text"] == "Hello, I'm JARVIS."

    def test_empty_input_ignored(self):
        """handle_input('') or whitespace-only must not log anything."""
        orch, ctx, bus = self._make_orchestrator()

        add_turn_calls = []
        original = ctx.add_turn
        ctx.add_turn = lambda role, content: (
            add_turn_calls.append((role, content)),
            original(role, content)
        )

        orch.handle_input("   ")
        orch.handle_input("")

        assert add_turn_calls == [], f"Unexpected turns logged: {add_turn_calls}"
