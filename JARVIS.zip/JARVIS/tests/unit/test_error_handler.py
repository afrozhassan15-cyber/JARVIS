"""
tests/unit/test_error_handler.py
"""
import pytest
from observation.error_handler import (ErrorHandler, ErrorType,
                                        RecoveryStrategy, ErrorClassification)
from ai.action_schema import VerificationResult
from core.context_manager import WorldState
from tasks.task import TaskStep


@pytest.fixture
def handler():
    return ErrorHandler()


def _world():
    return WorldState()


def _step(desc="open notepad"):
    return TaskStep(description=desc, expected_outcome="Notepad open")


def _vresult(error_type: str, explanation: str = ""):
    return VerificationResult(passed=False, confidence=0.3,
                               explanation=explanation, error_type=error_type)


def test_element_not_found_retry(handler):
    r = handler.classify(_step(), _world(), _vresult("element_not_found"))
    assert r.error_type == ErrorType.ELEMENT_NOT_FOUND
    assert r.strategy == RecoveryStrategy.RETRY


def test_wrong_screen_state_retry(handler):
    r = handler.classify(_step(), _world(), _vresult("wrong_screen_state"))
    assert r.strategy == RecoveryStrategy.RETRY


def test_app_not_open_wait_retry(handler):
    r = handler.classify(_step(), _world(), _vresult("app_not_open"))
    assert r.strategy == RecoveryStrategy.WAIT_AND_RETRY
    assert r.wait_seconds > 0


def test_environment_changed_replan(handler):
    r = handler.classify(_step(), _world(), _vresult("environment_changed"))
    assert r.strategy == RecoveryStrategy.REPLAN


def test_invalid_action_escalate(handler):
    r = handler.classify(_step(), _world(), _vresult("invalid_action"))
    assert r.strategy == RecoveryStrategy.ESCALATE


def test_unknown_error_type_defaults_retry(handler):
    r = handler.classify(_step(), _world(), _vresult("some_new_unknown_type"))
    assert r.strategy == RecoveryStrategy.RETRY
