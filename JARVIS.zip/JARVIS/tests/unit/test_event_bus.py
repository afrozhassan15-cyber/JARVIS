"""
tests/unit/test_event_bus.py
"""
import pytest
from core.event_bus import EventBus, EventType


def test_subscribe_and_publish():
    bus = EventBus()
    received = []
    bus.subscribe("test_event", lambda p: received.append(p))
    bus.publish("test_event", {"key": "value"})
    assert received == [{"key": "value"}]


def test_multiple_subscribers():
    bus = EventBus()
    calls = []
    bus.subscribe("ev", lambda p: calls.append(1))
    bus.subscribe("ev", lambda p: calls.append(2))
    bus.publish("ev", None)
    assert len(calls) == 2


def test_unsubscribe():
    bus = EventBus()
    calls = []
    handler = lambda p: calls.append(p)
    bus.subscribe("ev", handler)
    bus.unsubscribe("ev", handler)
    bus.publish("ev", "x")
    assert calls == []


def test_bad_handler_does_not_stop_others():
    bus = EventBus()
    good_calls = []
    bus.subscribe("ev", lambda p: (_ for _ in ()).throw(RuntimeError("bad")))
    bus.subscribe("ev", lambda p: good_calls.append(p))
    bus.publish("ev", "payload")
    assert good_calls == ["payload"]


def test_clear():
    bus = EventBus()
    calls = []
    bus.subscribe("ev", lambda p: calls.append(p))
    bus.clear()
    bus.publish("ev", "x")
    assert calls == []
