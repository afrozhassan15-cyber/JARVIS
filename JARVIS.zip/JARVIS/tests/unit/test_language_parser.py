"""
tests/unit/test_language_parser.py

Tests LanguageParser rule-based fallback (no API key required).
Also tests that a mock WatsonxAIClient is correctly bypassed in favour
of the rule-based classifier (regression for the Notepad-default bug).
"""
import pytest
from understanding.language_parser import LanguageParser
from understanding.input_types import InputType
from ai.watsonx_client import WatsonxAIClient


@pytest.fixture
def parser():
    """Rule-based parser — no client at all."""
    return LanguageParser(watsonx_client=None)


@pytest.fixture
def parser_mock_client():
    """Parser backed by a mock WatsonxAIClient (no API key).
    Must use the rule-based path, NOT the LLM path, because the mock
    client doesn't produce valid classification JSON."""
    return LanguageParser(watsonx_client=WatsonxAIClient())


# ── Rule-based: control / navigation commands ──────────────────────────────

def test_cancel_command(parser):
    r = parser.parse("stop")
    assert r.input_type == InputType.CANCEL

def test_cancel_abort(parser):
    r = parser.parse("cancel")
    assert r.input_type == InputType.CANCEL

def test_resume_command(parser):
    r = parser.parse("resume the previous task")
    assert r.input_type == InputType.RESUME

def test_interruption(parser):
    r = parser.parse("pause")
    assert r.input_type == InputType.INTERRUPTION

def test_confirmation_yes(parser):
    r = parser.parse("yes")
    assert r.input_type == InputType.CONFIRMATION

def test_confirmation_no(parser):
    r = parser.parse("no")
    assert r.input_type == InputType.CONFIRMATION

# ── Rule-based: computer tasks ─────────────────────────────────────────────

def test_computer_task_open(parser):
    r = parser.parse("open Notepad")
    assert r.input_type == InputType.COMPUTER_TASK

def test_computer_task_type(parser):
    r = parser.parse("type Hello World")
    assert r.input_type == InputType.COMPUTER_TASK

def test_search_task(parser):
    r = parser.parse("search for IBM watsonx")
    assert r.input_type == InputType.COMPUTER_TASK

# ── Rule-based: multi-step tasks ───────────────────────────────────────────

def test_multi_step_task(parser):
    r = parser.parse("open Notepad and then type Hello World")
    assert r.input_type == InputType.MULTI_STEP_TASK

def test_multi_step_comma(parser):
    r = parser.parse("open Notepad, type Hello World")
    assert r.input_type == InputType.MULTI_STEP_TASK

# ── Rule-based: questions ──────────────────────────────────────────────────

def test_question_what(parser):
    r = parser.parse("what is the capital of France?")
    assert r.input_type == InputType.QUESTION

def test_question_how(parser):
    r = parser.parse("how do I make pasta?")
    assert r.input_type == InputType.QUESTION

# ── Rule-based: conversation ───────────────────────────────────────────────

def test_conversation_default(parser):
    r = parser.parse("good morning")
    assert r.input_type == InputType.CONVERSATION

# ── Rule-based: misc ───────────────────────────────────────────────────────

def test_empty_input(parser):
    r = parser.parse("")
    assert r.input_type == InputType.UNKNOWN

def test_parsed_input_raw_text_preserved(parser):
    text = "open Notepad"
    r = parser.parse(text)
    assert r.raw_text == text

# ── Five required routing examples (rule-based) ────────────────────────────

def test_hello_is_conversation(parser):
    """'hello' must route to conversation, never to a computer task."""
    r = parser.parse("hello")
    assert r.input_type == InputType.CONVERSATION

def test_who_are_you_is_conversation(parser):
    """'who are you?' — question about JARVIS → conversational response."""
    r = parser.parse("who are you?")
    # LanguageParser rule-based: starts with "who" → QUESTION, which also
    # routes to _handle_conversation in the orchestrator.
    assert r.input_type in (InputType.CONVERSATION, InputType.QUESTION)

def test_what_is_machine_learning_is_question(parser):
    r = parser.parse("what is machine learning?")
    assert r.input_type == InputType.QUESTION

def test_open_notepad_is_computer_task(parser):
    r = parser.parse("open notepad")
    assert r.input_type == InputType.COMPUTER_TASK

def test_open_notepad_and_type_hello_is_multistep(parser):
    r = parser.parse("open notepad and type hello")
    assert r.input_type == InputType.MULTI_STEP_TASK

# ── Mock-client bypass regression tests ───────────────────────────────────
# These tests confirm that passing a mock WatsonxAIClient to LanguageParser
# does NOT cause the LLM path to be taken (which would return Primary AI
# action JSON with no "input_type" key, misclassifying everything as UNKNOWN).

def test_mock_client_hello_is_conversation(parser_mock_client):
    r = parser_mock_client.parse("hello")
    assert r.input_type == InputType.CONVERSATION

def test_mock_client_open_notepad_is_computer_task(parser_mock_client):
    r = parser_mock_client.parse("open notepad")
    assert r.input_type == InputType.COMPUTER_TASK

def test_mock_client_open_and_type_is_multistep(parser_mock_client):
    r = parser_mock_client.parse("open notepad and type hello")
    assert r.input_type == InputType.MULTI_STEP_TASK

def test_mock_client_question_is_question(parser_mock_client):
    r = parser_mock_client.parse("what is machine learning?")
    assert r.input_type == InputType.QUESTION

def test_mock_client_never_returns_unknown_for_valid_input(parser_mock_client):
    """With a mock client, valid inputs must never fall to UNKNOWN."""
    inputs = [
        "hello", "open notepad", "type hello world",
        "what is AI?", "search for cats", "who are you?",
    ]
    for text in inputs:
        r = parser_mock_client.parse(text)
        assert r.input_type != InputType.UNKNOWN, (
            f"'{text}' classified as UNKNOWN with mock client"
        )

# ── Mock response stub correctness ────────────────────────────────────────
# Verify that _mock_response() itself produces valid JSON for each caller.

def test_mock_response_classification_stub_returns_valid_json():
    """The classification stub must return a dict with 'input_type'."""
    import json
    from ai.watsonx_client import WatsonxAIClient
    from understanding.language_parser import LanguageParser
    client = WatsonxAIClient()
    assert client.is_mock
    lp = LanguageParser._LLM_SYSTEM_PROMPT
    messages = [
        {"role": "system", "content": lp},
        {"role": "user",   "content": "open notepad"},
    ]
    raw = client.chat(messages)
    data = json.loads(raw)
    assert "input_type" in data, f"Missing 'input_type' in: {data}"

def test_mock_response_primary_ai_stub_returns_valid_json():
    """The Primary AI stub must return a dict with 'action_type'."""
    import json
    from ai.watsonx_client import WatsonxAIClient
    from pathlib import Path
    client = WatsonxAIClient()
    prompt_path = Path("ai/prompts/primary_system_prompt.txt")
    system_prompt = prompt_path.read_text(encoding="utf-8") if prompt_path.exists() else \
        "PROPOSE the best next action"
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user",   "content": "open notepad"},
    ]
    raw = client.chat(messages)
    data = json.loads(raw)
    assert "action_type" in data, f"Missing 'action_type' in: {data}"
    assert "parameters" in data, f"Missing 'parameters' in: {data}"
    assert "confidence" in data, f"Missing 'confidence' in: {data}"

def test_mock_response_primary_ai_stub_no_notepad_default_for_generic_step():
    """For a step with no app name, the stub must NOT default to 'notepad'."""
    import json
    from ai.watsonx_client import WatsonxAIClient
    from pathlib import Path
    client = WatsonxAIClient()
    prompt_path = Path("ai/prompts/primary_system_prompt.txt")
    system_prompt = prompt_path.read_text(encoding="utf-8") if prompt_path.exists() else \
        "PROPOSE the best next action"
    # A step that has no task keyword — should fall to 'converse', not 'open_application(notepad)'
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user",   "content": "summarise the current screen"},
    ]
    raw = client.chat(messages)
    data = json.loads(raw)
    assert "action_type" in data
    # Must NOT default to open_application("notepad") for a non-open step
    assert not (
        data["action_type"] == "open_application"
        and data.get("parameters", {}).get("name") == "notepad"
    ), f"Stub hardcoded 'notepad' for a non-open step: {data}"

def test_mock_response_planner_stub_returns_valid_json():
    """The Planner stub must return a dict with 'steps'."""
    import json
    from ai.watsonx_client import WatsonxAIClient
    from pathlib import Path
    client = WatsonxAIClient()
    prompt_path = Path("ai/prompts/planner_system_prompt.txt")
    system_prompt = prompt_path.read_text(encoding="utf-8") if prompt_path.exists() else \
        "DECOMPOSE a user's goal. Task Planner."
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user",   "content": "open notepad and type hello"},
    ]
    raw = client.chat(messages)
    data = json.loads(raw)
    assert "steps" in data, f"Missing 'steps' in: {data}"
    assert len(data["steps"]) > 0
