"""
tests/unit/test_observer.py

Unit tests for Observer (in-memory capture, file tracking, cleanup)
and ScreenAnalyzer.
"""

from __future__ import annotations

import types
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from observation.observer import Observer
from observation.screen_analyzer import ScreenAnalyzer, ScreenState


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_fake_image():
    """Return a minimal object that looks like a PIL Image."""
    img = MagicMock()
    img.save = MagicMock()
    return img


# ── Observer: in-memory capture ───────────────────────────────────────────────

class TestObserverInMemory:

    def test_capture_in_memory_no_file_written(self, tmp_path, monkeypatch):
        """Default capture (save_to_disk=False) must not write any file."""
        fake_image = _make_fake_image()

        # Patch ImageGrab.grab to return our fake image
        monkeypatch.setattr(
            "observation.observer.Observer._grab_screenshot",
            lambda self: fake_image,
        )
        # Patch OCR so we don't need pytesseract
        monkeypatch.setattr(
            "observation.observer.Observer._extract_text",
            lambda self, img: "some ocr text",
        )
        monkeypatch.setattr(
            "observation.observer.Observer._get_window_info",
            lambda self: ("Test Window", "TestApp"),
        )

        observer = Observer()
        state = observer.capture(label="test_label")

        # No file path recorded in state
        assert state.screenshot_path == ""
        # No files tracked for cleanup
        assert observer._written_files == []
        # Image.save must NOT have been called
        fake_image.save.assert_not_called()

    def test_capture_returns_world_state_with_text(self, monkeypatch):
        """capture() must populate visible_text from OCR."""
        monkeypatch.setattr(
            "observation.observer.Observer._grab_screenshot",
            lambda self: _make_fake_image(),
        )
        monkeypatch.setattr(
            "observation.observer.Observer._extract_text",
            lambda self, img: "hello world",
        )
        monkeypatch.setattr(
            "observation.observer.Observer._get_window_info",
            lambda self: ("", ""),
        )
        observer = Observer()
        state = observer.capture()
        assert state.visible_text == "hello world"

    def test_capture_uses_screen_analyzer_for_structured_observation(self, monkeypatch):
        """capture() should analyze the image via ScreenAnalyzer before returning world state."""
        fake_image = _make_fake_image()
        observed = {"called": False}

        def fake_analyze(self, image, window_title="", active_app=""):
            observed["called"] = True
            return types.SimpleNamespace(
                raw_text="File Explorer",
                window_title="File Explorer",
                active_app="explorer",
            )

        monkeypatch.setattr(
            "observation.observer.Observer._grab_screenshot",
            lambda self: fake_image,
        )
        monkeypatch.setattr(
            "observation.observer.Observer._extract_text",
            lambda self, img: "File Explorer",
        )
        monkeypatch.setattr(
            "observation.observer.Observer._get_window_info",
            lambda self: ("File Explorer", "explorer"),
        )
        monkeypatch.setattr(
            "observation.screen_analyzer.ScreenAnalyzer.analyze",
            fake_analyze,
        )

        observer = Observer()
        state = observer.capture(label="explorer")

        assert observed["called"] is True
        assert state.visible_text == "File Explorer"
        assert state.window_title == "File Explorer"
        assert state.active_app == "explorer"


# ── Observer: file tracking + cleanup ─────────────────────────────────────────

class TestObserverCleanup:

    def test_cleanup_removes_written_files(self, tmp_path, monkeypatch):
        """Files written with save_to_disk=True are deleted by cleanup()."""
        fake_image = _make_fake_image()

        monkeypatch.setattr(
            "observation.observer.Observer._grab_screenshot",
            lambda self: fake_image,
        )
        monkeypatch.setattr(
            "observation.observer.Observer._extract_text",
            lambda self, img: "",
        )
        monkeypatch.setattr(
            "observation.observer.Observer._get_window_info",
            lambda self: ("", ""),
        )
        # Override _SCREENSHOT_DIR to write into tmp_path
        import observation.observer as obs_mod
        monkeypatch.setattr(obs_mod, "_SCREENSHOT_DIR", tmp_path)

        # Make fake_image.save actually create a file so Path.exists() returns True
        def real_save(path_str):
            Path(path_str).write_bytes(b"PNG")
        fake_image.save.side_effect = real_save

        observer = Observer()
        state = observer.capture(label="cleanup_test", save_to_disk=True)

        assert state.screenshot_path != ""
        saved_path = Path(state.screenshot_path)
        assert saved_path.exists()
        assert len(observer._written_files) == 1

        observer.cleanup()

        assert not saved_path.exists()
        assert observer._written_files == []

    def test_cleanup_is_idempotent(self, tmp_path):
        """Calling cleanup() twice must not raise."""
        observer = Observer()
        observer.cleanup()
        observer.cleanup()

    def test_cleanup_tolerates_missing_file(self, tmp_path):
        """cleanup() must not raise if a tracked file was already deleted."""
        observer = Observer()
        missing = tmp_path / "ghost.png"
        observer._written_files.append(missing)
        observer.cleanup()  # should not raise


# ── ScreenAnalyzer ────────────────────────────────────────────────────────────

class TestScreenAnalyzer:

    def _analyzer_with_ocr(self, ocr_text: str, monkeypatch) -> ScreenAnalyzer:
        """Return a ScreenAnalyzer whose OCR always returns ocr_text."""
        analyzer = ScreenAnalyzer()
        monkeypatch.setattr(analyzer, "_ocr", lambda img: ocr_text)
        monkeypatch.setattr(analyzer, "_get_window_info", lambda: ("Win", "App"))
        return analyzer

    def test_analyze_returns_screen_state(self, monkeypatch):
        """analyze() must return a ScreenState instance."""
        analyzer = self._analyzer_with_ocr("Hello World", monkeypatch)
        result = analyzer.analyze(image=MagicMock())
        assert isinstance(result, ScreenState)

    def test_screen_state_raw_text_populated(self, monkeypatch):
        analyzer = self._analyzer_with_ocr("Some text on screen", monkeypatch)
        result = analyzer.analyze(image=MagicMock())
        assert result.raw_text == "Some text on screen"

    def test_screen_analyzer_lines_non_empty(self, monkeypatch):
        """lines must contain no blank entries."""
        ocr = "First line\n\n  \nSecond line\n\nThird line"
        analyzer = self._analyzer_with_ocr(ocr, monkeypatch)
        result = analyzer.analyze(image=MagicMock())
        assert all(ln.strip() for ln in result.lines), \
            f"Blank lines found: {result.lines}"

    def test_screen_analyzer_window_info_propagated(self, monkeypatch):
        """Window title and active_app should come from pygetwindow or args."""
        analyzer = self._analyzer_with_ocr("", monkeypatch)
        result = analyzer.analyze(image=None, window_title="My App", active_app="myapp")
        assert result.window_title == "My App"
        assert result.active_app == "myapp"

    def test_interactive_elements_found(self, monkeypatch):
        """Known button labels should appear in interactive_elements."""
        ocr = "Click OK to confirm or Cancel to abort"
        analyzer = self._analyzer_with_ocr(ocr, monkeypatch)
        result = analyzer.analyze(image=MagicMock())
        labels_lower = [e.lower() for e in result.interactive_elements]
        assert "ok" in labels_lower
        assert "cancel" in labels_lower

    def test_has_text_input_true_when_hint_present(self, monkeypatch):
        ocr = "Please enter your email address"
        analyzer = self._analyzer_with_ocr(ocr, monkeypatch)
        result = analyzer.analyze(image=MagicMock())
        assert result.has_text_input is True

    def test_has_text_input_false_when_no_hint(self, monkeypatch):
        ocr = "File has been saved successfully"
        analyzer = self._analyzer_with_ocr(ocr, monkeypatch)
        result = analyzer.analyze(image=MagicMock(), window_title="Explorer")
        assert result.has_text_input is False

    def test_has_text_input_true_for_editor_window(self, monkeypatch):
        """Editor window title → has_text_input True even without hint text."""
        ocr = "The quick brown fox"
        analyzer = self._analyzer_with_ocr(ocr, monkeypatch)
        result = analyzer.analyze(image=MagicMock(), window_title="Notepad")
        assert result.has_text_input is True

    def test_screen_analyzer_graceful_when_ocr_unavailable(self, monkeypatch):
        """Works even if pytesseract raises an ImportError."""
        analyzer = ScreenAnalyzer()
        # Force _ocr to simulate tesseract missing
        monkeypatch.setattr(analyzer, "_ocr", lambda img: "")
        monkeypatch.setattr(analyzer, "_get_window_info", lambda: ("", ""))
        result = analyzer.analyze(image=None)
        assert isinstance(result, ScreenState)
        assert result.raw_text == ""
        assert result.lines == []

    def test_analyze_none_image_returns_empty_state(self, monkeypatch):
        """analyze(image=None) must return a valid ScreenState with empty text."""
        analyzer = ScreenAnalyzer()
        monkeypatch.setattr(analyzer, "_get_window_info", lambda: ("", ""))
        result = analyzer.analyze(image=None)
        assert result.raw_text == ""
        assert result.lines == []
