"""
tests/unit/test_permission_checker.py
"""
import pytest
from ai.action_schema import Action
from config.permissions import PermissionResult
from safety.permission_checker import PermissionChecker


@pytest.fixture
def checker():
    return PermissionChecker()


def test_safe_action_allowed(checker):
    action = Action(action_type="open_application")
    assert checker.check(action) == PermissionResult.ALLOW


def test_safe_type_text_allowed(checker):
    action = Action(action_type="type_text")
    assert checker.check(action) == PermissionResult.ALLOW


def test_delete_file_requires_confirmation(checker):
    action = Action(action_type="delete_file", parameters={"path": "~/test.txt"})
    assert checker.check(action) == PermissionResult.REQUIRE_CONFIRMATION


def test_send_email_requires_confirmation(checker):
    action = Action(action_type="send_email")
    assert checker.check(action) == PermissionResult.REQUIRE_CONFIRMATION


def test_execute_script_blocked(checker):
    action = Action(action_type="execute_script")
    assert checker.check(action) == PermissionResult.BLOCK


def test_access_credentials_blocked(checker):
    action = Action(action_type="access_credentials")
    assert checker.check(action) == PermissionResult.BLOCK


def test_read_file_in_home_allowed(checker):
    import os
    home = os.path.expanduser("~")
    path = os.path.join(home, "documents", "test.txt")
    action = Action(action_type="read_file", parameters={"path": path})
    # read_file is SAFE but still has path check
    result = checker.check(action)
    assert result == PermissionResult.ALLOW


def test_is_irreversible_delete(checker):
    action = Action(action_type="delete_file")
    assert checker.is_irreversible(action) is True


def test_is_not_irreversible_open(checker):
    action = Action(action_type="open_application")
    assert checker.is_irreversible(action) is False
