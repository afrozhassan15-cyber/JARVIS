"""
tests/unit/test_planner.py
"""
import pytest
from tasks.planner import Planner
from tasks.task import TaskPlan
from ai.watsonx_client import WatsonxAIClient


@pytest.fixture
def planner():
    return Planner(WatsonxAIClient())  # mock mode


def test_plan_returns_task_plan(planner):
    plan = planner.plan("open Notepad and type Hello World")
    assert isinstance(plan, TaskPlan)


def test_plan_has_steps(planner):
    plan = planner.plan("open Notepad and type Hello World")
    assert len(plan.steps) > 0


def test_plan_preserves_goal(planner):
    goal = "open calculator and compute 2+2"
    plan = planner.plan(goal)
    assert plan.goal == goal


def test_steps_have_descriptions(planner):
    plan = planner.plan("open Notepad")
    for step in plan.steps:
        assert step.description


def test_steps_have_expected_outcomes(planner):
    plan = planner.plan("open Notepad")
    for step in plan.steps:
        assert step.expected_outcome  # must be non-empty for StepVerifier to work


def test_replan_returns_new_steps(planner):
    from tasks.task import TaskStep
    completed = [TaskStep(description="Opened browser", status="COMPLETED")]
    new_plan = planner.replan(
        "search IBM and summarise",
        completed,
        "browser closed unexpectedly",
        "Desktop is visible",
    )
    assert isinstance(new_plan, TaskPlan)
    assert len(new_plan.steps) > 0
