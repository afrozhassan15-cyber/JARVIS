"""
tests/unit/test_policy_engine.py

Tests all branches of the Verification Policy Engine decision table.
No API calls — uses fixed ActionProposal and VerifierResult objects.
"""
import pytest
from ai.action_schema import Action, ActionProposal, PolicyDecision, Verdict, VerifierResult
from ai.policy_engine import VerificationPolicyEngine


@pytest.fixture
def engine():
    return VerificationPolicyEngine()


def _proposal(conf: float, action_type: str = "open_application",
              irreversible: bool = False, reconsidered: int = 0) -> ActionProposal:
    return ActionProposal(
        action=Action(action_type=action_type, is_irreversible=irreversible),
        reasoning="test",
        confidence=conf,
        reconsider_count=reconsidered,
    )


def _verifier(verdict: Verdict, conf: float, risks: list = None) -> VerifierResult:
    return VerifierResult(verdict=verdict, confidence=conf, risks=risks or [])


# ── EXECUTE cases ─────────────────────────────────────────────────────────────

def test_execute_high_confidence_approve(engine):
    p = _proposal(0.85)
    v = _verifier(Verdict.APPROVE, 0.80)
    assert engine.decide(p, v) == PolicyDecision.EXECUTE


def test_execute_medium_confidence_approve(engine):
    p = _proposal(0.72)
    v = _verifier(Verdict.APPROVE, 0.71)
    assert engine.decide(p, v) == PolicyDecision.EXECUTE


# ── BLOCK cases ───────────────────────────────────────────────────────────────

def test_block_unsafe_risk(engine):
    p = _proposal(0.90)
    v = _verifier(Verdict.REJECT, 0.85, risks=["unsafe_action"])
    assert engine.decide(p, v) == PolicyDecision.BLOCK


# ── ASK_USER cases ────────────────────────────────────────────────────────────

def test_ask_user_low_pai_confidence(engine):
    p = _proposal(0.35)
    v = _verifier(Verdict.APPROVE, 0.90)
    assert engine.decide(p, v) == PolicyDecision.ASK_USER


def test_ask_user_irreversible_action(engine):
    p = _proposal(0.90, irreversible=True)
    v = _verifier(Verdict.APPROVE, 0.85)
    assert engine.decide(p, v) == PolicyDecision.ASK_USER


# ── RECONSIDER cases ──────────────────────────────────────────────────────────

def test_reconsider_verifier_rejects_medium_pai(engine):
    p = _proposal(0.72)
    v = _verifier(Verdict.REJECT, 0.35)
    assert engine.decide(p, v) == PolicyDecision.RECONSIDER


def test_reconsider_both_medium_disagree_first_time(engine):
    p = _proposal(0.75, reconsidered=0)
    v = _verifier(Verdict.REJECT, 0.75)
    assert engine.decide(p, v) == PolicyDecision.RECONSIDER


def test_ask_user_both_medium_disagree_after_one_reconsider(engine):
    p = _proposal(0.75, reconsidered=1)
    v = _verifier(Verdict.REJECT, 0.75)
    assert engine.decide(p, v) == PolicyDecision.ASK_USER


# ── ESCALATE case ─────────────────────────────────────────────────────────────

def test_escalate_max_reconsider_cycles(engine):
    p = _proposal(0.80, reconsidered=3)
    v = _verifier(Verdict.REJECT, 0.55)
    assert engine.decide(p, v) == PolicyDecision.ESCALATE
