"""
tests/unit/test_primary_ai.py

Tests PrimaryAI using the mock WatsonxAIClient (no real API calls).
"""
import pytest
from ai.primary_ai import PrimaryAI
from ai.watsonx_client import WatsonxAIClient
from ai.action_schema import ActionProposal
from tasks.task import TaskStep


@pytest.fixture
def mock_client():
    return WatsonxAIClient()  # no credentials → mock mode


@pytest.fixture
def ai(mock_client):
    return PrimaryAI(mock_client)


def _step(description="Open Notepad", action_type="open_application",
          expected="Notepad is visible"):
    return TaskStep(description=description, action_type=action_type,
                    expected_outcome=expected)


def test_propose_action_returns_proposal(ai):
    step = _step()
    proposal = ai.propose_action(step)
    assert isinstance(proposal, ActionProposal)


def test_proposal_has_action(ai):
    proposal = ai.propose_action(_step())
    assert proposal.action is not None
    assert proposal.action.action_type != ""


def test_proposal_confidence_in_range(ai):
    proposal = ai.propose_action(_step())
    assert 0.0 <= proposal.confidence <= 1.0


def test_propose_type_text_step(ai):
    step = _step("Type Hello World", "type_text", "Text appears")
    proposal = ai.propose_action(step, world_state_text="Notepad is open")
    assert isinstance(proposal, ActionProposal)


def test_revise_action_increments_reconsider_count(ai):
    step = _step()
    from ai.action_schema import Action
    original = ActionProposal(
        action=Action(action_type="open_application"),
        reasoning="test",
        confidence=0.8,
        reconsider_count=0,
    )
    revised = ai.revise_action(step, original, "wrong_target")
    assert revised.reconsider_count == 1


def test_revise_action_returns_proposal(ai):
    step = _step()
    from ai.action_schema import Action
    original = ActionProposal(
        action=Action(action_type="open_application"),
        reasoning="test",
        confidence=0.5,
        reconsider_count=0,
    )
    revised = ai.revise_action(step, original, "try something else")
    assert isinstance(revised, ActionProposal)


def test_mock_primary_ai_does_not_hardcode_hello_world_text():
    client = WatsonxAIClient()
    system_prompt = "You are the Primary AI. PROPOSE the best next action."
    user_message = "Task step: Type into the active app"
    response = client.chat([
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_message},
    ])
    payload = response.lower()
    assert "hello world" not in payload


def test_search_like_question_uses_search_tool():
    from unittest.mock import MagicMock, patch
    from core.orchestrator import Orchestrator
    from config.config import AppConfig
    from core.event_bus import EventBus
    from core.context_manager import ContextManager

    cfg = AppConfig()
    bus = EventBus()
    ctx = ContextManager()

    with patch("core.orchestrator.WatsonxAIClient"), \
         patch("core.orchestrator.PrimaryAI"), \
         patch("core.orchestrator.VerifierAI"), \
         patch("core.orchestrator.VerificationPolicyEngine"), \
         patch("core.orchestrator.LanguageParser"), \
         patch("core.orchestrator.Planner"), \
         patch("core.orchestrator.TaskManager"), \
         patch("core.orchestrator.Observer"), \
         patch("core.orchestrator.StepVerifier"), \
         patch("core.orchestrator.ErrorHandler"), \
         patch("core.orchestrator.PermissionChecker"), \
         patch("core.orchestrator.ResponseGenerator") as response_mock, \
         patch("core.orchestrator.TextToSpeech"), \
         patch("core.orchestrator.ToolRegistry") as registry_mock:
        orch = Orchestrator(cfg, bus, ctx)
        orch._say = MagicMock()
        orch._registry = MagicMock()
        orch._registry.execute.return_value = type("R", (), {"success": True, "output": "Paris is the capital of France."})()
        response_mock.return_value.synthesize_search_result.return_value = "Paris is the capital of France."

        orch._handle_conversation("what is the capital of France?")

        orch._registry.execute.assert_called_once()
        orch._say.assert_called_once_with("Paris is the capital of France.")
