"""
tests/unit/test_response_generator.py

Tests for ResponseGenerator — including the new synthesize_search_result method.
Uses mock WatsonxAIClient — no real API calls.
"""
from __future__ import annotations

import pytest
from unittest.mock import MagicMock

from response.response_generator import ResponseGenerator
from response.personality import MessageType


@pytest.fixture
def generator_no_client():
    return ResponseGenerator(client=None)


@pytest.fixture
def generator_mock_client():
    from ai.watsonx_client import WatsonxAIClient
    return ResponseGenerator(client=WatsonxAIClient())  # mock mode


# ── converse ──────────────────────────────────────────────────────────────────

def test_converse_without_client_returns_fallback(generator_no_client):
    result = generator_no_client.converse("hello")
    assert isinstance(result, str)
    assert len(result) > 0


def test_converse_with_mock_client_returns_string(generator_mock_client):
    result = generator_mock_client.converse("hello")
    assert isinstance(result, str)
    assert len(result) > 0


def test_converse_with_question(generator_mock_client):
    result = generator_mock_client.converse("what is machine learning?")
    assert isinstance(result, str)
    # Must not be empty or a raw JSON blob
    assert "{" not in result or "action_type" not in result


def test_converse_does_not_return_action_json(generator_mock_client):
    """Conversational replies must never expose action_type JSON."""
    for input_text in ["hello", "who are you?", "good morning"]:
        result = generator_mock_client.converse(input_text)
        assert "action_type" not in result, \
            f"Got action JSON for conversational input '{input_text}': {result}"


# ── synthesize_search_result ──────────────────────────────────────────────────

def test_synthesize_without_client_returns_raw_results(generator_no_client):
    raw = "• IBM: IBM is a technology company\n• Wikipedia: International Business Machines"
    result = generator_no_client.synthesize_search_result("what is IBM?", raw)
    assert "IBM" in result
    assert isinstance(result, str)


def test_synthesize_with_mock_client_returns_string(generator_mock_client):
    raw = "• Result 1: Some info\n• Result 2: More info"
    result = generator_mock_client.synthesize_search_result("test query", raw)
    assert isinstance(result, str)
    assert len(result) > 0


def test_synthesize_does_not_return_raw_json(generator_mock_client):
    raw = "• Machine learning: A subset of AI\n• Deep learning: Uses neural networks"
    result = generator_mock_client.synthesize_search_result("what is machine learning?", raw)
    # Result must be a natural language string, not JSON
    assert "action_type" not in result


def test_synthesize_truncates_very_long_raw_results(generator_no_client):
    """Very long raw results must be truncated to avoid context overflow."""
    raw = "• Result: " + "x" * 5000
    result = generator_no_client.synthesize_search_result("test", raw)
    assert len(result) < 2000  # well under raw length


# ── template methods ──────────────────────────────────────────────────────────

def test_task_started_returns_string(generator_no_client):
    result = generator_no_client.task_started()
    assert isinstance(result, str) and result


def test_task_complete_returns_string(generator_no_client):
    result = generator_no_client.task_complete("All done")
    assert isinstance(result, str) and result


def test_task_failed_returns_string(generator_no_client):
    result = generator_no_client.task_failed("Something went wrong")
    assert isinstance(result, str) and result


def test_confirm_action_includes_action_text(generator_no_client):
    result = generator_no_client.confirm_action("open Notepad")
    assert isinstance(result, str) and result


def test_status_update_includes_step(generator_no_client):
    result = generator_no_client.status_update("Opening Notepad")
    assert isinstance(result, str) and result
