"""
tests/unit/test_speech_input.py

Verifies that speech-to-text results go through the same pipeline as typed
input and that handle_input is called exactly once per transcript.
"""

from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch, call

import pytest

from voice.speech_to_text import SpeechToText, TranscriptResult


class TestSpeechPipeline:
    """
    Speech results must be delivered to orchestrator.handle_input() exactly
    once — going through the exact same path as typed text input.
    """

    def test_speech_result_goes_through_same_pipeline_as_text(self):
        """
        SpeechToText delivers its transcript via the on_transcript callback.
        The callback used in main.py is orchestrator.handle_input.
        Verify the callback is invoked once with the correct text.
        """
        handle_input = MagicMock()
        stt = SpeechToText(on_transcript=lambda r: handle_input(r.text))

        # Simulate a transcript being delivered
        result = TranscriptResult(text="open notepad", confidence=0.95)
        stt._on_transcript(result)

        handle_input.assert_called_once_with("open notepad")

    def test_no_duplicate_processing_on_two_inputs(self):
        """
        Two separate transcripts produce exactly two handle_input calls —
        not four (i.e. no doubling up in the pipeline).
        """
        handle_input = MagicMock()
        stt = SpeechToText(on_transcript=lambda r: handle_input(r.text))

        stt._on_transcript(TranscriptResult(text="open notepad"))
        stt._on_transcript(TranscriptResult(text="close notepad"))

        assert handle_input.call_count == 2
        assert handle_input.call_args_list == [
            call("open notepad"),
            call("close notepad"),
        ]

    def test_callback_set_after_construction(self):
        """set_callback() must replace the on_transcript handler."""
        first_cb = MagicMock()
        second_cb = MagicMock()

        stt = SpeechToText(on_transcript=first_cb)
        stt.set_callback(second_cb)

        result = TranscriptResult(text="hello")
        stt._on_transcript(result)

        first_cb.assert_not_called()
        second_cb.assert_called_once_with(result)

    def test_listen_and_deliver_calls_callback(self):
        """
        _listen_and_deliver() calls the callback if listen_once() returns a result.
        """
        stt = SpeechToText()
        callback = MagicMock()
        stt.set_callback(callback)

        transcript = TranscriptResult(text="type hello world", confidence=0.9)
        with patch.object(stt, "listen_once", return_value=transcript):
            stt._listen_and_deliver()

        callback.assert_called_once_with(transcript)

    def test_listen_and_deliver_no_callback_when_none_result(self):
        """
        _listen_and_deliver() must not call callback if listen_once() returns None.
        """
        stt = SpeechToText()
        callback = MagicMock()
        stt.set_callback(callback)

        with patch.object(stt, "listen_once", return_value=None):
            stt._listen_and_deliver()

        callback.assert_not_called()

    def test_disabled_mode_listen_once_returns_none(self):
        """When mode is 'disabled', listen_once() returns None without raising."""
        stt = SpeechToText()
        stt._mode = "disabled"
        result = stt.listen_once()
        assert result is None

    def test_speech_recognition_compatibility_alias_is_registered(self):
        """Python 3.13+ should alias aifc to standard_aifc before speech_recognition import."""
        import voice.speech_to_text as mod

        with patch.object(mod, "_ensure_speech_recognition_compat") as ensure:
            mod._ensure_speech_recognition_compat()
            ensure.assert_called_once()
