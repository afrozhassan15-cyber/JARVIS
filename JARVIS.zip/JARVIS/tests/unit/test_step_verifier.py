"""
tests/unit/test_step_verifier.py
"""
import pytest
from observation.step_verifier import StepVerifier
from ai.watsonx_client import WatsonxAIClient
from core.context_manager import WorldState
from tasks.task import TaskStep


@pytest.fixture
def verifier():
    return StepVerifier(WatsonxAIClient())  # mock mode → rule-based


def _world(visible_text="", window_title=""):
    return WorldState(visible_text=visible_text, window_title=window_title)


def _step(desc="Open Notepad", expected="Notepad is visible"):
    return TaskStep(description=desc, expected_outcome=expected)


def test_verify_returns_result(verifier):
    from ai.action_schema import VerificationResult
    result = verifier.verify(_step(), _world("Notepad - Untitled", "Notepad"))
    assert isinstance(result, VerificationResult)


def test_verify_pass_when_expected_text_present(verifier):
    result = verifier.verify(
        _step("Open Notepad", "Notepad is visible and open"),
        _world("Untitled - Notepad", "Untitled - Notepad")
    )
    assert result.passed is True


def test_verify_fail_when_expected_text_absent(verifier):
    result = verifier.verify(
        _step("Open Notepad", "Notepad application is open and ready"),
        _world("This is a totally unrelated screen", "Desktop")
    )
    assert result.passed is False


def test_verify_no_expected_outcome_defaults_pass(verifier):
    step = TaskStep(description="do something", expected_outcome="")
    result = verifier.verify(step, _world())
    assert result.passed is True


def test_verify_confidence_in_range(verifier):
    result = verifier.verify(_step(), _world("Notepad"))
    assert 0.0 <= result.confidence <= 1.0
