"""
tests/unit/test_task_manager.py
"""
import pytest
from tasks.task import TaskPriority, TaskStatus
from tasks.task_manager import TaskManager


@pytest.fixture
def mgr():
    return TaskManager()


def test_create_task(mgr):
    task = mgr.create_task("open notepad")
    assert task.goal == "open notepad"
    assert task.status == TaskStatus.PENDING


def test_activate_task(mgr):
    task = mgr.create_task("test")
    ok = mgr.activate_task(task.id)
    assert ok
    assert mgr.get_active_task().id == task.id
    assert task.status == TaskStatus.ACTIVE


def test_pause_and_resume(mgr):
    task = mgr.create_task("test")
    mgr.activate_task(task.id)
    mgr.pause_task(task.id)
    assert task.status == TaskStatus.PAUSED
    assert mgr.get_active_task() is None

    mgr.resume_task(task.id)
    assert task.status == TaskStatus.ACTIVE
    assert mgr.get_active_task().id == task.id


def test_complete_task(mgr):
    task = mgr.create_task("test")
    mgr.activate_task(task.id)
    mgr.complete_task(task.id)
    assert task.status == TaskStatus.COMPLETED
    assert mgr.get_active_task() is None


def test_cancel_task(mgr):
    task = mgr.create_task("test")
    mgr.activate_task(task.id)
    mgr.cancel_task(task.id)
    assert task.status == TaskStatus.CANCELLED


def test_fail_task(mgr):
    task = mgr.create_task("test")
    mgr.activate_task(task.id)
    mgr.fail_task(task.id, "some error")
    assert task.status == TaskStatus.FAILED
    assert task.error_summary == "some error"


def test_cancel_all(mgr):
    t1 = mgr.create_task("task1")
    t2 = mgr.create_task("task2")
    mgr.activate_task(t1.id)
    mgr.cancel_all()
    assert t1.status == TaskStatus.CANCELLED
    assert t2.status == TaskStatus.CANCELLED
    assert mgr.get_active_task() is None


def test_priority_ordering(mgr):
    t_normal = mgr.create_task("normal", TaskPriority.NORMAL)
    t_high   = mgr.create_task("high",   TaskPriority.HIGH)
    t_bg     = mgr.create_task("bg",     TaskPriority.BACKGROUND)

    # Activate next should pick highest priority first
    first = mgr.activate_next()
    assert first.priority == TaskPriority.HIGH


def test_is_terminal_states():
    from tasks.task import Task
    for status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED):
        t = Task(goal="x", status=status)
        assert t.is_terminal
    for status in (TaskStatus.PENDING, TaskStatus.ACTIVE, TaskStatus.PAUSED):
        t = Task(goal="x", status=status)
        assert not t.is_terminal
