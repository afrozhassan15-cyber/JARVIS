"""
tests/unit/test_tool_registry.py
"""
import pytest
from ai.action_schema import Action, ActionResult
from tools.base_tool import BaseTool
from tools.tool_registry import ToolRegistry


class MockTool(BaseTool):
    def __init__(self, handled: set):
        self._handled = handled
        self._executed = []

    @property
    def name(self): return "mock_tool"
    @property
    def description(self): return "A mock tool"

    def can_handle(self, action: Action) -> bool:
        return action.action_type in self._handled

    def execute(self, action: Action) -> ActionResult:
        self._executed.append(action)
        return ActionResult(success=True, output="mock_output")

    def get_schema(self) -> dict:
        return {"tool": "mock_tool", "action_types": list(self._handled)}


@pytest.fixture
def registry():
    r = ToolRegistry()
    r.register(MockTool({"open_application", "type_text"}))
    return r


def test_find_tool_found(registry):
    action = Action(action_type="open_application")
    tool = registry.find_tool(action)
    assert tool is not None
    assert tool.name == "mock_tool"


def test_find_tool_not_found(registry):
    action = Action(action_type="nonexistent_action")
    tool = registry.find_tool(action)
    assert tool is None


def test_execute_success(registry):
    action = Action(action_type="type_text", parameters={"text": "hello"})
    result = registry.execute(action)
    assert result.success is True
    assert result.output == "mock_output"


def test_execute_no_tool(registry):
    action = Action(action_type="unknown_action_xyz")
    result = registry.execute(action)
    assert result.success is False
    assert "No tool available" in result.error_message


def test_get_all_schemas(registry):
    schemas = registry.get_all_schemas()
    assert len(schemas) == 1
    assert schemas[0]["tool"] == "mock_tool"


def test_list_tools(registry):
    assert "mock_tool" in registry.list_tools()


def test_tool_raises_exception_returns_failure(registry):
    class BrokenTool(BaseTool):
        @property
        def name(self): return "broken"
        @property
        def description(self): return "breaks"
        def can_handle(self, a): return a.action_type == "break"
        def execute(self, a): raise RuntimeError("boom")
        def get_schema(self): return {}

    registry.register(BrokenTool())
    result = registry.execute(Action(action_type="break"))
    assert result.success is False
    assert "boom" in result.error_message
