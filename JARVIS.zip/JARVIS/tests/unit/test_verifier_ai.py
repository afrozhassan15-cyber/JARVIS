"""
tests/unit/test_verifier_ai.py

Tests VerifierAI using mock WatsonxAIClient.
"""
import pytest
from ai.verifier_ai import VerifierAI
from ai.watsonx_client import WatsonxAIClient
from ai.action_schema import Action, ActionProposal, Verdict, VerifierResult
from tasks.task import TaskStep


@pytest.fixture
def mock_client():
    return WatsonxAIClient()


@pytest.fixture
def verifier(mock_client):
    return VerifierAI(mock_client)


def _proposal(action_type="open_application", conf=0.85):
    return ActionProposal(
        action=Action(action_type=action_type),
        reasoning="test",
        confidence=conf,
    )


def _step(desc="Open Notepad", expected="Notepad is visible"):
    return TaskStep(description=desc, expected_outcome=expected)


def test_evaluate_returns_verifier_result(verifier):
    result = verifier.evaluate(_proposal(), _step())
    assert isinstance(result, VerifierResult)


def test_verifier_confidence_in_range(verifier):
    result = verifier.evaluate(_proposal(), _step())
    assert 0.0 <= result.confidence <= 1.0


def test_verifier_verdict_is_valid(verifier):
    result = verifier.evaluate(_proposal(), _step())
    assert result.verdict in (Verdict.APPROVE, Verdict.REJECT)


def test_verifier_does_not_see_reasoning(verifier):
    """
    Verifier AI should only receive the action — not the reasoning.
    We verify this by checking that the system prompt instructs the verifier
    it has NOT seen the reasoning (covered by the prompt file test).
    """
    proposal = _proposal()
    assert proposal.reasoning  # Primary AI has reasoning
    result = verifier.evaluate(proposal, _step())
    # The result is based on the action alone, not reasoning
    assert result.verdict in (Verdict.APPROVE, Verdict.REJECT)


def test_verifier_provides_risks_list(verifier):
    result = verifier.evaluate(_proposal(), _step())
    assert isinstance(result.risks, list)
