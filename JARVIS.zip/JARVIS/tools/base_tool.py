"""
tools/base_tool.py

Abstract base class that every JARVIS tool must implement.
This is the tool interface contract — the only surface the Tool Registry and
Action Executor know about.  New tools are added by subclassing BaseTool.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from ai.action_schema import Action, ActionResult


class BaseTool(ABC):
    """
    Abstract interface for all JARVIS tools.

    To add a new tool:
    1. Create a class that extends BaseTool
    2. Implement can_handle(), execute(), and get_schema()
    3. Register it with ToolRegistry.register()

    The AI layer will automatically discover the tool through get_schema().
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this tool (e.g. 'computer_control')."""

    @property
    @abstractmethod
    def description(self) -> str:
        """Human/LLM-readable description of what this tool does."""

    @abstractmethod
    def can_handle(self, action: Action) -> bool:
        """
        Return True if this tool can handle the given action.
        The ToolRegistry calls this to route actions.
        """

    @abstractmethod
    def execute(self, action: Action) -> ActionResult:
        """
        Execute the action and return an ActionResult.

        Implementations must:
        - Never raise unhandled exceptions (catch and return ActionResult(success=False))
        - Log what they are doing at DEBUG/INFO level
        - Never call the AI layer directly
        """

    @abstractmethod
    def get_schema(self) -> dict:
        """
        Return a dict describing the action types this tool supports and their parameters.
        This schema is injected into the Primary AI's prompt so it knows what actions exist.
        """
