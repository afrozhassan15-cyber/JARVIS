"""
tools/computer_control/computer_tool.py

Computer control tool — keyboard and application control.
Uses pyautogui + pygetwindow + keyboard for cross-platform support.

NOTE: Mouse clicking is intentionally NOT implemented (keyboard-first phase).
      click() is accepted but treated as a focus action only.

IMPORTANT: This tool executes real system actions.
It is only called after the Verification Policy Engine approves the action
AND the PermissionChecker allows it.
"""

from __future__ import annotations

import logging
import subprocess
import time
from typing import Optional

from ai.action_schema import Action, ActionResult
from tools.base_tool import BaseTool

try:
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.05
except Exception:
    pass

logger = logging.getLogger(__name__)

_HANDLED_ACTIONS = frozenset({
    "open_application",
    "type_text",
    "press_key",
    "click",
    "scroll",
    "close_application",
    "switch_application",
    "take_screenshot",
    "read_screen",
    "focus_application",
    "converse",          # PrimaryAI may propose converse; handled here gracefully
})

# Windows application name → executable mapping
_APP_EXECUTABLES: dict[str, str] = {
    "notepad":     "notepad.exe",
    "calculator":  "calc.exe",
    "paint":       "mspaint.exe",
    "explorer":    "explorer.exe",
    "chrome":      "chrome.exe",
    "firefox":     "firefox.exe",
    "edge":        "msedge.exe",
    "word":        "winword.exe",
    "excel":       "excel.exe",
    "cmd":         "cmd.exe",
    "powershell":  "powershell.exe",
    "vscodium":    "codium.exe",
    "code":        "code.exe",
}


class ComputerControlTool(BaseTool):
    """
    Handles keyboard, mouse, and application actions.
    Uses pyautogui for input simulation, subprocess for app launching.
    """

    @property
    def name(self) -> str:
        return "computer_control"

    @property
    def description(self) -> str:
        return (
            "Controls the computer: open/close applications, type text, "
            "press keys, click elements, and scroll."
        )

    def can_handle(self, action: Action) -> bool:
        return action.action_type in _HANDLED_ACTIONS

    def execute(self, action: Action) -> ActionResult:
        handler = {
            "open_application":   self._open_application,
            "type_text":          self._type_text,
            "press_key":          self._press_key,
            "click":              self._click,
            "scroll":             self._scroll,
            "close_application":  self._close_application,
            "switch_application": self._switch_application,
            "focus_application":  self._focus_application,
            "take_screenshot":    self._take_screenshot,
            "read_screen":        self._read_screen,
            "converse":           self._converse,
        }.get(action.action_type)

        if handler is None:
            return ActionResult(
                success=False,
                error_message=f"Unknown action: {action.action_type}",
            )
        return handler(action.parameters)

    # ── Action implementations ────────────────────────────────────────────────

    def _open_application(self, params: dict) -> ActionResult:
        name = params.get("name", "").lower().strip()
        if not name:
            return ActionResult(success=False, error_message="No application name provided")

        executable = _APP_EXECUTABLES.get(name, name)
        logger.info("Opening application: %s (%s)", name, executable)
        try:
            subprocess.Popen(executable, shell=True)  # noqa: S602
            # Give the OS time to launch and render the window
            time.sleep(2.0)
            # Try to bring the window to the foreground
            self._try_focus_window(name)
            return ActionResult(success=True, output=f"Opened {name}")
        except Exception as exc:
            return ActionResult(
                success=False,
                error_message=f"Failed to open {name}: {exc}",
            )

    def _type_text(self, params: dict) -> ActionResult:
        """
        Type text into the currently focused window.

        Uses the `keyboard` library which supports full Unicode and does not
        depend on X11/Display (unlike pyautogui.typewrite on some systems).
        Falls back to pyautogui.write() if keyboard is unavailable.
        """
        text = params.get("text", "")
        if not text:
            return ActionResult(success=False, error_message="No text provided")
        # Small settle pause so the window is ready to accept input
        time.sleep(0.3)
        try:
            import keyboard as kb
            kb.write(text, delay=0.04)
            logger.info("Typed text (keyboard): %s", text[:50])
            return ActionResult(success=True, output=f"Typed: {text}")
        except Exception:
            pass
        # Fallback: pyautogui.write() handles Unicode better than typewrite()
        try:
            import pyautogui
            pyautogui.write(text, interval=0.04)
            logger.info("Typed text (pyautogui): %s", text[:50])
            return ActionResult(success=True, output=f"Typed: {text}")
        except Exception as exc:
            return ActionResult(success=False, error_message=str(exc))

    def _press_key(self, params: dict) -> ActionResult:
        key = params.get("key", "")
        modifiers = params.get("modifiers", [])
        if not key:
            return ActionResult(success=False, error_message="No key provided")
        try:
            import pyautogui
            if modifiers:
                pyautogui.hotkey(*modifiers, key)
            else:
                pyautogui.press(key)
            logger.info("Pressed key: %s %s", modifiers, key)
            return ActionResult(success=True, output=f"Pressed: {key}")
        except Exception as exc:
            return ActionResult(success=False, error_message=str(exc))

    def _click(self, params: dict) -> ActionResult:
        """
        Mouse clicking is intentionally deferred (keyboard-first phase).
        If coordinates are given we move the cursor only — no click.
        Without coordinates we just ensure focus via Tab/Enter keyboard navigation.
        """
        target = params.get("target", "")
        logger.info("Click requested for '%s' — using keyboard focus instead", target)
        # Use Tab to cycle focus to the target element (best-effort)
        try:
            import pyautogui
            pyautogui.press("tab")
            return ActionResult(success=True, output=f"Focus cycled (keyboard) for: {target}")
        except Exception as exc:
            return ActionResult(success=False, error_message=str(exc))

    def _scroll(self, params: dict) -> ActionResult:
        direction = params.get("direction", "down")
        amount = int(params.get("amount", 3))
        clicks = -amount if direction == "down" else amount
        try:
            import pyautogui
            pyautogui.scroll(clicks)
            return ActionResult(success=True, output=f"Scrolled {direction} {amount}")
        except Exception as exc:
            return ActionResult(success=False, error_message=str(exc))

    def _close_application(self, params: dict) -> ActionResult:
        name = params.get("name", "")
        try:
            import pygetwindow as gw
            windows = gw.getWindowsWithTitle(name)
            if windows:
                windows[0].close()
                return ActionResult(success=True, output=f"Closed {name}")
            return ActionResult(success=False, error_message=f"No window found: {name}")
        except Exception as exc:
            return ActionResult(success=False, error_message=str(exc))

    def _switch_application(self, params: dict) -> ActionResult:
        name = params.get("name", "")
        return self._try_focus_window(name)

    def _focus_application(self, params: dict) -> ActionResult:
        name = params.get("name", "")
        return self._try_focus_window(name)

    def _converse(self, params: dict) -> ActionResult:
        """
        Handle a converse action from PrimaryAI.
        The message is returned as output so the orchestrator can present it.
        """
        message = params.get("message", "")
        logger.info("Converse action: %s", message[:80])
        return ActionResult(success=True, output=message)

    def _take_screenshot(self, params: dict) -> ActionResult:
        try:
            import pyautogui
            from pathlib import Path
            path = Path("logs") / "last_screenshot.png"
            path.parent.mkdir(exist_ok=True)
            screenshot = pyautogui.screenshot()
            screenshot.save(str(path))
            logger.info("Screenshot saved: %s", path)
            return ActionResult(success=True, output=str(path))
        except Exception as exc:
            return ActionResult(success=False, error_message=str(exc))

    def _read_screen(self, params: dict) -> ActionResult:
        """Capture screen and extract text via OCR."""
        try:
            import pytesseract
            import pyautogui
            screenshot = pyautogui.screenshot()
            text = pytesseract.image_to_string(screenshot)
            logger.info("Screen OCR captured %d chars", len(text))
            return ActionResult(success=True, output=text)
        except Exception as exc:
            # OCR not available — return empty but success so pipeline continues
            logger.warning("Screen OCR failed: %s", exc)
            return ActionResult(success=True, output="(screen text unavailable)")

    # ── Shared helpers ────────────────────────────────────────────────────────

    def _try_focus_window(self, name: str) -> ActionResult:
        """
        Attempt to bring a named window to the foreground.
        Searches for a window whose title contains `name` (case-insensitive).
        Returns success even if no window is found — not fatal.
        """
        if not name:
            return ActionResult(success=True, output="No window name given; skipping focus")
        try:
            import pygetwindow as gw
            # Search by partial title match (case-insensitive)
            name_lower = name.lower()
            matches = [w for w in gw.getAllWindows()
                       if name_lower in (w.title or "").lower()]
            if matches:
                win = matches[0]
                win.activate()
                time.sleep(0.4)
                logger.info("Focused window: '%s'", win.title)
                return ActionResult(success=True, output=f"Focused: {win.title}")
        except Exception as exc:
            logger.warning("Window focus failed: %s", exc)
        return ActionResult(success=True, output=f"(focus skipped for '{name}')")

    def get_schema(self) -> dict:
        return {
            "tool": self.name,
            "description": self.description,
            "action_types": list(_HANDLED_ACTIONS),
        }
