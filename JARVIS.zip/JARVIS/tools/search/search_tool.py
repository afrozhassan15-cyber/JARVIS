"""
tools/search/search_tool.py

Web search tool — uses DuckDuckGo (no API key required).
"""

from __future__ import annotations

import logging

from ai.action_schema import Action, ActionResult
from tools.base_tool import BaseTool

logger = logging.getLogger(__name__)

_HANDLED_ACTIONS = frozenset({"search_web"})


class WebSearchTool(BaseTool):

    @property
    def name(self) -> str:
        return "web_search"

    @property
    def description(self) -> str:
        return "Searches the internet using DuckDuckGo and returns result summaries."

    def can_handle(self, action: Action) -> bool:
        return action.action_type in _HANDLED_ACTIONS

    def execute(self, action: Action) -> ActionResult:
        query = action.parameters.get("query", "").strip()
        if not query:
            return ActionResult(success=False, error_message="No search query provided")

        max_results = int(action.parameters.get("max_results", 5))
        logger.info("Web search: %s", query)
        try:
            from duckduckgo_search import DDGS
            results = []
            with DDGS() as ddgs:
                for r in ddgs.text(query, max_results=max_results):
                    results.append(
                        f"• {r.get('title', '')}: {r.get('body', '')[:200]}"
                    )
            if not results:
                return ActionResult(
                    success=True,
                    output="No results found for that query.",
                )
            summary = "\n".join(results)
            logger.info("Search returned %d results", len(results))
            return ActionResult(success=True, output=summary)
        except ImportError:
            return ActionResult(
                success=False,
                error_message="duckduckgo-search not installed. Run: pip install duckduckgo-search",
            )
        except Exception as exc:
            logger.error("Web search failed: %s", exc)
            return ActionResult(success=False, error_message=str(exc))

    def get_schema(self) -> dict:
        return {
            "tool": self.name,
            "description": self.description,
            "action_types": list(_HANDLED_ACTIONS),
            "parameters": {
                "search_web": {
                    "query": "string — the search query",
                    "max_results": "int — number of results (default 5)",
                }
            },
        }
