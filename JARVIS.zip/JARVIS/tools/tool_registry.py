"""
tools/tool_registry.py

Central registry for all JARVIS tools.
The Action Executor and Primary AI interact with tools exclusively through this registry.
"""

from __future__ import annotations

import logging
from typing import Optional

from ai.action_schema import Action, ActionResult
from tools.base_tool import BaseTool

logger = logging.getLogger(__name__)


class ToolRegistry:
    """
    Register, discover, and route to tools.

    Usage:
        registry = ToolRegistry()
        registry.register(ComputerControlTool())
        registry.register(WebSearchTool())

        tool = registry.find_tool(action)
        result = tool.execute(action)
    """

    def __init__(self) -> None:
        self._tools: dict[str, BaseTool] = {}

    def register(self, tool: BaseTool) -> None:
        """Register a tool. Later registrations with the same name overwrite earlier ones."""
        self._tools[tool.name] = tool
        logger.info("Tool registered: %s", tool.name)

    def find_tool(self, action: Action) -> Optional[BaseTool]:
        """Return the first tool that can handle this action, or None."""
        for tool in self._tools.values():
            if tool.can_handle(action):
                return tool
        logger.warning("No tool found for action_type: %s", action.action_type)
        return None

    def execute(self, action: Action) -> ActionResult:
        """
        Find and execute the action through the appropriate tool.
        Returns a failure ActionResult if no tool is found.
        """
        tool = self.find_tool(action)
        if tool is None:
            return ActionResult(
                success=False,
                error_message=f"No tool available for action type '{action.action_type}'",
                action_type=action.action_type,
            )
        try:
            result = tool.execute(action)
            result.action_type = action.action_type
            return result
        except Exception as exc:
            logger.error("Tool %s raised exception: %s", tool.name, exc, exc_info=True)
            return ActionResult(
                success=False,
                error_message=str(exc),
                action_type=action.action_type,
            )

    def get_all_schemas(self) -> list[dict]:
        """Return schemas for all registered tools (injected into AI prompts)."""
        return [t.get_schema() for t in self._tools.values()]

    def list_tools(self) -> list[str]:
        return list(self._tools.keys())
