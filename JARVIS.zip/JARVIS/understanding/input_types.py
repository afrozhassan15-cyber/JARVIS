"""
understanding/input_types.py

Enums and dataclasses for classifying user input.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class InputType(str, Enum):
    """Classification of what kind of input the user gave."""
    CONVERSATION    = "CONVERSATION"    # casual chat
    QUESTION        = "QUESTION"        # knowledge/information request
    COMPUTER_TASK   = "COMPUTER_TASK"   # single computer action
    MULTI_STEP_TASK = "MULTI_STEP_TASK" # multiple steps required
    INTERRUPTION    = "INTERRUPTION"    # stop/pause/switch current task
    CANCEL          = "CANCEL"          # cancel current task
    CLARIFICATION   = "CLARIFICATION"   # user is responding to JARVIS's question
    CONFIRMATION    = "CONFIRMATION"    # user answering yes/no to a confirmation request
    RESUME          = "RESUME"          # resume a paused task
    UNKNOWN         = "UNKNOWN"         # could not classify


@dataclass
class ParsedInput:
    """
    The result of LanguageParser processing a transcript.
    Passed to the Orchestrator for routing.
    """
    input_type: InputType
    intent: str                             # short description of what the user wants
    entities: dict[str, Any] = field(default_factory=dict)  # extracted named entities
    raw_text: str = ""                      # original transcript
    confidence: float = 1.0                 # classification confidence
    is_urgent: bool = False                 # should this interrupt an active task?

    def __str__(self) -> str:
        return (
            f"ParsedInput(type={self.input_type.value}, "
            f"intent='{self.intent}', conf={self.confidence:.2f})"
        )
