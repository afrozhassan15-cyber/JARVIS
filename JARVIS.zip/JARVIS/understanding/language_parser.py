"""
understanding/language_parser.py

Classifies user input using IBM watsonx.ai.
Falls back to simple rule-based classification when API is unavailable.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Optional

from understanding.input_types import InputType, ParsedInput

logger = logging.getLogger(__name__)

# ── Keyword-based fallback rules ──────────────────────────────────────────────
_CANCEL_KEYWORDS    = {"stop", "cancel", "abort", "quit", "exit"}
_RESUME_KEYWORDS    = {"resume", "continue", "carry on", "go on"}
_INTERRUPTION_KW    = {"pause", "wait", "hold on", "stop that", "do this instead",
                       "start the game", "never mind"}
_QUESTION_STARTERS  = {"what", "who", "where", "when", "why", "how", "is ", "are ",
                       "can ", "could ", "would ", "should ", "tell me", "explain"}
_TASK_KEYWORDS      = {"open", "launch", "start", "type", "write", "click",
                       "search", "find", "go to", "navigate", "delete", "copy",
                       "move", "create", "close", "switch", "send", "download",
                       "install", "uninstall", "run", "execute", "save"}
_CONFIRMATION_KW    = {"yes", "yeah", "yep", "sure", "ok", "okay", "confirm",
                       "no", "nope", "cancel", "reject", "deny"}


class LanguageParser:
    """
    Parses a natural-language transcript into a ParsedInput.

    When watsonx.ai is available: calls the LLM for structured classification.
    When unavailable: falls back to deterministic keyword rules (still useful
    for smoke-testing the whole pipeline without API credentials).
    """

    _LLM_SYSTEM_PROMPT = """You are a language understanding module for JARVIS, a desktop AI assistant.
Classify the user's input into exactly one of these types:
CONVERSATION, QUESTION, COMPUTER_TASK, MULTI_STEP_TASK, INTERRUPTION, CANCEL, CLARIFICATION, CONFIRMATION, RESUME, UNKNOWN

Rules:
- COMPUTER_TASK: single computer action (open one app, click one thing, type text)
- MULTI_STEP_TASK: requires 2 or more sequential computer actions
- INTERRUPTION: user wants to pause/stop/switch the current task
- CANCEL: user explicitly cancels (stop, cancel, abort)
- QUESTION: asking for information (no computer action needed)
- CONVERSATION: casual chat, greetings, small talk
- CONFIRMATION: answering yes/no to JARVIS's question
- RESUME: user wants to continue a paused task
- CLARIFICATION: user is providing more detail after JARVIS asked

Respond with ONLY valid JSON in this exact format:
{
  "input_type": "COMPUTER_TASK",
  "intent": "open Notepad application",
  "entities": {"application": "Notepad"},
  "confidence": 0.95,
  "is_urgent": false
}"""

    def __init__(self, watsonx_client=None) -> None:
        """
        Args:
            watsonx_client: an initialised WatsonxAIClient instance, or None
                            to use keyword-based fallback.
        """
        self._watsonx = watsonx_client

    def parse(self, transcript: str) -> ParsedInput:
        """
        Parse a transcript and return a ParsedInput.

        Uses the LLM only when a real (non-mock) client is available.
        When the client is in mock mode, or absent, the accurate rule-based
        classifier is used directly so that conversational inputs are never
        misrouted to the task pipeline.
        """
        if not transcript or not transcript.strip():
            return ParsedInput(
                input_type=InputType.UNKNOWN,
                intent="",
                raw_text=transcript,
                confidence=0.0,
            )

        transcript = transcript.strip()

        # Only call the LLM when a real (non-mock) model is available.
        # A mock client returns action-proposal JSON that lacks "input_type",
        # which would make every input classify as UNKNOWN.
        if self._watsonx and not getattr(self._watsonx, "is_mock", True):
            try:
                return self._parse_with_llm(transcript)
            except Exception as exc:
                logger.warning("LLM parse failed (%s), falling back to rules.", exc)

        return self._parse_with_rules(transcript)

    # ── LLM-based parsing ─────────────────────────────────────────────────────

    def _parse_with_llm(self, transcript: str) -> ParsedInput:
        messages = [
            {"role": "system", "content": self._LLM_SYSTEM_PROMPT},
            {"role": "user", "content": transcript},
        ]
        raw = self._watsonx.chat(messages)
        data = self._extract_json(raw)
        return ParsedInput(
            input_type=InputType(data.get("input_type", "UNKNOWN")),
            intent=data.get("intent", transcript),
            entities=data.get("entities", {}),
            raw_text=transcript,
            confidence=float(data.get("confidence", 0.8)),
            is_urgent=bool(data.get("is_urgent", False)),
        )

    # ── Rule-based fallback ───────────────────────────────────────────────────

    def _parse_with_rules(self, transcript: str) -> ParsedInput:
        text = transcript.lower().strip()
        words = set(re.split(r"\W+", text))

        # Cancel
        if words & _CANCEL_KEYWORDS and len(words) <= 4:
            return ParsedInput(InputType.CANCEL, "cancel current task",
                               raw_text=transcript, confidence=0.9)

        # Resume
        if words & _RESUME_KEYWORDS:
            return ParsedInput(InputType.RESUME, "resume paused task",
                               raw_text=transcript, confidence=0.85)

        # Interruption
        if any(kw in text for kw in _INTERRUPTION_KW):
            return ParsedInput(InputType.INTERRUPTION, transcript,
                               raw_text=transcript, confidence=0.80,
                               is_urgent=True)

        # Confirmation (very short yes/no)
        if words & _CONFIRMATION_KW and len(words) <= 3:
            return ParsedInput(InputType.CONFIRMATION, transcript,
                               raw_text=transcript, confidence=0.85)

        # Task keywords present
        task_kw_found = words & _TASK_KEYWORDS
        if task_kw_found:
            # Multi-step detection: connectives OR multiple distinct task keywords
            # e.g. "open notepad and type hello" has both "open" and "type"
            connectives = {"and then", "then", "after that", "next", "also",
                           "and also", "finally", "first"}
            has_connective = any(c in text for c in connectives)
            comma_count = transcript.count(",")
            multiple_task_kw = len(task_kw_found) >= 2
            if has_connective or comma_count >= 1 or multiple_task_kw:
                return ParsedInput(InputType.MULTI_STEP_TASK, transcript,
                                   raw_text=transcript, confidence=0.75)
            return ParsedInput(InputType.COMPUTER_TASK, transcript,
                               raw_text=transcript, confidence=0.75)

        # Question starters
        if any(text.startswith(q) for q in _QUESTION_STARTERS):
            return ParsedInput(InputType.QUESTION, transcript,
                               raw_text=transcript, confidence=0.70)

        # Default to conversation
        return ParsedInput(InputType.CONVERSATION, transcript,
                           raw_text=transcript, confidence=0.60)

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _extract_json(text: str) -> dict:
        """Extract first JSON object from LLM output (may contain surrounding text)."""
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass
        logger.warning("Could not extract JSON from LLM response: %s", text[:200])
        return {}
