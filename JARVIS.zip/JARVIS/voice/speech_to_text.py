"""
voice/speech_to_text.py

Converts microphone audio to text using IBM Watson STT.
Falls back to SpeechRecognition (Google STT) when credentials are unavailable.
"""

from __future__ import annotations

import logging
import sys
import threading
import time
import warnings
from dataclasses import dataclass
from typing import Callable, Optional

logger = logging.getLogger(__name__)


def _ensure_speech_recognition_compat() -> None:
    """Fix speech_recognition compatibility on Python 3.13+.

    `speech_recognition` imports the stdlib module `aifc`. In Python 3.13+,
    `aifc` was removed from the stdlib, so the compatibility package named
    `standard-aifc` must be aliased back to `aifc` before importing it.
    """
    if sys.version_info < (3, 13):
        return

    if "aifc" in sys.modules:
        return

    try:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message="aifc was removed in Python 3.13.*",
                category=DeprecationWarning,
            )
            import aifc  # noqa: F401
        return
    except ModuleNotFoundError:
        pass

    try:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message="aifc was removed in Python 3.13.*",
                category=DeprecationWarning,
            )
            import standard_aifc as aifc  # type: ignore
        sys.modules["aifc"] = aifc
        logger.info("SpeechRecognition compatibility shim registered for Python 3.13+")
    except Exception as exc:  # pragma: no cover
        logger.warning("SpeechRecognition compatibility shim unavailable: %s", exc)


@dataclass
class TranscriptResult:
    text: str
    confidence: float = 1.0
    is_final: bool = True


class SpeechToText:
    """
    Listens to the microphone and converts speech to text.

    Priority:
    1. IBM Watson STT (streaming, if configured)
    2. SpeechRecognition library with Google STT (fallback)

    Usage:
        stt = SpeechToText(api_key=..., url=...)
        stt.listen_once(callback=on_transcript)
    """

    def __init__(
        self,
        api_key: str = "",
        url: str = "",
        on_transcript: Optional[Callable[[TranscriptResult], None]] = None,
        on_state: Optional[Callable[[str], None]] = None,
    ) -> None:
        self._api_key = api_key
        self._url = url
        self._on_transcript = on_transcript
        self._on_state = on_state
        self._listening = threading.Event()
        self._last_transcript_key: Optional[str] = None
        self._last_transcript_time = 0.0
        self._mode = self._detect_mode()
        logger.info("SpeechToText: mode=%s", self._mode)

    def _detect_mode(self) -> str:
        if self._api_key and "your_watson" not in self._api_key:
            try:
                from ibm_watson import SpeechToTextV1
                from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
                auth = IAMAuthenticator(self._api_key)
                self._watson = SpeechToTextV1(authenticator=auth)
                self._watson.set_service_url(self._url)
                logger.info("STT: IBM Watson mode active")
                return "watson"
            except Exception as exc:
                logger.warning("Watson STT init failed: %s", exc)

        try:
            _ensure_speech_recognition_compat()
            import speech_recognition  # noqa: F401
            logger.info("STT: SpeechRecognition fallback mode active")
            return "speech_recognition"
        except ImportError:
            logger.warning("No STT library available — microphone disabled")
            return "disabled"

    def set_callback(self, callback: Callable[[TranscriptResult], None]) -> None:
        self._on_transcript = callback

    def set_state_callback(self, callback: Callable[[str], None]) -> None:
        self._on_state = callback

    def listen_once(self) -> Optional[TranscriptResult]:
        """
        Block and listen until the user stops speaking.
        Delivers result via callback AND returns it.
        """
        if self._mode == "disabled":
            logger.warning("STT: disabled — cannot listen")
            return None

        if self._mode == "watson":
            return self._listen_watson()
        return self._listen_speech_recognition()

    def listen_once_async(self) -> None:
        """Non-blocking: run listen_once on a background thread."""
        if self._listening.is_set():
            logger.info("SpeechToText: already listening")
            return
        thread = threading.Thread(target=self._listen_and_deliver, daemon=True)
        thread.start()

    def stop(self) -> None:
        """Request that the current listening session stop before the next one."""
        self._listening.clear()

    def _deliver_result(self, result: Optional[TranscriptResult]) -> None:
        """Send transcript to callback exactly once per spoken sentence."""
        if not result or not result.text or not result.text.strip():
            return

        normalized = result.text.strip()
        now = time.monotonic()
        if (
            self._last_transcript_key == normalized.lower()
            and now - self._last_transcript_time < 2.0
        ):
            logger.info("SpeechToText: suppressed duplicate transcript: %r", normalized)
            return

        self._last_transcript_key = normalized.lower()
        self._last_transcript_time = now

        if self._on_transcript:
            self._on_transcript(result)

    def _listen_and_deliver(self) -> None:
        self._listening.set()
        if self._on_state:
            self._on_state("LISTENING")
        try:
            result = self.listen_once()
            if result:
                self._deliver_result(result)
        finally:
            self._listening.clear()
            if self._on_state:
                self._on_state("IDLE")

    # ── Watson STT ────────────────────────────────────────────────────────────

    def _listen_watson(self) -> Optional[TranscriptResult]:
        try:
            import pyaudio
            CHUNK = 1024
            FORMAT = pyaudio.paInt16
            CHANNELS = 1
            RATE = 16000
            SILENCE_SECONDS = 2

            p = pyaudio.PyAudio()
            stream = p.open(format=FORMAT, channels=CHANNELS, rate=RATE,
                            input=True, frames_per_buffer=CHUNK)

            audio_data = b""
            import time
            start = time.time()
            logger.info("Watson STT: listening...")

            # Simple approach: record for up to 10s then transcribe
            while (time.time() - start) < 10:
                audio_data += stream.read(CHUNK, exception_on_overflow=False)

            stream.stop_stream()
            stream.close()
            p.terminate()

            response = self._watson.recognize(
                audio=audio_data,
                content_type="audio/l16; rate=16000",
                model="en-US_BroadbandModel",
            ).get_result()

            results = response.get("results", [])
            if results:
                alt = results[-1]["alternatives"][0]
                return TranscriptResult(
                    text=alt["transcript"].strip(),
                    confidence=alt.get("confidence", 1.0),
                )
        except Exception as exc:
            logger.error("Watson STT error: %s", exc)
        return None

    # ── SpeechRecognition fallback ────────────────────────────────────────────

    def _listen_speech_recognition(self) -> Optional[TranscriptResult]:
        try:
            _ensure_speech_recognition_compat()
            import speech_recognition as sr
            recognizer = sr.Recognizer()
            with sr.Microphone() as source:
                logger.info("SpeechRecognition: adjusting for ambient noise...")
                recognizer.adjust_for_ambient_noise(source, duration=0.5)
                logger.info("SpeechRecognition: listening...")
                audio = recognizer.listen(source, timeout=10, phrase_time_limit=15)

            text = recognizer.recognize_google(audio)
            return TranscriptResult(text=text, confidence=0.9)
        except Exception as exc:
            logger.warning("SpeechRecognition error: %s", exc)
            return None
