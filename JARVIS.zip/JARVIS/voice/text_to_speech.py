"""
voice/text_to_speech.py

Converts text to speech using IBM Watson TTS.
Falls back to pyttsx3 offline synthesis when credentials are unavailable.
"""

from __future__ import annotations

import logging
import os
import tempfile
import threading
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class TextToSpeech:
    """
    Converts text to audio and plays it through the system speaker.
    Runs audio playback on a background thread so the GUI never blocks.

    Priority:
    1. IBM Watson TTS (if configured)
    2. pyttsx3 offline (fallback)
    """

    def __init__(
        self,
        api_key: str = "",
        url: str = "",
        voice: str = "en-US_AllisonV3Voice",
    ) -> None:
        self._api_key   = api_key
        self._url       = url
        self._voice     = voice
        self._speaking  = threading.Event()
        self._watson_tts = None
        self._pyttsx3_engine = None

        self._mode = self._detect_mode()
        logger.info("TextToSpeech: mode=%s", self._mode)

    def _detect_mode(self) -> str:
        if self._api_key and "your_watson" not in self._api_key:
            try:
                from ibm_watson import TextToSpeechV1
                from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
                auth = IAMAuthenticator(self._api_key)
                self._watson_tts = TextToSpeechV1(authenticator=auth)
                self._watson_tts.set_service_url(self._url)
                logger.info("TTS: IBM Watson mode active")
                return "watson"
            except Exception as exc:
                logger.warning("Watson TTS init failed: %s", exc)

        try:
            import pyttsx3
            self._pyttsx3_engine = pyttsx3.init()
            self._pyttsx3_engine.setProperty("rate", 175)
            logger.info("TTS: pyttsx3 fallback mode active")
            return "pyttsx3"
        except Exception as exc:
            logger.warning("pyttsx3 init failed: %s — TTS disabled", exc)
            return "disabled"

    def speak(self, text: str) -> None:
        """
        Synthesise and play text.  Non-blocking — runs on a background thread.
        """
        if not text or self._mode == "disabled":
            return
        thread = threading.Thread(target=self._speak_blocking, args=(text,), daemon=True)
        thread.start()

    def _speak_blocking(self, text: str) -> None:
        self._speaking.set()
        try:
            if self._mode == "watson":
                self._speak_watson(text)
            elif self._mode == "pyttsx3":
                self._speak_pyttsx3(text)
        except Exception as exc:
            logger.error("TTS error: %s", exc)
        finally:
            self._speaking.clear()

    def _speak_watson(self, text: str) -> None:
        response = self._watson_tts.synthesize(
            text, voice=self._voice, accept="audio/wav"
        ).get_result()
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            f.write(response.content)
            tmp_path = f.name
        try:
            self._play_audio(tmp_path)
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

    def _speak_pyttsx3(self, text: str) -> None:
        self._pyttsx3_engine.say(text)
        self._pyttsx3_engine.runAndWait()

    def _play_audio(self, path: str) -> None:
        try:
            import pygame
            pygame.mixer.init()
            pygame.mixer.music.load(path)
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                import time; time.sleep(0.1)
        except ImportError:
            try:
                import playsound
                playsound.playsound(path, block=True)
            except Exception as exc:
                logger.warning("Audio playback failed: %s", exc)

    def is_speaking(self) -> bool:
        return self._speaking.is_set()

    def stop(self) -> None:
        try:
            import pygame
            if pygame.mixer.get_init():
                pygame.mixer.music.stop()
        except Exception:
            pass
